@echo off
cd /d %~dp0
echo == Scorecard: buggy vs fixed ==
python evaluate.py --compare
echo.
echo == Starting the test bench on http://localhost:8000 ==
python medguide.py serve
pause
