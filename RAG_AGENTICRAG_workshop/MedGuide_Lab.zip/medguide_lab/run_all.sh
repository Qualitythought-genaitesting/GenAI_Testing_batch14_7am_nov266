#!/usr/bin/env bash
cd "$(dirname "$0")"
echo "== Scorecard: buggy vs fixed =="; python3 evaluate.py --compare
echo; echo "== Starting the test bench on http://localhost:8000 =="; python3 medguide.py serve
