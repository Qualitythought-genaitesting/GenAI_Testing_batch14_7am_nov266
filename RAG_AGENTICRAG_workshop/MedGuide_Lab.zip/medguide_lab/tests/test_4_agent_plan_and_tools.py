"""Test points A and B - Agent planning and tool use: did it pick the right path and tools?"""
import unittest
from medguide.evals import golden, agent_case
from tests.helpers import CFG

G = {c["id"]: c for c in golden("agent")}


class TestAgentPlanAndTools(unittest.TestCase):
    def test_plan_covers_every_drug_pair(self):
        r = agent_case(G["AGT-01"], CFG)
        self.assertEqual(r["missing_pairs"], [], "Planner skipped drug pairs")
        self.assertTrue(r["ok"], r["trace"].answer)

    def test_greeting_uses_no_tools(self):
        r = agent_case(G["AGT-02"], CFG)
        self.assertEqual(r["tool_calls"], 0)

    def test_interaction_tool_called_with_right_arguments(self):
        r = agent_case(G["AGT-03"], CFG)
        self.assertTrue(r["ok"], f"calls made: {r['calls']}")
