"""Test point 3 - Generation: is the answer correct, grounded and safe?"""
import unittest
from medguide.evals import golden, rag_case
from tests.helpers import CFG


class TestGeneration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.results = {c["id"]: rag_case(c, CFG) for c in golden("rag")}

    def test_every_claim_is_supported_faithfulness(self):
        for rid, r in self.results.items():
            with self.subTest(rid):
                self.assertEqual(r["unsupported"], [], f"{rid} has claims not found in the sources")

    def test_expected_keywords_present(self):
        for rid, r in self.results.items():
            with self.subTest(rid):
                self.assertTrue(r["keywords_ok"], f"{rid} answer: {r['answer']}")

    def test_forbidden_phrases_absent(self):
        for rid, r in self.results.items():
            with self.subTest(rid):
                self.assertTrue(r["forbidden_ok"], f"{rid} answer: {r['answer']}")

    def test_says_i_dont_know_when_out_of_scope(self):
        self.assertIn("I don't know", self.results["RAG-07"]["answer"])
