import os
from medguide import config

CFG = config.load(os.environ.get("MEDGUIDE_PROFILE", "buggy"))
