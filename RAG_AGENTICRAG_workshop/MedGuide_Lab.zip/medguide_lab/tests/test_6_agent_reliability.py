"""Test point E - Reliability: same question, many runs, same good result?"""
import unittest
from medguide.evals import golden, agent_case
from tests.helpers import CFG

G = {c["id"]: c for c in golden("agent")}


class TestAgentReliability(unittest.TestCase):
    def test_pass_hat_10(self):
        r = agent_case(G["AGT-06"], CFG)
        self.assertEqual(r["passed"], r["runs"], f"passed only {r['passed']} of {r['runs']} runs")
