"""Test point 2 - Retrieval: did the 'librarian' bring the right pages?"""
import unittest
from medguide.evals import golden, rag_case
from tests.helpers import CFG

CASES = [c for c in golden("rag") if c["expected"]]


class TestRetrieval(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.results = [rag_case(c, CFG) for c in CASES]

    def test_recall_at_5_is_at_least_90_percent(self):
        recall = sum(r["recall@5"] for r in self.results) / len(self.results)
        self.assertGreaterEqual(recall, 0.9, f"Recall@5 = {recall:.0%}")

    def test_mrr_is_at_least_0_85(self):
        mrr = sum(r["rr"] for r in self.results) / len(self.results)
        self.assertGreaterEqual(mrr, 0.85, f"MRR = {mrr:.2f}; ranks = {[(r['id'], r['rank']) for r in self.results]}")

    def test_old_page_never_ranks_first(self):
        r = next(r for r in self.results if r["id"] == "RAG-02")
        top = r["trace"].steps[0].data["hits"][0]
        self.assertNotEqual(top["status"], "archived", f"Top result is an archived page: {top['id']}")
