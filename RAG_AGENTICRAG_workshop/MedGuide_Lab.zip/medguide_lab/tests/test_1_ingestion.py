"""Test point 1 - Ingestion: is the library prepared correctly before anyone asks?"""
import unittest
from medguide.corpus import build_chunks
from tests.helpers import CFG


class TestIngestion(unittest.TestCase):
    def setUp(self):
        self.chunks = build_chunks(CFG)

    def test_warning_sections_are_never_split(self):
        split = sorted({c.page for c in self.chunks if c.section == "Warnings" and "/" in c.id})
        self.assertEqual(split, [], f"Warnings cut into pieces on pages: {split}")

    def test_archived_pages_are_not_searchable(self):
        old = sorted({c.page for c in self.chunks if c.status == "archived"})
        self.assertEqual(old, [], f"Old page versions in the index: {old}")

    def test_every_chunk_has_metadata(self):
        bad = [c.id for c in self.chunks if not (c.drug and c.section and c.updated)]
        self.assertEqual(bad, [])
