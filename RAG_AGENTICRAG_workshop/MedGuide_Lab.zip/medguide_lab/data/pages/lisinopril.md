---
drug: lisinopril
title: Lisinopril
updated: 2026-06-18
status: active
source: drug-library
---
## Overview
Lisinopril is an ACE inhibitor used to treat high blood pressure and heart failure.

## Common side effects
The most common side effects of lisinopril are dry cough, dizziness, headache, and feeling tired.

## Warnings
Do not use lisinopril if you are pregnant, because it can harm the unborn baby. Lisinopril can raise potassium levels in the blood. Get emergency medical help if you have swelling of the face, lips, tongue, or throat.

## Interactions
NSAID pain relievers such as ibuprofen may reduce the blood pressure lowering effect of lisinopril. Using an NSAID with lisinopril may also harm kidney function, especially in older adults or people who are dehydrated.
