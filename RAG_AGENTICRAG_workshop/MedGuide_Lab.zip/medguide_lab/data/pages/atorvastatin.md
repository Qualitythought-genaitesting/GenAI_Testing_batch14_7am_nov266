---
drug: atorvastatin
title: Atorvastatin
updated: 2026-04-11
status: active
source: drug-library
---
## Overview
Atorvastatin is a statin medicine used to lower cholesterol and reduce the risk of heart attack and stroke.

## Common side effects
The most common side effects of atorvastatin are muscle aches, joint pain, diarrhea, and cold-like symptoms such as a stuffy nose.

## Warnings
Atorvastatin can rarely cause a serious muscle problem. Call your doctor right away if you have unexplained muscle pain, tenderness, or weakness, especially with fever or unusual tiredness.

## What to avoid
Avoid drinking large amounts of grapefruit juice while taking atorvastatin.
