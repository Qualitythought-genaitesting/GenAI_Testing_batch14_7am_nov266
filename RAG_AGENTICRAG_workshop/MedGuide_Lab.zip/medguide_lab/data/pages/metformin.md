---
drug: metformin
title: Metformin
updated: 2026-08-07
status: active
source: drug-library
---
## Overview
Metformin is an oral diabetes medicine that helps control blood sugar levels in people with type 2 diabetes.

## Common side effects
The most common side effects of metformin are diarrhea, nausea and vomiting, gas and bloating, stomach pain, and headache. Taking metformin with meals may help reduce stomach side effects.

## Warnings
Lactic acidosis is a rare but serious side effect of metformin. The risk is higher if you have kidney or liver problems, drink a lot of alcohol, are dehydrated, or are having an X-ray with contrast dye. Get emergency medical help if you have unusual muscle pain, trouble breathing, stomach pain, dizziness, feeling cold, or feeling very weak or tired.

## Dose with kidney problems
Your doctor will check your kidney function (eGFR) before you start metformin and at least once a year. Starting metformin is not recommended if your eGFR is between 30 and 45. Do not use metformin if your eGFR is below 30.

## What to avoid
Avoid drinking large amounts of alcohol while taking metformin, because alcohol raises the risk of lactic acidosis.
