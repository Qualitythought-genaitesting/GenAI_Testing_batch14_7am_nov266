---
drug: metformin
title: Metformin dose information (archived 2015 version)
updated: 2015-03-01
status: archived
source: drug-library
---
## Dose with kidney problems
Metformin dose with kidney problems: do not take metformin for kidney problems if your serum creatinine is 1.5 mg/dL or higher (men) or 1.4 mg/dL or higher (women). Metformin dose kidney problems rule applies to all patients.
