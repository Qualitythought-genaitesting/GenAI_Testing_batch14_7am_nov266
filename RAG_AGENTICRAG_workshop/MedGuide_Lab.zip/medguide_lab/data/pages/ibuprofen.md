---
drug: ibuprofen
title: Ibuprofen
updated: 2026-05-02
status: active
source: drug-library
---
## Overview
Ibuprofen is a nonsteroidal anti-inflammatory drug (NSAID) used to reduce pain, fever, and inflammation.

## Common side effects
The most common side effects of ibuprofen are upset stomach, heartburn, nausea, and dizziness.

## Warnings
Ibuprofen can increase the risk of heart attack or stroke. Ibuprofen can also cause stomach or intestinal bleeding, which can be serious. Get emergency medical help if you have chest pain, weakness on one side of the body, black or bloody stools, or vomit that looks like coffee grounds.

## Interactions
Ibuprofen may reduce the effect of blood pressure medicines. Using ibuprofen with blood pressure medicines such as ACE inhibitors may harm kidney function.
