"""Ingestion: load drug pages, cut them into chunks, build a BM25 search index."""
import json
import math
import re
from dataclasses import dataclass, field
from pathlib import Path

DATA = Path(__file__).resolve().parent.parent / "data"
STOP = set("""a an the of to and or for with in on at is are be by it its if your you
what which who how do does i my me can any about this that these those from as was were
should while taking take tell anything there they them their has have had not""".split())


def tokens(text: str) -> list[str]:
    return [t for t in re.findall(r"[a-z0-9]+", text.lower()) if t not in STOP]


@dataclass
class Chunk:
    id: str
    page: str
    drug: str
    section: str
    text: str
    updated: str
    status: str
    source: str
    prefix: str = ""
    meta: dict = field(default_factory=dict)


def _parse(path: Path) -> tuple[dict, list[tuple[str, str]]]:
    raw = path.read_text(encoding="utf-8")
    _, fm, body = raw.split("---", 2)
    meta = dict(line.split(": ", 1) for line in fm.strip().splitlines())
    sections = []
    for block in re.split(r"^## ", body.strip(), flags=re.M):
        if block.strip():
            head, _, text = block.partition("\n")
            sections.append((head.strip(), " ".join(text.split())))
    return meta, sections


def slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


def build_chunks(cfg) -> list[Chunk]:
    chunks = []
    for path in sorted((DATA / "pages").glob("*.md")):
        meta, sections = _parse(path)
        if meta["status"] == "archived" and not cfg.index_archived_pages:
            continue
        page = path.stem
        for head, text in sections:
            if cfg.chunk_strategy == "section":
                pieces = [text]
            else:  # fixed_words: cut every N words, ignoring sentence boundaries
                words = text.split()
                pieces = [" ".join(words[i:i + cfg.chunk_words]) for i in range(0, len(words), cfg.chunk_words)]
            for n, piece in enumerate(pieces):
                prefix = f"{meta['title']} | {head}: " if cfg.add_heading_to_chunk else ""
                body = prefix + piece
                chunks.append(Chunk(
                    id=f"{page}#{slug(head)}" + (f"/{n}" if len(pieces) > 1 else ""),
                    page=page, drug=meta["drug"], section=head, text=body,
                    updated=meta["updated"], status=meta["status"], source=meta["source"], prefix=prefix))
    return chunks


class Index:
    """Tiny BM25 search engine (stands in for a vector database)."""

    def __init__(self, chunks: list[Chunk], k1=1.4, b=0.6):
        self.chunks = chunks
        self.toks = [tokens(c.text) for c in chunks]
        self.avg = sum(map(len, self.toks)) / max(len(self.toks), 1)
        self.k1, self.b = k1, b
        df = {}
        for t in self.toks:
            for w in set(t):
                df[w] = df.get(w, 0) + 1
        n = len(chunks)
        self.idf = {w: math.log(1 + (n - d + 0.5) / (d + 0.5)) for w, d in df.items()}

    def search(self, query: str, k: int = 5, drug: str | None = None):
        q = tokens(query)
        scored = []
        for c, t in zip(self.chunks, self.toks):
            if drug and c.drug != drug:
                continue
            s = 0.0
            for w in set(q):
                f = t.count(w)
                if f:
                    s += self.idf.get(w, 0) * f * (self.k1 + 1) / (f + self.k1 * (1 - self.b + self.b * len(t) / self.avg))
            if s > 0:
                scored.append((round(s, 3), c))
        scored.sort(key=lambda x: -x[0])
        return scored[:k]


def known_drugs() -> list[str]:
    drugs = []
    for path in sorted((DATA / "pages").glob("*.md")):
        d = _parse(path)[0]["drug"]
        if d not in drugs:
            drugs.append(d)
    return drugs


def load_json(name: str):
    return json.loads((DATA / name).read_text(encoding="utf-8"))
