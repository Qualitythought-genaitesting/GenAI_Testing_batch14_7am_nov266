"""MedGuide: a tiny drug-safety assistant for practising RAG and agentic RAG testing. Training data only, not medical advice."""
