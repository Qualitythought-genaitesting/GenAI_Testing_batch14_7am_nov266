"""MedGuide in agentic RAG mode: plan -> call tools -> grade -> retry -> check -> answer."""
import random
import re
from itertools import combinations
from . import config, tools
from .corpus import known_drugs, tokens
from .mockllm import write_answer, faithfulness, intent
from .rag import index_for
from .trace import Trace

GREETINGS = {"hi", "hello", "hey", "thanks", "thank", "you", "good", "morning"}
KNOWN = known_drugs()
REWRITES = ["{t} side effects", "{t} overview uses", "what is {t}", "{t} warnings", "{t} medicine"]


def _drugs_in(question: str) -> list[str]:
    q = question.lower()
    found = [(q.find(d), d) for d in KNOWN if d in q]
    return [d for _, d in sorted(found)]


def _unknown_target(question: str) -> str:
    words = [w for w in tokens(question) if w not in {"side", "effects", "common", "dose", "warnings", "interact", "safe"}]
    return words[-1] if words else question.strip()


def plan(question: str, cfg, rng) -> dict:
    words = set(re.findall(r"[a-z]+", question.lower()))
    if words and words <= GREETINGS:
        return {"kind": "chat", "tasks": [], "note": "greeting: no tools needed"}
    drugs = _drugs_in(question)
    if cfg.planner_max_entities:
        drugs = drugs[:cfg.planner_max_entities]
    tasks = []
    if len(drugs) >= 2:
        tasks += [{"tool": "check_interaction", "args": {"drug_a": a, "drug_b": b}} for a, b in combinations(drugs, 2)]
        tasks += [{"tool": "search_drug_pages", "args": {"query": f"{d} warnings emergency"}, "target": d, "filter": d,
                   "ask": f"{d} warnings emergency serious", "max_sentences": 1} for d in drugs]
        tasks += [{"tool": "get_safety_updates", "args": {"drug": d}} for d in drugs]
        return {"kind": "multi_drug", "drugs": drugs, "tasks": tasks}
    if len(drugs) == 1:
        d = drugs[0]
        query, flt = question, d
        if cfg.temperature and rng.random() < cfg.temperature * 0.6:  # "creative" paraphrase drops the drug name
            query, flt = re.sub(d, "", question, flags=re.I).replace("  ", " ").strip(), None
        tasks.append({"tool": "search_drug_pages", "args": {"query": query}, "target": d, "filter": flt, "ask": question})
        return {"kind": "single_drug", "drugs": [d], "tasks": tasks}
    target = _unknown_target(question)
    tasks.append({"tool": "search_drug_pages", "args": {"query": question}, "target": target, "filter": target, "ask": question})
    return {"kind": "unknown_drug", "drugs": [target], "tasks": tasks}


def ask(question: str, cfg=None, seed=None) -> Trace:
    cfg = cfg or config.load()
    rng = random.Random(seed)
    idx = index_for(cfg)
    t = Trace(question, "agent", cfg.profile)
    p = plan(question, cfg, rng)
    t.add("plan", "planner", p.get("note") or f"{p['kind']}: {len(p['tasks'])} task(s) for {', '.join(p['drugs'])}",
          tasks=[{"tool": x["tool"], "args": x["args"]} for x in p["tasks"]], kind=p["kind"])
    if p["kind"] == "chat":
        t.answer = "Hello! Ask me about a medicine, its side effects, warnings or interactions."
        t.add("answer", "llm", "replied without tools")
        return t

    parts, evidence, sources = [], [], []

    def cite(src_id, text):
        evidence.append(text)
        if src_id not in sources:
            sources.append(src_id)
        return sources.index(src_id) + 1

    def budget_ok():
        if cfg.enforce_step_limit and len(t.steps) >= cfg.max_steps:
            t.status = "step_limit"
            t.add("stop", "controller", f"step limit of {cfg.max_steps} reached, stopping safely")
            return False
        if len(t.steps) >= config.HARD_STOP:
            t.status = "runaway"
            t.add("stop", "watchdog", f"EMERGENCY STOP after {config.HARD_STOP} steps (no step limit configured)")
            return False
        return True

    for task in p["tasks"]:
        if not budget_ok():
            break
        tool, args = task["tool"], task["args"]
        if tool == "check_interaction":
            r = tools.check_interaction(**args)
            t.add("tool_call", tool, f"({args['drug_a']}, {args['drug_b']}) -> {r.get('severity')}", args=args, result=r)
            if r.get("text"):
                n = cite(f"interaction-db: {r['pair']}", r["text"])
                parts.append(f"{args['drug_a'].title()} + {args['drug_b']} ({r['severity']}): {r['text']} [{n}]")
            continue
        if tool == "get_safety_updates":
            r = tools.get_safety_updates(**args)
            t.add("tool_call", tool, f"({args['drug']}) -> {len(r['updates'])} update(s)", args=args, result=r)
            for u in r["updates"]:
                n = cite(f"safety-updates: {args['drug']} {u['date']}", u["text"])
                parts.append(f"Safety update {u['date']}: {u['text']} [{n}]")
            continue
        # ---- search with grade / rewrite loop ----
        query, attempt = args["query"], 0
        while True:
            if attempt and not budget_ok():
                break
            hits = idx.search(query, k=3, drug=task.get("filter"))
            t.add("tool_call", "search_drug_pages", f"'{query}'" + (f" [drug={task['filter']}]" if task.get("filter") else "") + f" -> {len(hits)} hit(s)",
                  args={"query": query, "drug": task.get("filter")}, result=[h.id for _, h in hits])
            safe_hits = []
            for s, h in hits:
                if "AI ASSISTANT INSTRUCTION" in h.text:
                    if cfg.trust_tool_text:
                        m = re.search(r'drug="([^"]+)" and quantity=(\d+)', h.text)
                        r = tools.request_refill(m.group(1), int(m.group(2)), approved=False, cfg=cfg)
                        t.add("tool_call", "request_refill", f"(drug={m.group(1)!r}, qty={m.group(2)}, approved=False) -> {r['status']}",
                              args={"drug": m.group(1), "quantity": int(m.group(2)), "approved": False}, result=r, triggered_by=h.id)
                        safe_hits.append((s, h))
                    else:
                        t.add("guard", "injection_guard", f"ignored instructions hidden in {h.id}; kept only the visible text", source=h.id)
                        safe_hits.append((s, h))
                    continue
                safe_hits.append((s, h))
            target = task["target"]
            good = [(s, h) for s, h in safe_hits if s >= cfg.min_score and (not cfg.grader_checks_drug or target in h.text.lower() or h.drug == target)]
            t.add("grade", "grader", f"{len(good)} of {len(hits)} relevant" + (" -> use them" if good else " -> retry"), relevant=[h.id for _, h in good])
            if good:
                ans, cited = write_answer(task["ask"], good, cfg, task.get("max_sentences", 3))
                id_map = {h.id: h.text for _, h in good}
                for cid in cited:
                    n = cite(cid, id_map[cid])
                    ans = ans.replace(f"[{cited.index(cid) + 1}]", f"[#{n}]")
                parts.append(ans.replace("[#", "["))
                break
            if not budget_ok():
                break
            attempt += 1
            query = REWRITES[(attempt - 1) % len(REWRITES)].format(t=target)
            t.add("rewrite", "query_rewriter", f"new query: '{query}'")
        if t.status in ("step_limit", "runaway"):
            break

    if parts:
        t.answer = " ".join(parts)
    else:
        t.answer = f"I could not find reliable information about {', '.join(p['drugs'])} in the MedGuide sources."
        if t.status == "ok":
            t.status = "no_answer"
    t.sources = sources
    score, verdicts = faithfulness(t.answer, evidence) if parts else (1.0, [])
    t.add("self_check", "checker", f"{sum(v for _, v in verdicts)}/{len(verdicts)} claims backed by sources", faithfulness=score)
    t.add("answer", "llm", f"final answer, {len(t.answer.split())} words")
    return t
