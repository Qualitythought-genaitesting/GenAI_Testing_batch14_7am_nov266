"""MedGuide in plain RAG mode: one search, one answer. Always the same path."""
from functools import lru_cache
from . import config
from .corpus import build_chunks, Index
from .mockllm import write_answer
from .trace import Trace

IDK = "I don't know. I could not find this in the MedGuide drug pages."


@lru_cache(maxsize=4)
def index_for(cfg) -> Index:
    return Index(build_chunks(cfg))


def ask(question: str, cfg=None) -> Trace:
    cfg = cfg or config.load()
    idx = index_for(cfg)
    t = Trace(question, "rag", cfg.profile)
    hits = idx.search(question, k=cfg.top_k)
    t.add("retrieve", "search_index", f"top {cfg.top_k}: " + ", ".join(f"{c.id} ({s})" for s, c in hits) if hits else "no matches",
          hits=[{"id": c.id, "page": c.page, "section": c.section, "score": s, "text": c.text, "status": c.status, "updated": c.updated} for s, c in hits])
    if not hits or hits[0][0] < cfg.min_score:
        t.answer, t.status = IDK, "no_answer"
        t.add("answer", "llm", "said I don't know (nothing relevant found)")
        return t
    answer, cited = write_answer(question, hits, cfg)
    if not answer:
        t.answer, t.status = IDK, "no_answer"
    else:
        t.answer, t.sources = answer, cited
    t.add("answer", "llm", f"wrote {len(t.answer.split())} words from {len(cited)} chunk(s)", context=[c.text for _, c in hits])
    return t
