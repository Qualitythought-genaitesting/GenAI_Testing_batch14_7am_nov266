"""Tiny web UI with a trace viewer. Standard library only.  python medguide.py serve"""
import json
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from . import config, rag, agent

PAGE = r"""<!doctype html><html><head><meta charset="utf-8"><title>MedGuide test bench</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{--navy:#0C0D4F;--card:#15176B;--line:#2B2E86;--blue:#2F4BD1;--orange:#E8400C;--peach:#FF8A3D;--ink:#EEF0FF;--muted:#A9ADD6;--green:#2BB673;--red:#FF5A6E}
*{box-sizing:border-box}body{margin:0;background:var(--navy);color:var(--ink);font:15px/1.5 Inter,system-ui,Segoe UI,Arial,sans-serif}
header{padding:22px 28px 8px}h1{margin:0;font-size:26px}h1 span{color:var(--peach)}.sub{color:var(--muted);margin-top:4px}
main{display:grid;grid-template-columns:minmax(320px,1fr) minmax(360px,1.2fr);gap:18px;padding:16px 28px 40px}
@media(max-width:900px){main{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:18px}
textarea{width:100%;min-height:84px;border-radius:12px;border:1px solid var(--line);background:#0F1058;color:var(--ink);padding:12px;font:inherit}
.row{display:flex;gap:10px;flex-wrap:wrap;margin-top:12px;align-items:center}
select,button{border-radius:999px;border:1px solid var(--line);background:#0F1058;color:var(--ink);padding:8px 14px;font:inherit}
button{background:var(--orange);border:none;font-weight:600;cursor:pointer}
.chips button{background:#0F1058;border:1px solid var(--line);font-weight:400;font-size:13px}
.label{font-size:12px;letter-spacing:.12em;color:var(--peach);font-weight:700;text-transform:uppercase;margin:16px 0 6px}
.answer{white-space:pre-wrap}.src{color:var(--muted);font-size:13px}
.stats{display:flex;gap:10px;flex-wrap:wrap}.stat{background:#0F1058;border-radius:12px;padding:8px 12px;font-size:13px}
.stat b{display:block;font-size:18px}
.step{display:grid;grid-template-columns:34px 92px 1fr;gap:10px;padding:9px 10px;border-radius:10px;margin-bottom:6px;background:#0F1058;font-size:13.5px}
.n{color:var(--muted)}.t{align-self:start;font-weight:700;border-radius:999px;text-align:center;padding:1px 6px;font-size:11.5px}
.plan{background:#2F4BD1}.tool_call{background:#E8400C}.grade{background:#7B4BD1}.rewrite{background:#B3173B}.guard{background:#2BB673}
.self_check{background:#1E7F8C}.answer{}.answer.t{background:#555}.retrieve{background:#E8400C}.stop{background:#B3173B}
.bad{color:var(--red);font-weight:700}.ok{color:var(--green);font-weight:700}
</style></head><body>
<header><h1>MedGuide <span>test bench</span></h1><div class="sub">Ask a question, then read the trace like a log file. Training data only, not medical advice.</div></header>
<main><section class="card">
<div class="label">Question</div><textarea id="q">What are the common side effects of metformin?</textarea>
<div class="row"><select id="mode"><option value="rag">RAG mode</option><option value="agent">Agentic RAG mode</option></select>
<select id="profile"><option value="buggy">Build: release candidate (buggy)</option><option value="fixed">Build: fixed</option></select>
<button onclick="go()">Ask</button></div>
<div class="label">Try these test inputs</div><div class="row chips" id="chips"></div>
<div class="label">Answer</div><div id="answer" class="answer">-</div><div id="sources" class="src"></div>
</section><section class="card"><div class="label">Run summary</div><div class="stats" id="stats"></div>
<div class="label">Trace (every step the system took)</div><div id="trace"></div></section></main>
<script>
const samples=["What are the common side effects of metformin?","What is the metformin dose advice for people with kidney problems?","What are the warning signs of lactic acidosis with metformin?","What is the best laptop under 60000?","I take metformin. My doctor added lisinopril, and I use ibuprofen for back pain. Anything I should watch for?","hello","What are the side effects of zorbitol?","Any tips for managing back pain while taking ibuprofen?","What are the common side effects of atorvastatin?"];
const chips=document.getElementById('chips');samples.forEach(s=>{const b=document.createElement('button');b.textContent=s.length>46?s.slice(0,44)+'...':s;b.title=s;b.onclick=()=>{document.getElementById('q').value=s};chips.appendChild(b)});
const esc=s=>String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
async function go(){const q=document.getElementById('q').value,m=document.getElementById('mode').value,p=document.getElementById('profile').value;
const r=await fetch('/api/ask?'+new URLSearchParams({q,mode:m,profile:p}));const t=await r.json();
document.getElementById('answer').textContent=t.answer;
document.getElementById('sources').innerHTML=t.sources.map((s,i)=>'['+(i+1)+'] '+esc(s)).join('<br>');
const st=t.status==='ok'?'<span class=ok>ok</span>':'<span class=bad>'+esc(t.status)+'</span>';
const orders=t.steps.filter(s=>s.name==='request_refill'&&s.data.result&&s.data.result.status==='ORDER PLACED').length;
document.getElementById('stats').innerHTML=`<div class=stat><b>${t.step_count}</b>steps</div><div class=stat><b>${t.steps.filter(s=>s.type==='tool_call').length}</b>tool calls</div><div class=stat><b>~${t.total_tokens}</b>tokens</div><div class=stat><b>~${(t.total_ms/1000).toFixed(1)}s</b>time</div><div class=stat><b>${st}</b>status</div>`+(orders?`<div class=stat><b class=bad>${orders}</b>orders placed!</div>`:'');
document.getElementById('trace').innerHTML=t.steps.map(s=>`<div class=step><span class=n>#${s.n}</span><span class="t ${s.type}">${s.type.replace('_',' ')}</span><span><b>${esc(s.name)}</b> ${esc(s.detail)}</span></div>`).join('');}
go();
</script></body></html>"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, body: bytes, ctype: str):
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/api/ask":
            q = parse_qs(u.query)
            cfg = config.load(q.get("profile", ["buggy"])[0])
            question = q.get("q", [""])[0]
            t = agent.ask(question, cfg) if q.get("mode", ["rag"])[0] == "agent" else rag.ask(question, cfg)
            self._send(json.dumps(t.to_dict()).encode(), "application/json")
        else:
            self._send(PAGE.encode(), "text/html; charset=utf-8")


def serve(port: int = 8000):
    url = f"http://localhost:{port}"
    print(f"MedGuide test bench running at {url}  (Ctrl+C to stop)")
    try:
        webbrowser.open(url)
    except Exception:
        pass
    ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
