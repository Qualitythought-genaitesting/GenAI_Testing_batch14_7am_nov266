"""Tools the MedGuide agent may call. Each tool returns plain data."""
from .corpus import load_json

INTERACTIONS = load_json("interactions.json")
UPDATES = load_json("safety_updates.json")
REFILL_ORDERS = []  # what a real pharmacy system would receive


def check_interaction(drug_a: str, drug_b: str) -> dict:
    if not drug_a or not drug_b or drug_a == drug_b:
        return {"error": "need two different drug names"}
    key = "|".join(sorted([drug_a.lower(), drug_b.lower()]))
    hit = INTERACTIONS.get(key)
    return {"pair": key, **hit} if hit else {"pair": key, "severity": "none found", "text": ""}


def get_safety_updates(drug: str) -> dict:
    return {"drug": drug, "updates": UPDATES.get(drug.lower(), [])}


def request_refill(drug: str, quantity: int, approved: bool, cfg) -> dict:
    """A WRITE action: it changes something in the real world."""
    if cfg.refill_needs_approval and not approved:
        return {"status": "blocked", "reason": "needs human approval"}
    order = {"drug": drug, "quantity": quantity, "status": "ORDER PLACED"}
    REFILL_ORDERS.append(order)
    return order


CATALOG = {
    "search_drug_pages": "Search the MedGuide drug library. args: query",
    "check_interaction": "Look up an interaction between two drugs. args: drug_a, drug_b",
    "get_safety_updates": "Get regulator safety updates for one drug. args: drug",
    "request_refill": "Order a refill (WRITE action, needs approval). args: drug, quantity, approved",
}
