"""A trace is the agent's flight recorder: every step, in order."""
from dataclasses import dataclass, field, asdict

# Simulated cost per step type, so traces look like a real system.
COST = {"plan": (650, 900), "tool_call": (0, 180), "grade": (420, 600), "rewrite": (300, 500),
        "guard": (0, 5), "self_check": (500, 700), "answer": (900, 1200), "retrieve": (0, 120),
        "stop": (0, 0)}


@dataclass
class Step:
    n: int
    type: str
    name: str
    detail: str
    data: dict = field(default_factory=dict)
    tokens: int = 0
    ms: int = 0


@dataclass
class Trace:
    question: str
    mode: str
    profile: str
    steps: list = field(default_factory=list)
    answer: str = ""
    sources: list = field(default_factory=list)
    status: str = "ok"

    def add(self, type_, name, detail, **data) -> Step:
        tok, ms = COST.get(type_, (0, 0))
        s = Step(len(self.steps) + 1, type_, name, detail, data, tok, ms)
        self.steps.append(s)
        return s

    def tool_calls(self, name: str | None = None):
        return [s for s in self.steps if s.type == "tool_call" and (name is None or s.name == name)]

    @property
    def total_tokens(self):
        return sum(s.tokens for s in self.steps)

    @property
    def total_ms(self):
        return sum(s.ms for s in self.steps)

    def to_dict(self):
        d = asdict(self)
        d.update(total_tokens=self.total_tokens, total_ms=self.total_ms, step_count=len(self.steps))
        return d

    def pretty(self) -> str:
        icon = {"plan": "PLAN ", "tool_call": "TOOL ", "grade": "GRADE", "rewrite": "RETRY", "guard": "GUARD",
                "self_check": "CHECK", "answer": "ANSWR", "retrieve": "SRCH ", "stop": "STOP "}
        lines = [f"Q: {self.question}", f"mode={self.mode} profile={self.profile}", "-" * 72]
        for s in self.steps:
            lines.append(f"{s.n:>2} {icon.get(s.type, s.type):5} {s.name:<20} {s.detail}")
        lines += ["-" * 72, f"status={self.status}  steps={len(self.steps)}  tokens~{self.total_tokens}  time~{self.total_ms/1000:.1f}s",
                  "", "ANSWER:", self.answer or "(none)"]
        if self.sources:
            lines += ["", "SOURCES:"] + [f"  [{i+1}] {s}" for i, s in enumerate(self.sources)]
        return "\n".join(lines)
