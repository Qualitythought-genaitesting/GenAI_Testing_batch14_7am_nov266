"""An offline, deterministic stand-in for an LLM.

It is NOT a real language model. It picks sentences from the retrieved
text, which is enough to show every RAG and agent behaviour a tester needs
to see, with zero setup and zero cost. Swap in a real LLM later if you like.
"""
import re
from .corpus import tokens, known_drugs

INTENTS = {
    "side_effects": (["side effect", "side-effect", "side effects"], ["common", "side", "effects"]),
    "warning_signs": (["warning", "signs", "symptom", "danger", "emergency"], ["emergency", "serious", "risk", "help"]),
    "dose": (["dose", "dosage", "kidney", "egfr", "how much"], ["egfr", "kidney", "dose", "start"]),
    "interaction": (["interact", "together", "with ibuprofen", "combine", "mix"], ["nsaid", "reduce", "effect", "kidney"]),
    "avoid": (["avoid", "should not", "grapefruit", "alcohol"], ["avoid"]),
    "tips": (["tip", "manage", "managing", "help with"], ["tips", "heat", "stretch"]),
}

FRIENDLY_EXTRA = "Most people can safely take it with any other medicine."


def intent(question: str) -> str:
    q = question.lower()
    for name, (triggers, _) in INTENTS.items():
        if any(t in q for t in triggers):
            return name
    return "overview"


def sentences(text: str) -> list[str]:
    text = re.sub(r"<!--.*?-->", " ", text)  # comments are never shown to users
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if len(s.split()) >= 4]


def write_answer(question: str, hits, cfg, max_sentences: int = 3) -> tuple[str, list[str]]:
    """Return (answer, cited_chunk_ids). hits = [(score, chunk), ...] best first."""
    qt = set(tokens(question))
    boost = INTENTS.get(intent(question), ([], []))[1]
    named = [d for d in known_drugs() if d in question.lower()]
    if len(named) == 1:  # one drug asked about: never mix in text about another drug
        hits = [h for h in hits if h[1].drug == named[0]] or hits
    cands = []
    for rank, (_, c) in enumerate(hits[:2]):
        for i, s in enumerate(sentences(c.text[len(c.prefix):])):
            st = set(tokens(s))
            score = len(qt & st) + 2 * sum(1 for b in boost if b in s.lower()) - 0.1 * rank - 0.01 * i
            if score > 0.5:
                cands.append((score, rank, i, s, c.id))
    cands.sort(key=lambda x: -x[0])
    chosen = sorted(cands[:max_sentences], key=lambda x: (x[1], x[2]))
    cited, parts = [], []
    for _, _, _, s, cid in chosen:
        if cid not in cited:
            cited.append(cid)
        parts.append(f"{s} [{cited.index(cid) + 1}]")
    if cfg.answer_style == "friendly" and intent(question) == "side_effects":
        parts.append(FRIENDLY_EXTRA)
    return " ".join(parts), cited


# ---------------------------------------------------------------- judging
def claims(answer: str) -> list[str]:
    """One sentence = one claim. Citation markers are removed."""
    clean = re.sub(r"\[\d+\]", "", answer)
    label = re.compile(r"^(Safety update [\d-]+|[A-Z][a-z]+ \+ [a-z]+ \([a-z ]+\)):\s*")  # labels are not claims
    return [label.sub("", s.strip()) for s in re.split(r"(?<=[.!?])\s+", clean) if len(s.split()) >= 4]


def claim_supported(claim: str, evidence: list[str], threshold: float = 0.7) -> bool:
    ct = set(tokens(claim))
    if not ct:
        return True
    return any(len(ct & set(tokens(e))) / len(ct) >= threshold for e in evidence)


def faithfulness(answer: str, evidence: list[str]) -> tuple[float, list[tuple[str, bool]]]:
    cl = claims(answer)
    if not cl:
        return 1.0, []
    verdicts = [(c, claim_supported(c, evidence)) for c in cl]
    return sum(v for _, v in verdicts) / len(verdicts), verdicts
