"""MedGuide settings.

Two profiles ship with the lab:
  * "buggy"  - the release candidate you are asked to test (default)
  * "fixed"  - the same app after the team fixed every defect

Pick one with the environment variable MEDGUIDE_PROFILE=buggy|fixed
or with --profile on the command line.

Tester tip: read these settings the way you would read a release note.
Each one is a realistic setting a developer might get wrong.
"""
import os
from dataclasses import dataclass, replace


@dataclass(frozen=True)
class Settings:
    profile: str
    # ---------- ingestion ----------
    chunk_strategy: str          # "section" keeps one heading = one chunk, "fixed_words" cuts every N words
    chunk_words: int             # only used by "fixed_words"
    add_heading_to_chunk: bool   # prefix "Metformin - Warnings:" to chunk text
    index_archived_pages: bool   # should old page versions be searchable?
    # ---------- retrieval ----------
    top_k: int
    min_score: float             # below this the app should say "I don't know"
    # ---------- generation ----------
    answer_style: str            # "strict" = only facts from sources, "friendly" = adds reassuring sentences
    # ---------- agent ----------
    planner_max_entities: int    # 0 = no limit
    grader_checks_drug: bool     # grader must confirm the result is about the asked drug
    temperature: float           # >0 makes the planner creative (and random)
    enforce_step_limit: bool
    max_steps: int
    trust_tool_text: bool        # follow instructions found inside retrieved pages?
    refill_needs_approval: bool  # human approval before request_refill runs


BUGGY = Settings(
    profile="buggy",
    chunk_strategy="fixed_words", chunk_words=40, add_heading_to_chunk=False,
    index_archived_pages=True,
    top_k=5, min_score=1.0,
    answer_style="friendly",
    planner_max_entities=2, grader_checks_drug=False, temperature=0.7,
    enforce_step_limit=False, max_steps=14,
    trust_tool_text=True, refill_needs_approval=False,
)

FIXED = replace(
    BUGGY, profile="fixed",
    chunk_strategy="section", add_heading_to_chunk=True,
    index_archived_pages=False,
    answer_style="strict",
    planner_max_entities=0, grader_checks_drug=True, temperature=0.0,
    enforce_step_limit=True,
    trust_tool_text=False, refill_needs_approval=True,
)

HARD_STOP = 30  # emergency brake so a runaway agent cannot hang your laptop


def load(profile: str | None = None) -> Settings:
    name = (profile or os.environ.get("MEDGUIDE_PROFILE", "buggy")).lower()
    return FIXED if name == "fixed" else BUGGY
