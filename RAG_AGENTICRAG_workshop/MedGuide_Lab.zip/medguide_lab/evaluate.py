"""Run every golden test case and print a tester's scorecard.

  python evaluate.py                 # buggy release candidate
  python evaluate.py --profile fixed
  python evaluate.py --compare       # both, side by side
"""
import argparse
from medguide import config
from medguide.evals import golden, rag_case, agent_case, ingestion_report


def scorecard(profile):
    cfg = config.load(profile)
    ing = ingestion_report(cfg)
    rag = [rag_case(c, cfg) for c in golden("rag")]
    scored = [r for r in rag if r["recall@5"] is not None]
    ag = [agent_case(c, cfg) for c in golden("agent")]
    rel = next(a for a in ag if a["check"] == "reliability")
    return {
        "Ingestion: warning sections kept whole": "PASS" if not ing["split_warning_pages"] else f"FAIL {ing['split_warning_pages']}",
        "Ingestion: no archived pages indexed": "PASS" if not ing["archived_indexed"] else f"FAIL {ing['archived_indexed']}",
        "Retrieval: Recall@5": f"{sum(r['recall@5'] for r in scored)/len(scored):.0%}",
        "Retrieval: MRR": f"{sum(r['rr'] for r in scored)/len(scored):.2f}",
        "Generation: faithfulness (avg)": f"{sum(r['faithfulness'] for r in scored)/len(scored):.0%}",
        "Generation: keyword checks": f"{sum(r['keywords_ok'] for r in rag)}/{len(rag)}",
        "Generation: forbidden-phrase checks": f"{sum(r['forbidden_ok'] for r in rag)}/{len(rag)}",
        **{f"Agent {a['id']}: {a['check']}": "PASS" if a["ok"] else "FAIL" for a in ag if a["check"] != "reliability"},
        f"Agent {rel['id']}: reliability (pass^{rel['runs']})": f"{'PASS' if rel['ok'] else 'FAIL'} ({rel['passed']}/{rel['runs']} runs)",
    }, rag, ag


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", choices=["buggy", "fixed"])
    ap.add_argument("--compare", action="store_true")
    ap.add_argument("--details", action="store_true")
    a = ap.parse_args()
    profiles = ["buggy", "fixed"] if a.compare else [a.profile or config.load().profile]
    cards = {p: scorecard(p) for p in profiles}
    width = 48
    print("MedGuide test scorecard".ljust(width) + "".join(p.upper().ljust(26) for p in profiles))
    print("-" * (width + 26 * len(profiles)))
    for key in cards[profiles[0]][0]:
        print(key.ljust(width) + "".join(str(cards[p][0][key])[:25].ljust(26) for p in profiles))
    if a.details:
        for p in profiles:
            print(f"\n==== {p} details ====")
            for r in cards[p][1]:
                print(f"{r['id']} rank={r['rank']} faith={r['faithfulness']:.2f} kw={r['keywords_ok']} forbid={r['forbidden_ok']} unsupported={r['unsupported']}")
            for g in cards[p][2]:
                print({k: v for k, v in g.items() if k != "trace"})


if __name__ == "__main__":
    main()
