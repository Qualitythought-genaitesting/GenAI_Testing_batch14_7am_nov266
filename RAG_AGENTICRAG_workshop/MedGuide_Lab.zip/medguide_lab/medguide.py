"""MedGuide command line.

  python medguide.py ask "What are the common side effects of metformin?"
  python medguide.py ask "..." --mode agent --profile fixed
  python medguide.py ask "..." --json          # full trace as JSON
  python medguide.py serve                     # web UI on http://localhost:8000
"""
import argparse, json, sys
from medguide import config, rag, agent


def run(question, mode, profile, seed=None):
    cfg = config.load(profile)
    return agent.ask(question, cfg, seed=seed) if mode == "agent" else rag.ask(question, cfg)


def main():
    ap = argparse.ArgumentParser(description="MedGuide: RAG and agentic RAG practice app (training data, not medical advice)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("ask")
    a.add_argument("question")
    a.add_argument("--mode", choices=["rag", "agent"], default="rag")
    a.add_argument("--profile", choices=["buggy", "fixed"], default=None)
    a.add_argument("--seed", type=int, default=None)
    a.add_argument("--json", action="store_true")
    s = sub.add_parser("serve")
    s.add_argument("--port", type=int, default=8000)
    args = ap.parse_args()
    if args.cmd == "ask":
        t = run(args.question, args.mode, args.profile, args.seed)
        print(json.dumps(t.to_dict(), indent=2) if args.json else t.pretty())
    else:
        from medguide.web import serve
        serve(args.port)


if __name__ == "__main__":
    sys.exit(main())
