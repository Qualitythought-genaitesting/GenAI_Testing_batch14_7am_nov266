# MedGuide lab: test a RAG app and an agentic RAG app

MedGuide is a small drug-safety assistant built only for testing practice.
It runs in two modes:

| Mode | What it does | What you test |
|---|---|---|
| `rag` | One search over the drug pages, then one answer | The pages it finds and the answer it writes |
| `agent` | Plans, calls tools, grades results, retries, checks itself, then answers | The answer **and** the path it took |

Everything is offline: no API key, no internet, no installs. It needs only **Python 3.10 or newer**.
The "LLM" is a deterministic stand-in, so every trainee sees the same behaviour.

> Training data only. Not medical advice.

## 1. Run it

```bash
# Web test bench with a trace viewer (opens http://localhost:8000)
python medguide.py serve

# Command line
python medguide.py ask "What are the common side effects of metformin?"
python medguide.py ask "I take metformin. My doctor added lisinopril, and I use ibuprofen for back pain. Anything I should watch for?" --mode agent
python medguide.py ask "hello" --mode agent --json      # full trace as JSON
```

Windows: double-click `run_all.bat`. macOS/Linux: `bash run_all.sh`.

## 2. Two builds

| Build | How to pick it | Meaning |
|---|---|---|
| `buggy` (default) | `--profile buggy` or `MEDGUIDE_PROFILE=buggy` | The release candidate you are testing. It has **7 hidden defects**. |
| `fixed` | `--profile fixed` or `MEDGUIDE_PROFILE=fixed` | The same app after the fixes. Use it to confirm a fix. |

## 3. Run the automated tests

```bash
python -m unittest -v                         # tests the buggy build: expect failures
MEDGUIDE_PROFILE=fixed python -m unittest -v  # tests the fixed build: all pass
# Windows PowerShell:  $env:MEDGUIDE_PROFILE="fixed"; python -m unittest -v

python evaluate.py --compare                  # one scorecard, both builds side by side
```

Tests are grouped by **test point**:

| File | Test point | Checks |
|---|---|---|
| `test_1_ingestion.py` | 1 Ingestion | warnings never split, no archived pages, metadata on every chunk |
| `test_2_retrieval.py` | 2 Retrieval | Recall@5, MRR, old page never ranks first |
| `test_3_generation.py` | 3 Generation | faithfulness, keywords, forbidden phrases, "I don't know" |
| `test_4_agent_plan_and_tools.py` | A Plan, B Tools | every drug pair checked, no tools for "hello", right tool arguments |
| `test_5_agent_control_and_safety.py` | C Control, D Safety | step limit, hidden instructions ignored |
| `test_6_agent_reliability.py` | E Reliability | same question 10 times, 10 passes (pass^10) |

Golden test data lives in `tests/golden_rag.json` and `tests/golden_agent.json`. Add your own cases there.

## 4. Lab exercises

1. **Explore (15 min).** Open the test bench. Ask the sample questions in both modes. Read each trace. For every step, write down what you would check.
2. **Write test cases (20 min).** Using the template on the workshop slides, write 3 RAG and 3 agentic RAG test cases: input, expected result, oracle (exact check, metric, or judge).
3. **Bug hunt (30 min).** Run the tests on the buggy build. For each failure, find the step in the trace that shows the defect, and write a defect report.
4. **Confirm the fix (10 min).** Run the same tests on the fixed build and close your defects.
5. **Stretch.** Add one new golden case that the current tests miss.

## 5. Project map

```
medguide.py          command line + web server entry point
evaluate.py          scorecard for one or both builds
medguide/config.py   the two builds (read it like release notes)
medguide/corpus.py   ingestion: load pages, chunk, index (BM25 stands in for a vector DB)
medguide/rag.py      RAG mode
medguide/agent.py    agentic RAG mode: planner, tools, grader, rewrite loop, guard, self-check
medguide/tools.py    search, interaction checker, safety updates, request_refill (write action)
medguide/mockllm.py  offline LLM stand-in + faithfulness judge
medguide/trace.py    the trace (flight recorder)
data/                drug pages, interaction table, safety updates
tests/               golden datasets + unittest suite
```
