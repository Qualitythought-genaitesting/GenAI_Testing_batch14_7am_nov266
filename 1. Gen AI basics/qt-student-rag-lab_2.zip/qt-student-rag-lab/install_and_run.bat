@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title QT Student RAG Lab - one-click installer
REM Usage: double-click, or  install_and_run.bat bugs   (starts the chatbot with 3 planted bugs)

echo ============================================================
echo   QT Student RAG Lab - one-click install and run
echo ============================================================

set PY=
where python >nul 2>nul && set PY=python
if "%PY%"=="" (where py >nul 2>nul && set PY=py)
if "%PY%"=="" (
  echo [ERROR] Python 3.9+ not found. Install from https://www.python.org/downloads/ and tick "Add to PATH", then run this again.
  pause & exit /b 1
)
where node >nul 2>nul || (echo [ERROR] Node.js 20+ not found. Install the LTS from https://nodejs.org then run this again. & pause & exit /b 1)
where npm >nul 2>nul || (echo [ERROR] npm not found. Reinstall Node.js from https://nodejs.org & pause & exit /b 1)

if not exist "node_modules\promptfoo" (
  echo.
  echo [1/4] Installing promptfoo ^(first run only, about 1-2 minutes^)...
  call npm install --no-audit --no-fund || (echo [ERROR] npm install failed. Check your internet connection. & pause & exit /b 1)
) else (
  echo [1/4] promptfoo already installed.
)
if not exist results mkdir results
set PROMPTFOO_DISABLE_TELEMETRY=1
set PROMPTFOO_DISABLE_UPDATE=1

if /I "%~1"=="bugs" (set QT_BUGS=1 & echo [2/4] Starting chatbot WITH planted bugs...) else (set QT_BUGS=0 & echo [2/4] Starting chatbot ^(good build^)...)
start "QT chatbot" /min %PY% server.py

set /a tries=0
:wait
%PY% -c "import urllib.request,json;urllib.request.urlopen(urllib.request.Request('http://localhost:8100/chat',json.dumps({'question':'ping'}).encode(),{'content-type':'application/json'}),timeout=2)" >nul 2>nul
if errorlevel 1 (
  set /a tries+=1
  if !tries! GTR 20 (echo [ERROR] Chatbot did not start on port 8100. Is the port in use? & pause & exit /b 1)
  ping -n 2 127.0.0.1 >nul
  goto wait
)
echo       Chatbot is up at http://localhost:8100/chat

echo [3/4] Running the test suites...
call npx promptfoo eval -c promptfooconfig.yaml --no-cache -o results\main.json
call npx promptfoo eval -c promptfooconfig.answer-only.yaml --no-cache -o results\answer-only.json
call npx promptfoo eval -c promptfooconfig.json-reply.yaml --no-cache -o results\json-reply.json
echo.
echo Teaching suite below is EXPECTED to fail (reworded reference answers):
call npx promptfoo eval -c promptfooconfig.teaching.yaml --no-cache -o results\teaching.json

echo.
echo [4/4] Opening the results viewer in your browser. Press Ctrl+C here to stop.
call npx promptfoo view -y

taskkill /FI "WINDOWTITLE eq QT chatbot*" /T /F >nul 2>nul
pause
