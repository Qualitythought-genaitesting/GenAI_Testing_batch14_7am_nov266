#!/usr/bin/env bash
cd "$(dirname "$0")" && ./install_and_run.sh "$@"
