#!/usr/bin/env bash
# One-click install + run for macOS / Linux.   Usage: ./install_and_run.sh [bugs]
cd "$(dirname "$0")" || exit 1
echo "============================================================"
echo "  QT Student RAG Lab - one-click install and run"
echo "============================================================"
PY=$(command -v python3 || command -v python) || { echo "[ERROR] Python 3.9+ not found. Install from https://www.python.org/downloads/"; exit 1; }
command -v node >/dev/null || { echo "[ERROR] Node.js 20+ not found. Install the LTS from https://nodejs.org"; exit 1; }
command -v npm  >/dev/null || { echo "[ERROR] npm not found. Reinstall Node.js from https://nodejs.org"; exit 1; }
if [ ! -d node_modules/promptfoo ]; then
  echo "[1/4] Installing promptfoo (first run only, about 1-2 minutes)..."
  npm install --no-audit --no-fund || { echo "[ERROR] npm install failed. Check your internet connection."; exit 1; }
else
  echo "[1/4] promptfoo already installed."
fi
mkdir -p results
export PROMPTFOO_DISABLE_TELEMETRY=1 PROMPTFOO_DISABLE_UPDATE=1
if [ "$1" = "bugs" ]; then export QT_BUGS=1; echo "[2/4] Starting chatbot WITH planted bugs..."; else export QT_BUGS=0; echo "[2/4] Starting chatbot (good build)..."; fi
"$PY" server.py >/tmp/qt-chatbot.log 2>&1 &
SERVER=$!
trap 'kill $SERVER 2>/dev/null' EXIT INT TERM
for i in $(seq 1 20); do
  "$PY" - <<'PYEOF' >/dev/null 2>&1 && break
import urllib.request, json
urllib.request.urlopen(urllib.request.Request('http://localhost:8100/chat', json.dumps({'question':'ping'}).encode(), {'content-type':'application/json'}), timeout=2)
PYEOF
  sleep 1
  [ "$i" = 20 ] && { echo "[ERROR] Chatbot did not start on port 8100 (port in use?)"; exit 1; }
done
echo "      Chatbot is up at http://localhost:8100/chat"
echo "[3/4] Running the test suites..."
npx promptfoo eval -c promptfooconfig.yaml --no-cache -o results/main.json
npx promptfoo eval -c promptfooconfig.answer-only.yaml --no-cache -o results/answer-only.json
npx promptfoo eval -c promptfooconfig.json-reply.yaml --no-cache -o results/json-reply.json
echo; echo "Teaching suite below is EXPECTED to fail (reworded reference answers):"
npx promptfoo eval -c promptfooconfig.teaching.yaml --no-cache -o results/teaching.json
echo; echo "[4/4] Opening the results viewer in your browser. Press Ctrl+C to stop."
npx promptfoo view -y
