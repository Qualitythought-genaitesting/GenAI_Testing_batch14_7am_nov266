# QT Student RAG - black-box promptfoo lab

## One-click install and run
- Windows: double-click `install_and_run.bat` (add `bugs` as an argument to start the chatbot with 3 planted bugs)
- macOS: double-click `install_and_run.command` (or run `./install_and_run.sh`)
- Linux: `./install_and_run.sh`
Needs Python 3.9+ and Node.js 20+ installed. It installs promptfoo (first run only), starts the stand-in chatbot on port 8100, runs all suites, and opens the results viewer.

## Manual steps
1. Start the stand-in chatbot: `python3 server.py`  (port 8100; `QT_BUGS=1 python3 server.py` plants 3 bugs)
2. Run: `promptfoo eval -c promptfooconfig.yaml` (also: .answer-only, .json-reply, .teaching)
3. To test the REAL chatbot, change `url:` (and body/transformResponse if its reply shape differs) in the config files.
Data: kb.json is built from qualitythought.in pages (home, courses, contact, skill-to-job). Some facts are summarised or conflict on the site; verify before publishing.
Judge assertions (llm-rubric, factuality, similar, context-*) are shown in the deck as syntax only; they need a judge model key.

## Framework and documents
- `prompts/qt-prompt.txt` holds the prompt; `promptfooconfig.yaml` holds URL, inputs and defaults; `tests/*.yaml` hold the tests.
- `docs/` : requirement document, manual test plan, promptfoo automation test plan, manual/blue/red test cases (xlsx).
- `presentations/QT_RAG_Promptfoo_Customised.pptx` : teaching deck.

## RAG stage suites and red team
- `npm run eval:retrieval | eval:augmentation | eval:generation` : separate suites per RAG stage (tests/retrieval.yaml, augmentation.yaml, generation.yaml), default assertions only.
- `npm run eval:redteam-static` : 29 offline attacks (no key). `promptfooconfig.redteam.yaml` is the generated red-team config (needs a model key; passes `promptfoo validate`).
- `presentations/` : Deck 1 Retrieval, 2 Augmentation, 3 Generation, 4 Manual red team, 5 Automated red team, 6 Red-team reports and frameworks.
Results (good / bugged build): retrieval 12/12 / 11, augmentation 10/10 / 8, generation 12/12 / 10, red-team offline 22/29 / 15.
