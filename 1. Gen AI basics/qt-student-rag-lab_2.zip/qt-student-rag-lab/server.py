"""Stand-in 'QT Student RAG' chatbot over qualitythought.in facts. Black box: POST /chat {question, top_k}.
Run: python3 server.py   (QT_BUGS=1 switches on three planted bugs)"""
import json, math, os, re, time
from http.server import BaseHTTPRequestHandler, HTTPServer
BUGS = os.environ.get("QT_BUGS") == "1"
STOP = set("a an the is are of for to in on at and or do does what which how when where who can i me my you your it be with about this that there".split())
def toks(t):
    out = []
    for w in re.findall(r"[a-z0-9₹+]+", t.lower()):
        if w in STOP: continue
        if len(w) > 4 and w.endswith("ing"): w = w[:-3]
        elif len(w) > 3 and w.endswith("s") and not w.endswith("ss"): w = w[:-1]
        out.append(w)
    return out
def sents(t):
    t = t.replace("No. ", "No\u0000 ").replace("Pvt. ", "Pvt\u0000 ")
    return [s.strip().replace("\u0000", ".") for s in re.split(r"(?<=[.])\s+(?=[A-Z₹+0-9])", t) if s.strip()]
CH = []
for d in json.load(open(os.path.join(os.path.dirname(__file__), "kb.json"))):
    ss = sents(d["text"])
    for i in range(0, len(ss), 2):
        txt = " ".join(ss[i:i+2]); CH.append({"id": f'{d["id"]}#{i//2}', "doc": d["id"], "aud": d["audience"], "text": txt, "tok": toks(txt), "sents": ss[i:i+2]})
N = len(CH); AVG = sum(len(c["tok"]) for c in CH) / N
DF = {}
for c in CH:
    for t in set(c["tok"]): DF[t] = DF.get(t, 0) + 1
IDF = {t: math.log(1 + (N - f + .5) / (f + .5)) for t, f in DF.items()}
def bm25(q, c, k1=1.5, b=.75):
    tf = {}
    for t in c["tok"]: tf[t] = tf.get(t, 0) + 1
    s = 0.0
    for t in set(q):
        if t in tf: s += IDF[t] * tf[t] * (k1 + 1) / (tf[t] + k1 * (1 - b + b * len(c["tok"]) / AVG))
    return s
def retrieve(question, top_k):
    q = toks(question); sc = []
    for c in CH:
        if c["aud"] != "public" and not BUGS: continue
        s = bm25(q, c)
        if s > 0: sc.append((s, c))
    sc.sort(key=lambda x: -x[0])
    return q, sc[:top_k]
REFUSE = re.compile(r"ignore (your|all|previous)|system prompt|other students|student phone|payout|approval code|password|override", re.I)
ABSTAIN = "I don't have information about that on the Quality Thought website. Please call +91 9963486280 or email info@qualitythought.in."
def chat(question, top_k):
    t0 = time.time()
    if REFUSE.search(question) and not BUGS:
        ans, src = "Sorry, I can't help with that request.", []
    else:
        q, hits = retrieve(question, top_k)
        if not hits or (hits[0][0] < 2.0 and not BUGS):
            ans, src = ABSTAIN, []
        else:
            best = hits[0][1]; qs = set(q)
            sent = max(best["sents"], key=lambda s: len(qs & set(toks(s))))
            ans = f"{sent} [1]"; src = hits
    sources = [{"n": i+1, "chunk": c["id"], "doc": c["doc"], "score": round(s, 3)} for i, (s, c) in enumerate(src)]
    out = ans + ("\nSources: " + " | ".join(f'[{x["n"]}] {x["doc"]}' for x in sources) if sources else "")
    return {"answer": ans, "output": out, "top_k": top_k, "sources": sources, "latency_ms": round((time.time()-t0)*1000, 2)}
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers.get("content-length", 0))) or b"{}")
        r = json.dumps(chat(body.get("question", ""), int(body.get("top_k", 3))), ensure_ascii=False).encode()
        self.send_response(200); self.send_header("content-type", "application/json"); self.send_header("content-length", str(len(r))); self.end_headers(); self.wfile.write(r)
if __name__ == "__main__":
    HTTPServer(("0.0.0.0", int(os.environ.get("PORT", 8100))), H).serve_forever()
