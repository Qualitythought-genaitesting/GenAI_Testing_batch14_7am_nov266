/* =====================================================================
 *   ___  _____   QUALITY THOUGHT  |  Student Helpdesk RAG
 *  / _ \|_   _|  Transforming Dreams! Redefining Future!
 * | (_) | | |
 *  \__\_\ |_|    File: assertions/rag_metrics.js
 * ---------------------------------------------------------------------
 *  Deterministic RAG metrics used by promptfoo "javascript" assertions:
 *
 *    - type: javascript
 *      value: file://assertions/rag_metrics.js:hitAtK   <- file : function
 *      config: { k: 3 }                                <- read as context.config
 *      metric: hit_rate_at_3                           <- name in the report
 *
 *  Every function receives:
 *    output   -> the answer text (string) returned by the app
 *    context  -> { vars, config, providerResponse: { metadata } }
 *                metadata = the full answer contract from /api/ask
 *                (retrieved pages, citations, context text, fallback flag)
 *
 *  Every function returns { pass, score (0..1), reason }.
 *  No LLM judge anywhere: same output in, same verdict out.
 *
 *  Test data comes from the CSV / YAML vars:
 *    expected_docs = "DOC-102"            one right page
 *    expected_docs = "DOC-101;DOC-102"    question needs two pages
 *    expected_docs = "NONE"               out-of-scope: nothing should match
 * ===================================================================== */

// ---------- small helpers -------------------------------------------------
const meta = (context) => (context && context.providerResponse && context.providerResponse.metadata) || {};

/** "DOC-101;DOC-102" -> ["DOC-101","DOC-102"]   "NONE" -> [] */
function expectedDocs(context) {
  const raw = String((context.vars && context.vars.expected_docs) || 'NONE').trim();
  if (!raw || raw.toUpperCase() === 'NONE') return [];
  return raw.split(/[;,|\s]+/).filter(Boolean);
}

const retrievedIds = (context) => (meta(context).retrieved || []).map((p) => p.id);
const result = (pass, score, reason) => ({ pass, score: Number(score.toFixed(3)), reason });

/** Out-of-scope questions: the right behaviour is "retrieve nothing, use the fallback". */
function outOfScope(context, label) {
  const m = meta(context);
  const ok = m.fallback === true && retrievedIds(context).length === 0;
  return result(ok, ok ? 1 : 0, ok
    ? `${label}: out-of-scope question, nothing retrieved, fallback used (correct)`
    : `${label}: out-of-scope question but retrieved [${retrievedIds(context)}] fallback=${m.fallback}`);
}

/* =====================================================================
 *  RETRIEVAL METRICS  (did the librarian bring the right pages?)
 * ===================================================================== */

/**
 * Hit@K (hit rate): is at least one expected page inside the top K?
 * The most important retrieval metric. If this fails, the LLM never
 * saw the right facts, so fix the retriever / knowledge base first.
 */
function hitAtK(output, context) {
  const k = (context.config && context.config.k) || 3;
  const expected = expectedDocs(context);
  if (!expected.length) return outOfScope(context, `Hit@${k}`);
  const topK = retrievedIds(context).slice(0, k);
  const hit = expected.some((id) => topK.includes(id));
  return result(hit, hit ? 1 : 0, `Hit@${k}: expected [${expected}] top${k}=[${topK}]`);
}

/** Top-1 accuracy: is the best-ranked page one of the expected pages? */
function topOneAccuracy(output, context) {
  const expected = expectedDocs(context);
  if (!expected.length) return outOfScope(context, 'Top-1');
  const first = retrievedIds(context)[0];
  const ok = expected.includes(first);
  return result(ok, ok ? 1 : 0, `Top-1: expected one of [${expected}] got ${first || 'nothing'}`);
}

/**
 * Reciprocal rank (averaged over all tests = MRR, Mean Reciprocal Rank).
 * Rank 1 -> 1.0   rank 2 -> 0.5   rank 3 -> 0.33   not found -> 0
 * Passes when the first expected page is at rank 1 or 2 (score >= 0.5).
 */
function reciprocalRank(output, context) {
  const expected = expectedDocs(context);
  if (!expected.length) return outOfScope(context, 'RR');
  const ids = retrievedIds(context);
  const pos = ids.findIndex((id) => expected.includes(id));
  const rr = pos === -1 ? 0 : 1 / (pos + 1);
  const min = (context.config && context.config.min) || 0.5;
  return result(rr >= min, rr, `Reciprocal rank = ${rr.toFixed(2)} (first expected page at rank ${pos === -1 ? 'none' : pos + 1})`);
}

/**
 * Context recall: what fraction of the expected pages were retrieved?
 * Matters most for multi-page questions ("fee AND refund").
 * 1 of 2 pages found -> 0.5 -> the answer will be half right.
 */
function contextRecall(output, context) {
  const expected = expectedDocs(context);
  if (!expected.length) return outOfScope(context, 'Recall');
  const ids = retrievedIds(context);
  const found = expected.filter((id) => ids.includes(id));
  const recall = found.length / expected.length;
  return result(recall === 1, recall, `Context recall = ${found.length}/${expected.length} expected pages retrieved`);
}

/**
 * Context precision: what fraction of the retrieved pages are relevant?
 * Low precision = noisy context, which invites the LLM to mix in
 * unrelated facts. Default pass mark 0.3 (config.min).
 */
function contextPrecision(output, context) {
  const expected = expectedDocs(context);
  if (!expected.length) return outOfScope(context, 'Precision');
  const ids = retrievedIds(context);
  if (!ids.length) return result(false, 0, 'Context precision: nothing retrieved');
  const relevant = ids.filter((id) => expected.includes(id)).length;
  const precision = relevant / ids.length;
  const min = (context.config && context.config.min) || 0.3;
  return result(precision >= min, precision, `Context precision = ${relevant}/${ids.length} retrieved pages are relevant`);
}

/* =====================================================================
 *  GENERATION METRICS  (did the writer use the pages honestly?)
 * ===================================================================== */

/**
 * Citation grounding: every [DOC-xxx] in the answer must be a page that
 * was actually retrieved. Catches invented citations.
 * In-scope answers must cite at least one page.
 */
function citationGrounding(output, context) {
  const m = meta(context);
  const cited = [...new Set((String(output).match(/DOC-\d{3}/g) || []))];
  const ids = retrievedIds(context);
  if (m.fallback) {
    const ok = cited.length === 0;
    return result(ok, ok ? 1 : 0, ok ? 'Fallback answer has no citations (correct)' : `Fallback answer cites [${cited}]`);
  }
  if (!cited.length) return result(false, 0, 'Answer has no [DOC-xxx] citation');
  const fake = cited.filter((id) => !ids.includes(id));
  const score = (cited.length - fake.length) / cited.length;
  return result(fake.length === 0, score, fake.length ? `Cited but NOT retrieved: [${fake}]` : `All citations [${cited}] were retrieved`);
}

/** Citation accuracy: the answer cites at least one of the expected pages. */
function citationAccuracy(output, context) {
  const expected = expectedDocs(context);
  const cited = String(output).match(/DOC-\d{3}/g) || [];
  if (!expected.length) {
    const ok = cited.length === 0;
    return result(ok, ok ? 1 : 0, ok ? 'Out-of-scope answer cites nothing (correct)' : `Out-of-scope answer cites [${cited}]`);
  }
  const ok = expected.some((id) => cited.includes(id));
  return result(ok, ok ? 1 : 0, `Expected a citation of [${expected}], answer cites [${[...new Set(cited)]}]`);
}

/**
 * Numeric faithfulness (a deterministic hallucination check):
 * every number in the answer (fees, days, times, phone) must also
 * appear in the retrieved context. "INR 25,000" when the page says
 * "INR 30,000" fails here even if it sounds plausible.
 */
function numericFaithfulness(output, context) {
  const numbersIn = (text) => (String(text)
    .replace(/DOC-\d{3}/g, ' ')                 // ignore page IDs
    .match(/\d[\d,]*(\.\d+)?/g) || [])
    .map((n) => n.replace(/,/g, '').replace(/\.0+$/, ''));
  const source = new Set(numbersIn(meta(context).context || ''));
  const answerNumbers = [...new Set(numbersIn(output))];
  if (!answerNumbers.length) return result(true, 1, 'No numbers in the answer to verify');
  const unsupported = answerNumbers.filter((n) => !source.has(n));
  const score = (answerNumbers.length - unsupported.length) / answerNumbers.length;
  return result(unsupported.length === 0, score, unsupported.length
    ? `Numbers NOT found in retrieved pages: ${unsupported.join(', ')}`
    : `All numbers [${answerNumbers.join(', ')}] appear in the retrieved pages`);
}

/** Citation position: the citation closes the answer, e.g. "... batch. [DOC-102]" */
function citationAtEnd(output) {
  const ok = /\[DOC-\d{3}\]\.?\s*$/.test(String(output).trim());
  return result(ok, ok ? 1 : 0, ok ? 'Answer ends with a citation' : 'Answer does not end with a [DOC-xxx] citation');
}

module.exports = {
  hitAtK, topOneAccuracy, reciprocalRank, contextRecall, contextPrecision,
  citationGrounding, citationAccuracy, numericFaithfulness, citationAtEnd,
};
