# =====================================================================
#   ___  _____   QUALITY THOUGHT  |  Student Helpdesk RAG
#  / _ \|_   _|  Transforming Dreams! Redefining Future!
# | (_) | | |
#  \__\_\ |_|    File: assertions/rag_metrics.py
# ---------------------------------------------------------------------
#  The SAME deterministic RAG metrics as rag_metrics.js, in Python.
#  Use them from YAML with type: python
#
#    - type: python
#      value: file://assertions/rag_metrics.py:hit_at_k   <- file : function
#      config: { k: 3 }                                   <- context["config"]
#      metric: hit_rate_at_3                              <- name in the report
#
#  Every function receives:
#    output   -> the answer text (str)
#    context  -> dict with "vars", "config" and "providerResponse"
#                context["providerResponse"]["metadata"] = the app's JSON
#                (retrieved pages, citations, context text, fallback flag)
#
#  Every function returns {"pass": bool, "score": 0..1, "reason": str}.
#  Standard library only: nothing to pip install. Needs Python 3.8+.
# =====================================================================
import re


# ---------- small helpers ---------------------------------------------
def _meta(context):
    """The app's answer contract (JSON) for this test."""
    return (context.get("providerResponse") or {}).get("metadata") or {}


def _config(context, key, default):
    return (context.get("config") or {}).get(key, default)


def _expected_docs(context):
    """'DOC-101;DOC-102' -> ['DOC-101', 'DOC-102']   'NONE' -> []"""
    raw = str((context.get("vars") or {}).get("expected_docs") or "NONE").strip()
    if not raw or raw.upper() == "NONE":
        return []
    return [d for d in re.split(r"[;,|\s]+", raw) if d]


def _retrieved_ids(context):
    return [p["id"] for p in _meta(context).get("retrieved") or []]


def _result(passed, score, reason):
    return {"pass": bool(passed), "score": round(float(score), 3), "reason": reason}


def _out_of_scope(context, label):
    """Out-of-scope question: correct = nothing retrieved and the fallback used."""
    ids = _retrieved_ids(context)
    ok = _meta(context).get("fallback") is True and not ids
    if ok:
        return _result(True, 1, f"{label}: out-of-scope question, nothing retrieved, fallback used (correct)")
    return _result(False, 0, f"{label}: out-of-scope question but retrieved {ids}")


# =====================================================================
#  RETRIEVAL METRICS
# =====================================================================
def hit_at_k(output, context):
    """Hit@K: is at least one expected page in the top K? (default K = 3)"""
    k = _config(context, "k", 3)
    expected = _expected_docs(context)
    if not expected:
        return _out_of_scope(context, f"Hit@{k}")
    top_k = _retrieved_ids(context)[:k]
    hit = any(doc in top_k for doc in expected)
    return _result(hit, 1 if hit else 0, f"Hit@{k}: expected {expected} top{k}={top_k}")


def top_one_accuracy(output, context):
    """Top-1: is the best-ranked page one of the expected pages?"""
    expected = _expected_docs(context)
    if not expected:
        return _out_of_scope(context, "Top-1")
    ids = _retrieved_ids(context)
    first = ids[0] if ids else None
    ok = first in expected
    return _result(ok, 1 if ok else 0, f"Top-1: expected one of {expected}, got {first or 'nothing'}")


def reciprocal_rank(output, context):
    """1 / rank of the first expected page (averaged over tests = MRR)."""
    expected = _expected_docs(context)
    if not expected:
        return _out_of_scope(context, "RR")
    ids = _retrieved_ids(context)
    rank = next((i + 1 for i, doc in enumerate(ids) if doc in expected), None)
    rr = 1 / rank if rank else 0
    minimum = _config(context, "min", 0.5)
    return _result(rr >= minimum, rr, f"Reciprocal rank = {rr:.2f} (first expected page at rank {rank or 'none'})")


def context_recall(output, context):
    """Share of the expected pages that were retrieved."""
    expected = _expected_docs(context)
    if not expected:
        return _out_of_scope(context, "Recall")
    ids = _retrieved_ids(context)
    found = [doc for doc in expected if doc in ids]
    recall = len(found) / len(expected)
    return _result(recall == 1, recall, f"Context recall = {len(found)}/{len(expected)} expected pages retrieved")


def context_precision(output, context):
    """Share of the retrieved pages that are relevant (default pass mark 0.3)."""
    expected = _expected_docs(context)
    if not expected:
        return _out_of_scope(context, "Precision")
    ids = _retrieved_ids(context)
    if not ids:
        return _result(False, 0, "Context precision: nothing retrieved")
    relevant = sum(1 for doc in ids if doc in expected)
    precision = relevant / len(ids)
    minimum = _config(context, "min", 0.3)
    return _result(precision >= minimum, precision, f"Context precision = {relevant}/{len(ids)} retrieved pages are relevant")


# =====================================================================
#  GENERATION METRICS
# =====================================================================
def citation_grounding(output, context):
    """Every [DOC-xxx] in the answer must be a page that was retrieved."""
    cited = sorted(set(re.findall(r"DOC-\d{3}", str(output))))
    ids = _retrieved_ids(context)
    if _meta(context).get("fallback"):
        ok = not cited
        return _result(ok, 1 if ok else 0, "Fallback answer has no citations (correct)" if ok else f"Fallback answer cites {cited}")
    if not cited:
        return _result(False, 0, "Answer has no [DOC-xxx] citation")
    fake = [doc for doc in cited if doc not in ids]
    score = (len(cited) - len(fake)) / len(cited)
    return _result(not fake, score, f"Cited but NOT retrieved: {fake}" if fake else f"All citations {cited} were retrieved")


def citation_accuracy(output, context):
    """The answer cites at least one of the expected pages."""
    expected = _expected_docs(context)
    cited = re.findall(r"DOC-\d{3}", str(output))
    if not expected:
        ok = not cited
        return _result(ok, 1 if ok else 0, "Out-of-scope answer cites nothing (correct)" if ok else f"Out-of-scope answer cites {cited}")
    ok = any(doc in cited for doc in expected)
    return _result(ok, 1 if ok else 0, f"Expected a citation of {expected}, answer cites {sorted(set(cited))}")


def _numbers(text):
    """All numbers in a text, commas removed, page IDs ignored: 'INR 30,000' -> '30000'"""
    text = re.sub(r"DOC-\d{3}", " ", str(text))
    return [re.sub(r"\.0+$", "", n.replace(",", "")) for n in re.findall(r"\d[\d,]*(?:\.\d+)?", text)]


def numeric_faithfulness(output, context):
    """Every number in the answer must also appear in the retrieved pages."""
    source = set(_numbers(_meta(context).get("context") or ""))
    in_answer = sorted(set(_numbers(output)))
    if not in_answer:
        return _result(True, 1, "No numbers in the answer to verify")
    unsupported = [n for n in in_answer if n not in source]
    score = (len(in_answer) - len(unsupported)) / len(in_answer)
    if unsupported:
        return _result(False, score, f"Numbers NOT found in retrieved pages: {', '.join(unsupported)}")
    return _result(True, score, f"All numbers {in_answer} appear in the retrieved pages")


def citation_at_end(output, context):
    """The citation closes the answer, e.g. '... batch. [DOC-102]'"""
    ok = re.search(r"\[DOC-\d{3}\]\.?\s*$", str(output).strip()) is not None
    return _result(ok, 1 if ok else 0, "Answer ends with a citation" if ok else "Answer does not end with a [DOC-xxx] citation")


# =====================================================================
#  BONUS: things Python makes easy
# =====================================================================
def mentions_refund_window(output, context):
    """Case-insensitive regex: Python has flags, promptfoo's regex type does not."""
    ok = re.search(r"\b7\s+days\b", str(output), re.IGNORECASE) is not None
    return _result(ok, 1 if ok else 0, "mentions 7 days" if ok else "no 7-day refund window")
