#!/usr/bin/env bash
# =====================================================================
#  QUALITY THOUGHT | Student Helpdesk RAG - one-click run (macOS / Linux)
#  Transforming Dreams! Redefining Future!
#  Same steps as run.bat:  bash run.sh
# =====================================================================
set -u
cd "$(dirname "$0")"
export PROMPTFOO_DISABLE_TELEMETRY=1 PROMPTFOO_DISABLE_UPDATE=1 PROMPTFOO_DISABLE_SHARING=1
open_url() { (command -v open >/dev/null && open "$1") || (command -v xdg-open >/dev/null && xdg-open "$1") || echo "  Open $1"; }

echo "=============================================================="
echo "   QUALITY THOUGHT | Student Helpdesk RAG + Promptfoo tests"
echo "   Transforming Dreams! Redefining Future!"
echo "=============================================================="
echo "[1/6] Node.js";   command -v node >/dev/null || { echo "Install Node.js 22.22+ from https://nodejs.org"; exit 1; }
node scripts/check-node.js || exit 1
node scripts/check-python.js
echo "[2/6] Settings";  [ -f .env ] || node scripts/setup-env.js || exit 1
echo "[3/6] Packages";  { [ -f node_modules/promptfoo/package.json ] && [ -f node_modules/js-yaml/package.json ]; } || npm install --no-audit --no-fund || exit 1
echo "[4/6] App"
if ! node scripts/wait-for-server.js --check; then node app/server.js > results/server.log 2>&1 & echo "  server log: results/server.log"; fi
node scripts/wait-for-server.js || exit 1
open_url http://localhost:3000
echo "[5/6] Tests"
mkdir -p results
npx promptfoo eval -c promptfooconfig.yaml --no-cache -o results/latest-results.json -o results/promptfoo-results.html
echo "  promptfoo exit code $? (0 = all passed, 100 = some failed; [DEMO-RED] fails on purpose)"
echo "[6/6] Report"
node scripts/make-report.js && open_url http://localhost:3000/report
open_url "http://localhost:3000/#lab"
echo "Test lab: http://localhost:3000/#lab   Settings: http://localhost:3000/#settings"
echo "Promptfoo dashboard: npx promptfoo view --yes"
