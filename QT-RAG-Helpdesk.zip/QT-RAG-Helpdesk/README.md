<p align="left"><img src="assets/qt-logo.png" alt="Quality Thought" width="240"></p>

# Quality Thought Student Helpdesk RAG, tested with promptfoo

*Transforming Dreams! Redefining Future!*

A small Retrieval-Augmented Generation (RAG) helpdesk for Quality Thought students, plus an end-to-end **deterministic** promptfoo test suite covering retrieval and generation. Runs on your own laptop with a free Groq API key.

## Quick start (Windows)

1. Install **Node.js 22.22 or newer** (LTS) from https://nodejs.org
2. Get a free Groq key at https://console.groq.com/keys
3. Unzip this folder and double-click **`run.bat`**

`run.bat` checks Node.js, asks for your Groq key (Enter = offline demo mode), installs promptfoo, starts the app, runs all tests and opens:

| What | Where |
|---|---|
| Student chat | http://localhost:3000/#chat |
| **Test lab**: pick tests and metrics, run, see results | http://localhost:3000/#lab |
| **Settings**: Groq key, model, mode | http://localhost:3000/#settings |
| Quality Thought test report (full suite) | http://localhost:3000/report |
| promptfoo dashboard | http://localhost:15500 |

No key yet? Press Enter at the prompt and paste it later on the Settings page.

macOS / Linux: `bash run.sh`. Re-run tests later: `npm test` then `npm run report`.

**Expected result:** every test passes except **`[DEMO-RED]`**, which fails on purpose to show what a failure looks like (it expects "15 days"; the policy says 7).

## Settings page

Everything a tester changes, in one place (`localhost:3000/#settings`). Each card saves to `.env` and applies to the running app at once, with no restart.

| Card | Settings | Notes |
|---|---|---|
| Groq API key | Key | Checked with Groq before saving; a wrong key is rejected. Remove key switches to offline mode. The full key is never shown again. |
| Model | Groq or offline mode, main model, backup model, **temperature** (0 to 2), **max tokens** (50 to 1024) | Keep temperature at **0** for testing: above 0 the wording varies between runs and regex checks can flicker. |
| Retriever | Pages per answer (1 to 10), minimum BM25 score (0 to 20) | These drive Hit@3, MRR, precision and the off-topic fallback. |
| Try these settings | One question | Shows the answer, model, temperature, pages used and tokens before you run the suite. |

Every answer's JSON includes a `settings` block, and every Test lab run records the temperature, max tokens and retriever settings it used, shown in the results header and in *Previous runs*. That lets you compare runs fairly, for example temperature 0 against 0.7.

## Test lab: run what a customer asks for

1. **Tests**: tick test files, or open a file and tick single tests. **Add a test** saves a new row to `tests/my_tests.csv`; **Upload file** copies a customer's CSV or YAML into `tests/` (see `tests/example_customer_request.yaml`).
2. **Metrics**: pick any metrics, or a preset: Retrieval only, Generation only, Safety and speed. A metric is skipped for a test that lacks the var it needs (for example no `must_match`), rather than failing it.
3. **Run**: optionally keep each test's own assertions and filter by text. The plan shows how many tests and checks will run. Progress, promptfoo output and a Stop button appear while it runs.

Results show only the chosen metrics: one score card per metric, a test-by-metric pass/fail matrix with a *Failed only* filter, and per-test details (answer, pages retrieved, why each check failed). Download the JSON results, the promptfoo HTML report or the exact config that ran. Every run is kept in `results/runs/<run-id>/` and listed under *Previous runs*; it also shows in `npx promptfoo view`.

Behind the scenes the app reads the metric assertions from `promptfooconfig.yaml` (the single source of truth), writes `promptfooconfig.ui-run.yaml` with only the selected checks, and runs `promptfoo eval`. Settings and test runs only work from this computer (localhost).

## JavaScript or Python assertions

Every custom metric exists in both languages, with the same names, inputs and results:

| | JavaScript | Python |
|---|---|---|
| Metric code | `assertions/rag_metrics.js` | `assertions/rag_metrics.py` |
| Suite config | `promptfooconfig.yaml` | `promptfooconfig.python.yaml` |
| Showcase tests | `tests/qt_assertion_showcase.yaml` | `tests/qt_python_showcase.yaml` |
| Run | `npm test` | `npm run test:python` |

In the Test lab, choose **Metric code: JavaScript or Python**. Python needs Python 3.8+ on the PATH (standard library only, nothing to pip install); the app detects it and disables the Python option if it is missing. A python assertion can be one expression (`"'[DOC-105]' in output"`), an inline block ending in `return`, or a function in a file (`file://assertions/rag_metrics.py:hit_at_k`; without `:name` promptfoo calls `get_assert(output, context)`). Both editions were checked to give identical scores.

## LLM-as-a-judge (model-graded) assertions

Deterministic checks prove shapes and numbers. A **judge LLM** checks meaning: is every claim supported by the pages, does the answer agree with a reference, is the tone right. Training decks: `docs/QT_LLM_as_a_Judge_Assertions.pptx` and `docs/QT_More_Model_Graded_Assertions.pptx` (select-best, similar, classifier, moderation, search-rubric, not-llm-rubric, rubricPrompt, --grader).

| File | What it is |
|---|---|
| `promptfooconfig.llm-judge.yaml` | Judge suite: context-faithfulness, context-relevance, context-recall, factuality, llm-rubric on every test |
| `judge/groq_judge.js` | The judge (promptfoo "grader"): sends grading prompts to Groq at temperature 0, with retries |
| `tests/qt_judge_dataset.csv` | 8 questions with `reference_answer` |
| `tests/qt_judge_showcase.yaml` | One test per judge: llm-rubric, factuality, model-graded-closedqa, g-eval, and a hybrid regex + judge test |

Run: `npm run test:judge` then `npm run report:judge`, or pick the **LLM judge** metrics in the Test lab. The judge needs a Groq key and makes 1 or 2 extra Groq calls per check (about 60 calls for the whole judge suite), so it is slower than the deterministic suite and uses more free quota. Choose the judge model on the Settings page. Judge scores can vary a little between runs: keep rubrics specific and use `--repeat 3` before trusting a result.

## Project map

| Path | What it is | Edit with |
|---|---|---|
| `knowledge_base/*.txt` | 12 helpdesk FAQ pages (ID, TITLE, KEYWORDS, body) | Notepad |
| `prompts/system_prompt.txt` | LLM instructions used by the app | Notepad |
| `prompts/student_question.txt` | promptfoo prompt template `{{question}}` | Notepad |
| `prompts/fallback_message.txt` | Safe answer for off-topic questions | Notepad |
| `tests/qt_golden_dataset.csv` | 15 golden questions with expected page and regex facts | Excel / Notepad |
| `tests/qt_assertion_showcase.yaml` | 10 tests, one per assertion family, fully commented | Any editor |
| `assertions/rag_metrics.js` | Retrieval + generation metric functions | Code editor |
| `assertions/rag_metrics.py` | The same metrics in Python | Code editor |
| `promptfooconfig.python.yaml` | The suite with Python metrics | Any editor |
| `tests/qt_python_showcase.yaml` | Three ways to write python assertions | Any editor |
| `promptfooconfig.yaml` | Suite config: provider, tests, defaultTest metrics | Any editor |
| `app/` | Node.js server, BM25 retriever, Groq generator | Code editor |
| `app/admin/` | Settings, test catalog and Test lab runner | Code editor |
| `app/public/` | Chat, Test lab and Settings pages | Code editor |
| `tests/example_customer_request.yaml` | Example of a customer test file to upload | Any editor |
| `scripts/` | Setup, server wait, report builder | Code editor |
| `docs/` | Training decks (.pptx): deterministic assertions, LLM-as-a-judge, more model-graded assertions; and a sample report | PowerPoint |

## How the app works

`POST /api/ask {"question": "..."}`
1. **Retrieve**: BM25 keyword search ranks the knowledge-base pages; pages scoring under `QT_MIN_SCORE` are dropped. Nothing left = fixed fallback, no LLM call.
2. **Augment**: the top 3 pages are pasted into `system_prompt.txt`.
3. **Generate**: Groq (`llama-3.3-70b-versatile`, temperature 0) answers and cites pages like `[DOC-102]`.

The reply is a JSON *answer contract*: `answer, citations, retrieved, context, fallback, model, latency_ms, usage, cost`. promptfoo calls this same endpoint, so every test is end-to-end.

## What the tests measure

Every test (CSV row or YAML item) gets 14 checks from `defaultTest`, driven by three vars: `expected_docs`, `must_match`, `must_not_match`.

| Group | Named metric | Assertion | Meaning |
|---|---|---|---|
| Retrieval | `hit_rate_at_3` | javascript | Expected page in top 3 |
| Retrieval | `top1_accuracy` | javascript | Expected page ranked first |
| Retrieval | `mrr` | javascript | 1 / rank of first expected page |
| Retrieval | `context_recall` | javascript | Share of needed pages retrieved |
| Retrieval | `context_precision` | javascript | Share of retrieved pages relevant |
| Generation | `answer_correctness` | regex | Right fact in the right shape |
| Generation | `no_wrong_facts` | not-regex | Known wrong value absent |
| Generation | `citation_grounding` | javascript | Every citation was retrieved |
| Generation | `citation_accuracy` | javascript | Expected page is cited |
| Generation | `numeric_faithfulness` | javascript | Every number exists in the pages |
| Quality | `conciseness` | word-count | Answer under 80 words |
| Safety | `safety` | not-regex, not-icontains | No ID-number or system prompt leaks |
| Contract | `response_contract` | is-json + schema | App JSON keeps its shape |
| Speed | `latency` | latency | Round trip under 20 s |

The showcase YAML adds `equals, starts-with, levenshtein, contains, icontains, contains-all, contains-any, icontains-any, icontains-all, not-contains, regex, javascript (inline + file), word-count, rouge-n, latency, cost`.

**Add a test:** use *Add a test* in the Test lab, or add one row to any CSV in `tests/`. Write regex without `(?i)` (JavaScript does not support it); use `[Pp]` letter sets instead.

## Settings file (`.env`)

All of these can be changed on the Settings page; editing `.env` by hand also works (restart the app afterwards).

| Key | Default | Purpose |
|---|---|---|
| `GROQ_API_KEY` | (empty) | Free key; empty = offline mode |
| `QT_LLM_MODE` | `groq` | `groq` or `offline` |
| `GROQ_MODEL` | `llama-3.3-70b-versatile` | Main model |
| `GROQ_FALLBACK_MODEL` | `llama-3.1-8b-instant` | Used if the daily free limit is hit |
| `QT_TEMPERATURE` | `0` | 0 to 2; 0 gives repeatable answers |
| `QT_MAX_TOKENS` | `200` | Longest answer the LLM may write |
| `QT_TOP_K` / `QT_MIN_SCORE` | `3` / `2.5` | Retriever settings |

## Troubleshooting

- **Rate limits (HTTP 429):** the app waits and retries; tests run one at a time with a 1.5 s pause. If it persists, wait a minute or switch `GROQ_MODEL` to `llama-3.1-8b-instant`.
- **Test lab says js-yaml is missing:** run `npm install` in the project folder (run.bat does this).
- **Port 3000 busy:** close the old server window, or set `PORT` in `.env` and update the URL in `promptfooconfig.yaml`.
- **401 from Groq:** the key is wrong; fix `GROQ_API_KEY` in `.env`.
- **LLM wording varies:** regex checks accept shapes, not exact sentences. If a correct answer fails, widen the regex in the CSV rather than the app.

---
*Knowledge-base content is sample training data. Replace it with the official FAQs from qualitythought.in before using it with students.*
Quality Thought · Transforming Dreams! Redefining Future!
