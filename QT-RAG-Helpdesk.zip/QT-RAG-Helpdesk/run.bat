@echo off
REM =====================================================================
REM   QUALITY THOUGHT  -  Student Helpdesk RAG  -  ONE-CLICK RUN
REM   Transforming Dreams! Redefining Future!
REM ---------------------------------------------------------------------
REM   Double-click this file. It will:
REM     1. check Node.js           4. start the app on http://localhost:3000
REM     2. create .env (Groq key)  5. run every promptfoo test
REM     3. install promptfoo       6. open the report, Test lab and dashboard
REM =====================================================================
setlocal EnableExtensions
title Quality Thought - Student Helpdesk RAG
cd /d "%~dp0"
set "PROMPTFOO_DISABLE_TELEMETRY=1"
set "PROMPTFOO_DISABLE_UPDATE=1"
set "PROMPTFOO_DISABLE_SHARING=1"

echo.
echo  ==============================================================
echo     QUALITY THOUGHT  ^|  Student Helpdesk RAG + Promptfoo tests
echo     Transforming Dreams! Redefining Future!
echo  ==============================================================
echo.

REM ---------- STEP 1: Node.js ------------------------------------------
echo  [1/6] Checking Node.js ...
where node >nul 2>nul
if errorlevel 1 goto :no_node
node scripts\check-node.js
if errorlevel 1 goto :no_node

REM Python is optional: only python assertions need it
node scripts\check-python.js

REM ---------- STEP 2: settings (.env) -----------------------------------
echo  [2/6] Checking settings (.env) ...
if exist ".env" (
  echo   .env found. Edit it in Notepad to change the Groq key or model.
) else (
  node scripts\setup-env.js
  if errorlevel 1 goto :fail
)

REM ---------- STEP 3: install promptfoo (first run only) ----------------
echo  [3/6] Checking packages ...
set "NEED_INSTALL=0"
if not exist "node_modules\promptfoo\package.json" set "NEED_INSTALL=1"
if not exist "node_modules\js-yaml\package.json" set "NEED_INSTALL=1"
if "%NEED_INSTALL%"=="1" (
  echo   Installing promptfoo and js-yaml. First run only, takes 2 to 5 minutes ...
  call npm install --no-audit --no-fund
  if errorlevel 1 goto :fail
) else (
  echo   Packages already installed.
)

REM ---------- STEP 4: start the RAG app ---------------------------------
echo  [4/6] Starting the helpdesk app on http://localhost:3000 ...
node scripts\wait-for-server.js --check
if errorlevel 1 start "QT RAG Helpdesk - server" cmd /k "node app\server.js"
node scripts\wait-for-server.js
if errorlevel 1 goto :fail
start "" "http://localhost:3000"

REM ---------- STEP 5: run the promptfoo tests ---------------------------
echo  [5/6] Running the promptfoo test suite (about 1 to 2 minutes) ...
echo.
if not exist "results" mkdir "results"
call npx promptfoo eval -c promptfooconfig.yaml --no-cache -o results\latest-results.json -o results\promptfoo-results.html
echo.
echo   promptfoo exit code %errorlevel%  (0 = all passed, 100 = some tests failed)
echo   One failure is planned: the [DEMO-RED] test shows what a FAIL looks like.

REM ---------- STEP 6: reports -------------------------------------------
echo  [6/6] Building the Quality Thought report ...
node scripts\make-report.js
if errorlevel 1 goto :fail
start "" "http://localhost:3000/report"
start "" "http://localhost:3000/#lab"
start "Promptfoo dashboard" cmd /k "npx promptfoo view --yes"

echo.
echo  ==============================================================
echo   Done.
echo     Chat app        http://localhost:3000/#chat
echo     Test lab        http://localhost:3000/#lab     pick tests + metrics, run, see results
echo     Settings        http://localhost:3000/#settings   Groq key and model
echo     QT test report  http://localhost:3000/report
echo     Promptfoo UI    http://localhost:15500
echo   Run the tests again any time:  npm test  then  npm run report
echo   Same suite with Python metrics:  npm run test:python
echo   LLM-as-a-judge suite (needs Groq key):  npm run test:judge  then  npm run report:judge
echo   Keep the server window open while testing. Close it to stop.
echo  ==============================================================
echo.
pause
exit /b 0

:no_node
echo.
echo   Node.js 22.22 or newer is needed. Opening the download page ...
echo   Install the LTS version, then double-click run.bat again.
start "" "https://nodejs.org/en/download"
pause
exit /b 1

:fail
echo.
echo   Something went wrong. Read the message above, fix it, and run again.
echo   Common fixes: check internet for npm install, check GROQ_API_KEY in .env.
pause
exit /b 1
