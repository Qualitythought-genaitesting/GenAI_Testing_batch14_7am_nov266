/* =====================================================================
 *   ___  _____   QUALITY THOUGHT  |  Student Helpdesk RAG
 *  / _ \|_   _|  Transforming Dreams! Redefining Future!
 * | (_) | | |
 *  \__\_\ |_|    File: judge/groq_judge.js
 * ---------------------------------------------------------------------
 *  The LLM JUDGE (promptfoo calls it the "grader").
 *
 *  Model-graded assertions (llm-rubric, factuality, g-eval,
 *  context-faithfulness, ...) send a grading prompt to this provider.
 *  It forwards the prompt to Groq and returns the judge's reply;
 *  promptfoo then turns that reply into pass / score / reason.
 *
 *  Uses in promptfoo YAML:
 *    defaultTest:
 *      options:
 *        provider: file://judge/groq_judge.js
 *
 *  Settings: GROQ_API_KEY and QT_JUDGE_MODEL from .env (Settings page).
 *  Temperature is always 0 so the judge is as repeatable as possible.
 *  Same retry and backup-model logic as the app (free-tier rate limits).
 *
 *  Built-in alternative, no file needed:
 *        provider: groq:llama-3.3-70b-versatile
 * ===================================================================== */
const config = require('../app/env');
const { callGroq } = require('../app/rag/generator');

/** promptfoo grading prompts are a JSON list of chat messages, or plain text. */
function toMessages(prompt) {
  try {
    const parsed = JSON.parse(prompt);
    if (Array.isArray(parsed) && parsed.every((m) => m && m.role && typeof m.content === 'string')) return parsed;
  } catch (_) { /* plain text prompt */ }
  return [{ role: 'user', content: String(prompt) }];
}

class GroqJudge {
  constructor(options = {}) {
    this.options = options;
    this.model = (options.config && options.config.model) || config.JUDGE_MODEL;
  }

  id() { return `qt-groq-judge:${this.model}`; }

  async callApi(prompt) {
    if (!config.GROQ_API_KEY) {
      return { error: 'The LLM judge needs a Groq API key. Add it on the Settings page (localhost:3000/#settings) or in .env.' };
    }
    try {
      const out = await callGroq(toMessages(prompt), { model: this.model, temperature: 0, maxTokens: 1024 });
      const usage = out.usage || {};
      return {
        output: out.text,
        tokenUsage: { prompt: usage.prompt_tokens || 0, completion: usage.completion_tokens || 0, total: usage.total_tokens || 0 },
      };
    } catch (err) {
      return { error: `Judge call failed: ${err.message}` };
    }
  }
}

module.exports = GroqJudge;
