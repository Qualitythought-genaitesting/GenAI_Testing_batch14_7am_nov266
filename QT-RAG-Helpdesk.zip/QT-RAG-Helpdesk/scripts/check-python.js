/* =====================================================================
 *  QUALITY THOUGHT | Student Helpdesk RAG
 *  Transforming Dreams! Redefining Future!
 *  File: scripts/check-python.js
 * ---------------------------------------------------------------------
 *  Python is OPTIONAL: only python assertions need it. Checks for a real
 *  Python 3 (the Windows Store "python" stub does not count).
 * ===================================================================== */
const { spawnSync } = require('child_process');
for (const cmd of process.env.PROMPTFOO_PYTHON ? [process.env.PROMPTFOO_PYTHON] : ['python', 'python3', 'py']) {
  try {
    const r = spawnSync(cmd, ['--version'], { encoding: 'utf8', timeout: 5000, windowsHide: true });
    const out = `${r.stdout || ''}${r.stderr || ''}`.trim();
    if (r.status === 0 && /^Python 3\./.test(out)) {
      console.log(`  ${out} found: python assertions available (npm run test:python).`);
      process.exit(0);
    }
  } catch (_) { /* try the next one */ }
}
console.log('  Python 3 not found (optional). Install it from python.org, ticking "Add python.exe to PATH", to use python assertions.');
