/* =====================================================================
 *  QUALITY THOUGHT | Student Helpdesk RAG
 *  Transforming Dreams! Redefining Future!
 *  File: scripts/setup-env.js
 * ---------------------------------------------------------------------
 *  First-run helper called by run.bat / run.sh. Asks for the free Groq
 *  API key, checks it with Groq, and writes .env from .env.example.
 *  Press Enter without a key to use the offline demo mode.
 * ===================================================================== */
const fs = require('fs');
const path = require('path');
const readline = require('readline');

const ROOT = path.resolve(__dirname, '..');
const ENV = path.join(ROOT, '.env');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise((r) => rl.question(q, (a) => r(a.trim())));

async function keyWorks(key) {
  try {
    const res = await fetch('https://api.groq.com/openai/v1/models', {
      headers: { Authorization: `Bearer ${key}` }, signal: AbortSignal.timeout(8000),
    });
    if (res.status === 401) return false;
    return true; // 200, or a temporary error we should not block on
  } catch (_) {
    console.log('  Could not reach Groq to verify the key (no internet?). Saving it anyway.');
    return true;
  }
}

(async () => {
  console.log('');
  console.log('  First run: connect the free Groq LLM.');
  console.log('  1. Open https://console.groq.com/keys and sign in (free).');
  console.log('  2. Click "Create API Key" and copy the key (starts with gsk_).');
  console.log('  Tip: you can also skip this and paste the key later on the Settings page.');
  console.log('');
  let key = '';
  for (let tries = 0; tries < 3; tries++) {
    key = await ask('  Paste your Groq API key, or press Enter to add it later in Settings: ');
    if (!key) break;
    if (await keyWorks(key)) break;
    console.log('  Groq rejected that key (401). Please copy it again.');
    key = '';
  }
  rl.close();

  let text = fs.readFileSync(path.join(ROOT, '.env.example'), 'utf8');
  text = text.replace(/^GROQ_API_KEY=.*$/m, `GROQ_API_KEY=${key}`);
  if (!key) text = text.replace(/^QT_LLM_MODE=.*$/m, 'QT_LLM_MODE=offline');
  fs.writeFileSync(ENV, text);
  console.log(key
    ? '  Saved .env with your Groq key. Mode: groq.'
    : '  Saved .env in OFFLINE demo mode. Add the key any time at http://localhost:3000/#settings');
})();
