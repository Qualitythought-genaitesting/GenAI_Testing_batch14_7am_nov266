/* =====================================================================
 *  QUALITY THOUGHT | Student Helpdesk RAG
 *  Transforming Dreams! Redefining Future!
 *  File: scripts/wait-for-server.js
 * ---------------------------------------------------------------------
 *  node scripts/wait-for-server.js          -> waits up to 30 s for the app
 *  node scripts/wait-for-server.js --check  -> exit 0 if already running
 * ===================================================================== */
const url = `http://localhost:${process.env.PORT || 3000}/api/health`;
const checkOnly = process.argv.includes('--check');
const deadline = Date.now() + (checkOnly ? 2000 : 30000);

(async function poll() {
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(1500) });
    if (res.ok) {
      const h = await res.json();
      if (!checkOnly) console.log(`  App is up: ${h.app} (${h.mode}${h.model ? ', ' + h.model : ''})`);
      process.exit(0);
    }
  } catch (_) { /* not up yet */ }
  if (Date.now() > deadline) {
    if (!checkOnly) console.error('  The app did not start. Look at the "QT RAG Helpdesk - server" window for the error.');
    process.exit(1);
  }
  setTimeout(poll, 700);
})();
