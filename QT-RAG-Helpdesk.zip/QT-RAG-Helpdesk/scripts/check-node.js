/* =====================================================================
 *  QUALITY THOUGHT | Student Helpdesk RAG
 *  Transforming Dreams! Redefining Future!
 *  File: scripts/check-node.js  (promptfoo needs Node.js 22.22 or newer)
 * ===================================================================== */
const [major, minor] = process.versions.node.split('.').map(Number);
const ok = major > 22 || (major === 22 && minor >= 22);
if (ok) {
  console.log(`  Node.js ${process.versions.node} found.`);
} else {
  console.error(`  Node.js ${process.versions.node} is too old. Install the LTS version (22.22 or newer) from https://nodejs.org and run again.`);
  process.exit(1);
}
