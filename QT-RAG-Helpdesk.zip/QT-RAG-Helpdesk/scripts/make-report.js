/* =====================================================================
 *   ___  _____   QUALITY THOUGHT  |  Student Helpdesk RAG
 *  / _ \|_   _|  Transforming Dreams! Redefining Future!
 * | (_) | | |
 *  \__\_\ |_|    File: scripts/make-report.js
 * ---------------------------------------------------------------------
 *  Turns results/latest-results.json (written by promptfoo -o) into a
 *  Quality Thought branded HTML report: results/qt-test-report.html
 *  Served by the app at http://localhost:3000/report
 * ===================================================================== */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
// Usage: node scripts/make-report.js [results.json] [report.html]
const IN = path.resolve(ROOT, process.argv[2] || 'results/latest-results.json');
const OUT = path.resolve(ROOT, process.argv[3] || 'results/qt-test-report.html');

if (!fs.existsSync(IN)) {
  console.error(`No ${path.relative(ROOT, IN)} yet. Run the tests first (npm test, or npm run test:judge).`);
  process.exit(1);
}

const data = JSON.parse(fs.readFileSync(IN, 'utf8'));
const rows = data.results.results;
const stats = data.results.stats;
const metrics = (data.results.prompts[0] && data.results.prompts[0].metrics) || {};
const avg = (name) => {
  const sum = metrics.namedScores && metrics.namedScores[name];
  const count = metrics.namedScoresCount && metrics.namedScoresCount[name];
  return sum === undefined || !count ? null : sum / count;
};
const logo = 'data:image/png;base64,' + fs.readFileSync(path.join(ROOT, 'assets', 'qt-logo.png')).toString('base64');
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// Metric catalogue: name in promptfooconfig.yaml -> label + what it tells you
const GROUPS = [
  ['Retrieval metrics', 'Did the retriever bring the right pages?', [
    ['hit_rate_at_3', 'Hit rate @3', 'Right page somewhere in the top 3'],
    ['top1_accuracy', 'Top-1 accuracy', 'Right page ranked first'],
    ['mrr', 'MRR', 'Mean reciprocal rank: 1.0 means always rank 1'],
    ['context_recall', 'Context recall', 'Share of needed pages that were retrieved'],
    ['context_precision', 'Context precision', 'Share of retrieved pages that were relevant'],
  ]],
  ['Generation metrics', 'Did the writer use the pages correctly?', [
    ['answer_correctness', 'Answer correctness', 'Right fact in the right shape (regex)'],
    ['no_wrong_facts', 'No wrong facts', 'Known wrong values absent (not-regex)'],
    ['citation_grounding', 'Citation grounding', 'Every citation was really retrieved'],
    ['citation_accuracy', 'Citation accuracy', 'The expected page is cited'],
    ['numeric_faithfulness', 'Numeric faithfulness', 'Every number exists in the retrieved pages'],
    ['reference_overlap', 'Reference overlap', 'ROUGE-N word overlap with a reference answer'],
    ['format_shapes', 'Format shapes', 'Email, mobile and clock-time shapes'],
    ['business_rules', 'Business rules', 'Custom JavaScript rules (installment maths)'],
    ['citation_format', 'Citation format', 'Citation closes the answer'],
  ]],
  ['LLM judge', 'What did the judge LLM decide?', [
    ['judge_faithfulness', 'Faithfulness', 'Every claim supported by the retrieved pages'],
    ['judge_context_relevance', 'Context relevance', 'Share of retrieved text the question needs'],
    ['judge_context_recall', 'Context recall', 'Pages contain everything the reference says'],
    ['judge_factuality', 'Factuality', 'Agrees with the reference answer'],
    ['judge_helpfulness', 'Helpfulness rubric', 'Plain-English rubric'],
    ['judge_tone', 'Tone rubric', 'Rubric written in the test'],
    ['judge_closedqa', 'Closed QA', 'Yes/no criterion'],
    ['judge_geval', 'G-Eval', 'Multi-criteria score out of 10'],
  ]],
  ['Safety, contract and speed', 'Is it safe, well-formed and fast?', [
    ['safety', 'Safety', 'No ID-number leaks, no system prompt leaks'],
    ['conciseness', 'Conciseness', 'Answer within the word budget'],
    ['response_contract', 'Response contract', 'App JSON keeps its schema'],
    ['latency', 'Latency', 'Round trip under the time budget'],
  ]],
];

const pct = (v) => (v === null ? 'n/a' : `${Math.round(v * 100)}%`);
const tone = (v) => (v === null ? 'na' : v >= 0.999 ? 'good' : v >= 0.8 ? 'warn' : 'bad');

const first = rows.find((r) => r.response && r.response.metadata) || {};
const runMeta = (first.response && first.response.metadata) || {};
const passed = stats.successes;
const failed = stats.failures;
const errors = stats.errors;
const total = passed + failed + errors;

const groupsHtml = GROUPS.filter(([, , items]) => items.some(([k]) => avg(k) !== null)).map(([title, sub, items]) => `
  <section class="group">
    <h2>${title}</h2><p class="sub">${sub}</p>
    ${items.filter(([k]) => avg(k) !== null).map(([k, label, help]) => `
      <div class="metric ${tone(avg(k))}">
        <div class="mtop"><b>${label}</b><span>${pct(avg(k))}</span></div>
        <div class="bar"><i style="width:${Math.round((avg(k) || 0) * 100)}%"></i></div>
        <small>${help} <code>${k}</code></small>
      </div>`).join('')}
  </section>`).join('');

const testsHtml = rows.map((r, i) => {
  const md = (r.response && r.response.metadata) || {};
  const fails = ((r.gradingResult && r.gradingResult.componentResults) || []).filter((c) => !c.pass);
  const checks = ((r.gradingResult && r.gradingResult.componentResults) || []).length;
  const demo = /DEMO-RED/.test(r.testCase.description || '');
  return `
  <details class="test ${r.success ? 'ok' : 'ko'}" ${!r.success ? 'open' : ''}>
    <summary>
      <span class="badge">${r.success ? 'PASS' : demo ? 'FAIL · expected' : 'FAIL'}</span>
      <span class="tname">${i + 1}. ${esc(r.testCase.description || r.vars.question)}</span>
      <span class="tmeta">${checks - fails.length}/${checks} checks · ${r.latencyMs ?? '-'} ms</span>
    </summary>
    <div class="tbody">
      <p><b>Question</b> ${esc(r.vars.question)}</p>
      <p><b>Answer</b> ${esc((r.response && r.response.output) || r.error || '')}</p>
      <p><b>Pages retrieved</b> ${(md.retrieved || []).map((p) => `<span class="chip">#${p.rank} ${esc(p.id)} · ${p.score}</span>`).join(' ') || '<span class="chip">none (fallback)</span>'}
         <b class="exp">Expected</b> <span class="chip">${esc(r.vars.expected_docs)}</span></p>
      ${fails.length ? `<ul class="fails">${fails.map((c) => `<li><code>${esc((c.assertion && c.assertion.type) || '')}</code>${c.assertion && c.assertion.metric ? ` <em>${esc(c.assertion.metric)}</em>` : ''} ${esc(c.reason)}</li>`).join('')}</ul>` : ''}
      ${demo ? '<p class="note">This failure is intentional: the test expects "15 days" but the policy page says 7 days. Fix the test, not the app.</p>' : ''}
    </div>
  </details>`;
}).join('');

const html = `<!doctype html>
<!-- Quality Thought · Transforming Dreams! Redefining Future! · generated by scripts/make-report.js -->
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Quality Thought · RAG Test Report</title>
<link rel="icon" href="${logo}">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{--ink:#090A4D;--orange:#ED3705;--amber:#FD8608;--mist:#F4F5FA;--line:#DFE1EC;--muted:#5B5E86;--good:#127A4A;--warn:#B86E00;--bad:#C0260A}
*{box-sizing:border-box}body{margin:0;font-family:"Outfit","Segoe UI",system-ui,sans-serif;color:var(--ink);background:var(--mist);line-height:1.5}
header{background:#fff;border-bottom:1px solid var(--line);padding:1rem 2rem;display:flex;align-items:center;justify-content:space-between;gap:1rem;flex-wrap:wrap}
header img{height:56px}header .run{color:var(--muted);font-size:.9rem;text-align:right}
main{max-width:1150px;margin:0 auto;padding:1.5rem 2rem 3rem}
h1{font-size:2rem;margin:.2rem 0}h2{font-size:1.2rem;margin:0}.sub{color:var(--muted);margin:.1rem 0 1rem}
.summary{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin:1rem 0 1.5rem}
.stat{background:#fff;border:1px solid var(--line);border-radius:14px;padding:1rem 1.2rem}
.stat b{display:block;font-size:2.4rem;line-height:1.1}.stat.pass b{color:var(--good)}.stat.fail b{color:var(--bad)}
.groups{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:1rem}
.group{background:#fff;border:1px solid var(--line);border-radius:14px;padding:1.2rem}
.metric{padding:.55rem 0;border-top:1px dashed var(--line)}.mtop{display:flex;justify-content:space-between}
.mtop span{font-weight:700}.metric.good .mtop span{color:var(--good)}.metric.warn .mtop span{color:var(--warn)}.metric.bad .mtop span{color:var(--bad)}
.bar{height:6px;background:var(--mist);border-radius:4px;margin:.3rem 0}.bar i{display:block;height:100%;border-radius:4px;background:linear-gradient(90deg,var(--orange),var(--amber))}
small{color:var(--muted)}code{font-size:.8rem;background:var(--mist);padding:.05rem .35rem;border-radius:4px}
.tests{margin-top:2rem}.test{background:#fff;border:1px solid var(--line);border-radius:12px;margin:.6rem 0}
summary{cursor:pointer;display:flex;gap:.8rem;align-items:center;padding:.8rem 1rem;flex-wrap:wrap}
.badge{font-weight:700;font-size:.8rem;padding:.2rem .6rem;border-radius:999px;color:#fff;background:var(--good)}
.ko .badge{background:var(--bad)}.tname{font-weight:600;flex:1}.tmeta{color:var(--muted);font-size:.85rem}
.tbody{padding:0 1rem 1rem 1rem;border-top:1px solid var(--line)}.tbody p{margin:.6rem 0}.tbody b{margin-right:.4rem}
.chip{display:inline-block;border:1px solid var(--line);border-radius:999px;padding:0 .55rem;font-size:.85rem;margin:.1rem}
.exp{margin-left:1rem}.fails{margin:.4rem 0;padding-left:1.2rem;color:var(--bad)}.fails em{color:var(--muted)}
.note{background:#FFF1EA;border:1px solid #F7C9B4;border-radius:8px;padding:.5rem .8rem}
footer{text-align:center;color:var(--muted);font-size:.85rem;padding:1rem}
@media(max-width:900px){.summary,.groups{grid-template-columns:1fr 1fr}main{padding:1rem}}
@media(max-width:560px){.summary,.groups{grid-template-columns:1fr}}
</style></head><body>
<header><img src="${logo}" alt="Quality Thought - Transforming Dreams! Redefining Future!">
<div class="run">Run ${esc(new Date(data.results.timestamp || Date.now()).toLocaleString())}<br>
LLM: ${esc(runMeta.mode === 'offline' ? 'offline demo mode' : 'Groq · ' + (runMeta.model || ''))} · ${(stats.durationMs / 1000).toFixed(1)} s</div></header>
<main>
<h1>Student Helpdesk RAG · ${/judge/.test(OUT) ? 'LLM-as-a-judge report' : 'Test report'}</h1>
<p class="sub">${/judge/.test(OUT) ? 'Model-graded promptfoo checks: a judge LLM grades meaning, faithfulness and tone.' : 'Deterministic promptfoo checks on retrieval and generation. Same answer in, same verdict out.'}</p>
<div class="summary">
  <div class="stat"><b>${total}</b>tests</div>
  <div class="stat pass"><b>${passed}</b>passed</div>
  <div class="stat fail"><b>${failed}</b>failed</div>
  <div class="stat"><b>${errors}</b>errors</div>
</div>
<div class="groups">${groupsHtml}</div>
<section class="tests"><h2>Every test</h2><p class="sub">Failed tests open automatically and show the reason for each failed check.</p>${testsHtml}</section>
</main>
<footer>Quality Thought · Transforming Dreams! Redefining Future! · Full detail: run <code>npx promptfoo view</code></footer>
</body></html>`;

fs.writeFileSync(OUT, html);
console.log(`Report written: ${OUT}`);
console.log(`  ${passed} passed, ${failed} failed, ${errors} errors  ->  http://localhost:3000/report${/judge/.test(OUT) ? '/judge' : ''}`);
