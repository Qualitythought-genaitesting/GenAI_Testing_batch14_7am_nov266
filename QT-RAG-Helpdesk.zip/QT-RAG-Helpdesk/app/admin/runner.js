/* =====================================================================
 *   ___  _____   QUALITY THOUGHT  |  Student Helpdesk RAG
 *  / _ \|_   _|  Transforming Dreams! Redefining Future!
 * | (_) | | |
 *  \__\_\ |_|    File: app/admin/runner.js
 * ---------------------------------------------------------------------
 *  Runs promptfoo from the Test Lab page:
 *   1. takes the user's choice (test files / tests, metrics, options)
 *   2. writes promptfooconfig.ui-run.yaml with exactly those checks
 *   3. runs "promptfoo eval" as a child process
 *   4. summarises the results for the selected metrics only
 *  Every run is kept in results/runs/<run-id>/ (config, results, log).
 * ===================================================================== */
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const yaml = require('js-yaml');
const config = require('../env');
const catalog = require('./catalog');

const RUNS_DIR = path.join(config.ROOT, 'results', 'runs');
const RUN_CONFIG = path.join(config.ROOT, 'promptfooconfig.ui-run.yaml');
let active = null; // only one run at a time: free Groq keys have rate limits

const stripAnsi = (s) => s.replace(/\u001b\[[0-9;]*m/g, '');
const newId = () => new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14) + '-' + Math.random().toString(36).slice(2, 6);

function promptfooBin() {
  // promptfoo's package.json is not "exported", so find it on disk.
  let dir = path.join(config.ROOT, 'node_modules', 'promptfoo');
  if (!fs.existsSync(path.join(dir, 'package.json'))) {
    dir = path.dirname(require.resolve('promptfoo', { paths: [config.ROOT] }));
    while (!fs.existsSync(path.join(dir, 'package.json')) && path.dirname(dir) !== dir) dir = path.dirname(dir);
  }
  const pkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'));
  const bin = typeof pkg.bin === 'string' ? pkg.bin : pkg.bin.promptfoo;
  return path.join(dir, bin);
}

/** Build the list of promptfoo tests for this run. */
function buildTests(request) {
  const selectedMetrics = new Set(request.metrics || []);
  const metricDefs = catalog.metrics(request.lang).filter((m) => selectedMetrics.has(m.name));
  const wantedIds = request.testIds && request.testIds.length ? new Set(request.testIds) : null;
  const filter = String(request.filter || '').trim().toLowerCase();
  const tests = [];
  for (const file of request.files || []) {
    for (const t of catalog.readTests(file)) {
      if (wantedIds && !wantedIds.has(t.id)) continue;
      if (filter && !`${t.description} ${t.vars.question || ''}`.toLowerCase().includes(filter)) continue;
      const assert = [];
      if (request.includeOwn !== false) assert.push(...t.assert);
      for (const m of metricDefs) {
        // Skip a metric when the test lacks the var it reads (e.g. no must_match column).
        if (m.needs && !String(t.vars[m.needs] || '').trim()) continue;
        // Judges of retrieved pages need pages: skip them for off-topic tests.
        if (m.inScope && /^(NONE)?$/i.test(String(t.vars.expected_docs || '').trim())) continue;
        assert.push(...m.assertions.map((a) => JSON.parse(JSON.stringify(a))));
      }
      if (!assert.length) continue;
      tests.push({
        description: t.description,
        vars: t.vars,
        assert,
        metadata: { ...t.metadata, source: t.id },
        ...(t.options ? { options: t.options } : {}),
      });
    }
  }
  return tests;
}

function buildConfig(request, tests) {
  const main = catalog.mainConfig(request.lang);
  const usesJudge = tests.some((t) => t.assert.some((a) => catalog.MODEL_GRADED.has(a.type)));
  const providers = JSON.parse(JSON.stringify(main.providers)).map((p) => ({
    ...p, id: String(p.id).replace(/localhost:\d+/, `localhost:${config.PORT}`),
  }));
  return {
    description: `Quality Thought Test Lab run (${request.files.join(', ')}, metrics in ${catalog.langOf(request.lang)})`,
    prompts: main.prompts,
    providers,
    evaluateOptions: config.LLM_MODE === 'offline' && !usesJudge ? { maxConcurrency: 1 } : { maxConcurrency: 1, delay: usesJudge ? 2000 : 1500 },
    // LLM judge: grader provider + vars.query for the context-* judges
    ...(usesJudge ? { defaultTest: { options: catalog.judgeDefaults().options } } : {}),
    tests,
  };
}

/** Plan a run without starting it: how many tests and checks. */
function preview(request) {
  const tests = buildTests(request);
  return {
    tests: tests.length,
    checks: tests.reduce((n, t) => n + t.assert.length, 0),
    judgeChecks: tests.reduce((n, t) => n + t.assert.filter((a) => catalog.MODEL_GRADED.has(a.type)).length, 0),
  };
}

function saveMeta(run) {
  const { child, ...meta } = run;
  fs.writeFileSync(path.join(run.dir, 'run.json'), JSON.stringify(meta, null, 2));
}

function start(request) {
  if (active) throw new Error('A run is already in progress. Wait for it to finish or stop it.');
  if (!Array.isArray(request.files) || !request.files.length) throw new Error('Pick at least one test file.');
  if (!Array.isArray(request.metrics)) request.metrics = [];
  request.lang = catalog.langOf(request.lang);
  if (request.lang === 'python' && !catalog.pythonInfo().available) {
    throw new Error('Python 3 was not found. Install it from python.org (tick "Add python.exe to PATH"), restart the app, or switch metric code to JavaScript.');
  }
  const known = new Set(catalog.testFiles().map((f) => f.file));
  for (const f of request.files) if (!known.has(f)) throw new Error(`Unknown test file: ${f}`);

  const tests = buildTests(request);
  if (!tests.length) throw new Error('Nothing to run: no tests match, or no checks were selected.');
  const needsJudge = tests.some((t) => t.assert.some((a) => catalog.MODEL_GRADED.has(a.type)));
  if (needsJudge && !config.GROQ_API_KEY) {
    throw new Error('LLM-judge checks need a Groq API key: the judge is an LLM too. Add your key on the Settings page, or untick the LLM judge metrics and judge test files.');
  }
  const needsPython = tests.some((t) => t.assert.some((a) => a.type === 'python' || a.type === 'not-python'));
  if (needsPython && !catalog.pythonInfo().available) {
    throw new Error('Some selected tests use python assertions, but Python 3 was not found. Install it from python.org (tick "Add python.exe to PATH") and restart the app, or untick those tests.');
  }

  const id = newId();
  const dir = path.join(RUNS_DIR, id);
  fs.mkdirSync(dir, { recursive: true });
  const cfgText = `# Quality Thought Test Lab - generated for run ${id}. Do not edit; edit tests/ or promptfooconfig.yaml.\n`
    + yaml.dump(buildConfig(request, tests), { lineWidth: 200, noRefs: true });
  fs.writeFileSync(RUN_CONFIG, cfgText);
  fs.writeFileSync(path.join(dir, 'config.yaml'), cfgText);

  const run = {
    id, dir, status: 'running', request, mode: config.LLM_MODE, model: config.LLM_MODE === 'groq' ? config.GROQ_MODEL : 'offline-extractive',
    // The settings this run was tested with, so runs can be compared later
    settings: { temperature: config.TEMPERATURE, maxTokens: config.MAX_TOKENS, topK: config.TOP_K, minScore: config.MIN_SCORE, judgeModel: config.JUDGE_MODEL },
    total: tests.length, checks: tests.reduce((n, t) => n + t.assert.length, 0), done: 0,
    startedAt: new Date().toISOString(), finishedAt: null, exitCode: null, log: [],
  };
  const resultsJson = path.join(dir, 'results.json');
  const args = [promptfooBin(), 'eval', '-c', RUN_CONFIG, '--no-cache', '--no-progress-bar', '--no-table', '-o', resultsJson, '-o', path.join(dir, 'promptfoo-results.html')];
  const pyCmd = catalog.pythonInfo().command;
  const child = spawn(process.execPath, args, {
    cwd: config.ROOT,
    env: { ...process.env, ...(pyCmd && !process.env.PROMPTFOO_PYTHON ? { PROMPTFOO_PYTHON: pyCmd } : {}), FORCE_COLOR: '0', PROMPTFOO_DISABLE_TELEMETRY: '1', PROMPTFOO_DISABLE_UPDATE: '1', PROMPTFOO_DISABLE_SHARING: '1' },
    windowsHide: true,
  });
  run.child = child;
  const onData = (buf) => {
    for (const line of stripAnsi(buf.toString()).split(/\r?\n/)) {
      if (line.trim()) run.log.push(line.slice(0, 400));
    }
    if (run.log.length > 400) run.log.splice(0, run.log.length - 400);
  };
  child.stdout.on('data', onData);
  child.stderr.on('data', onData);
  child.on('error', (err) => { run.log.push(`Could not start promptfoo: ${err.message}`); });
  child.on('close', (code) => {
    run.exitCode = code;
    run.finishedAt = new Date().toISOString();
    // promptfoo exit codes: 0 = all passed, 100 = some tests failed
    run.status = run.status === 'stopped' ? 'stopped' : fs.existsSync(resultsJson) && (code === 0 || code === 100) ? 'finished' : 'error';
    run.done = run.status === 'finished' ? run.total : run.done;
    saveMeta(run);
    fs.writeFileSync(path.join(dir, 'log.txt'), run.log.join('\n'));
    active = null;
  });
  active = run;
  saveMeta(run);
  return publicRun(run);
}

function stop() {
  if (!active) throw new Error('No run in progress.');
  active.status = 'stopped';
  active.child.kill();
  return { ok: true, message: 'Run stopped.' };
}

/** Called by the app for every /api/ask while a run is active (progress bar). */
function onAsk() { if (active && active.done < active.total) active.done += 1; }

const publicRun = (run) => {
  const { child, dir, ...rest } = run;
  return rest;
};

function loadRun(id) {
  if (!/^[\w-]+$/.test(id)) throw new Error('Bad run id.');
  if (active && active.id === id) return active;
  const metaFile = path.join(RUNS_DIR, id, 'run.json');
  if (!fs.existsSync(metaFile)) throw new Error('Run not found.');
  const meta = JSON.parse(fs.readFileSync(metaFile, 'utf8'));
  const logFile = path.join(RUNS_DIR, id, 'log.txt');
  meta.log = fs.existsSync(logFile) ? fs.readFileSync(logFile, 'utf8').split('\n') : meta.log || [];
  meta.dir = path.join(RUNS_DIR, id);
  return meta;
}

/** Turn promptfoo's results.json into what the results page shows. */
function summarize(run) {
  const file = path.join(run.dir || path.join(RUNS_DIR, run.id), 'results.json');
  if (!fs.existsSync(file)) return null;
  const data = JSON.parse(fs.readFileSync(file, 'utf8'));
  const selected = new Set(run.request.metrics || []);
  const selectable = new Set(catalog.metrics(run.request.lang).map((m) => m.name));
  const metricStats = {};
  const tests = data.results.results.map((r) => {
    const md = (r.response && r.response.metadata) || {};
    const byMetric = {};
    const own = [];
    for (const c of (r.gradingResult && r.gradingResult.componentResults) || []) {
      const a = c.assertion || {};
      const entry = { type: a.type, pass: c.pass, score: typeof c.score === 'number' ? c.score : (c.pass ? 1 : 0), reason: c.reason || '' };
      if (a.metric && (selected.has(a.metric) || !selectable.has(a.metric))) {
        (byMetric[a.metric] = byMetric[a.metric] || []).push(entry);
      } else {
        own.push(entry);
      }
    }
    const metrics = {};
    for (const [name, list] of Object.entries(byMetric)) {
      const pass = list.every((e) => e.pass);
      const score = list.reduce((s, e) => s + e.score, 0) / list.length;
      metrics[name] = { pass, score: Number(score.toFixed(3)), reasons: list.filter((e) => !e.pass).map((e) => `${e.type}: ${e.reason}`) };
      const ms = (metricStats[name] = metricStats[name] || { name, ...catalog.info(name), sum: 0, count: 0, passed: 0 });
      ms.sum += score; ms.count += 1; ms.passed += pass ? 1 : 0;
    }
    return {
      description: r.testCase.description || r.vars.question,
      source: (r.testCase.metadata && r.testCase.metadata.source) || '',
      question: r.vars.question,
      expected_docs: r.vars.expected_docs || '',
      success: r.success,
      error: r.response && r.response.error ? r.response.error : (!r.response ? r.error || null : null),
      answer: (r.response && r.response.output) || '',
      retrieved: md.retrieved || [],
      fallback: md.fallback,
      latencyMs: r.latencyMs,
      metrics,
      own,
    };
  });
  const stats = data.results.stats;
  return {
    passed: stats.successes, failed: stats.failures, errors: stats.errors,
    durationMs: stats.durationMs,
    metrics: Object.values(metricStats).map((m) => ({ ...m, average: Number((m.sum / m.count).toFixed(3)) })),
    ownChecks: tests.reduce((n, t) => n + t.own.length, 0),
    ownPassed: tests.reduce((n, t) => n + t.own.filter((o) => o.pass).length, 0),
    tests,
  };
}

function get(id) {
  const run = loadRun(id);
  const out = publicRun(run);
  out.log = (run.log || []).slice(-150);
  out.summary = run.status === 'finished' ? summarize(run) : null;
  out.links = {
    json: `/runs/${run.id}/results.json`,
    html: `/runs/${run.id}/promptfoo-results.html`,
    config: `/runs/${run.id}/config.yaml`,
  };
  return out;
}

function list() {
  if (!fs.existsSync(RUNS_DIR)) return [];
  return fs.readdirSync(RUNS_DIR).filter((d) => fs.existsSync(path.join(RUNS_DIR, d, 'run.json')))
    .map((d) => {
      const m = active && active.id === d ? active : JSON.parse(fs.readFileSync(path.join(RUNS_DIR, d, 'run.json'), 'utf8'));
      return { id: m.id, status: m.status, startedAt: m.startedAt, total: m.total, files: m.request.files, metrics: m.request.metrics.length, lang: m.request.lang || 'javascript', mode: m.mode, model: m.model, settings: m.settings || null };
    })
    .sort((a, b) => b.startedAt.localeCompare(a.startedAt))
    .slice(0, 30);
}

/** Serve a file from a run folder (results.json, promptfoo-results.html, config.yaml). */
function runFile(id, name) {
  if (!/^[\w-]+$/.test(id) || !['results.json', 'promptfoo-results.html', 'config.yaml'].includes(name)) return null;
  const file = path.join(RUNS_DIR, id, name);
  return fs.existsSync(file) ? file : null;
}

module.exports = { start, stop, get, list, preview, onAsk, runFile, isActive: () => Boolean(active) };
