/* =====================================================================
 *   ___  _____   QUALITY THOUGHT  |  Student Helpdesk RAG
 *  / _ \|_   _|  Transforming Dreams! Redefining Future!
 * | (_) | | |
 *  \__\_\ |_|    File: app/admin/settings.js
 * ---------------------------------------------------------------------
 *  Backs the Settings page: Groq API key, model, temperature, max tokens
 *  and retriever settings. A new key is checked with Groq first.
 *  Everything is saved to .env and applied to the running app at once,
 *  no restart needed. The full key is never sent back to the browser.
 * ===================================================================== */
const fs = require('fs');
const path = require('path');
const config = require('../env');

const ENV_FILE = path.join(config.ROOT, '.env');
const EXAMPLE = path.join(config.ROOT, '.env.example');
const FALLBACK_MODELS = ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant'];

/** Numeric settings the UI can change: .env name, config field, allowed range. */
const NUMBERS = {
  temperature: { env: 'QT_TEMPERATURE', field: 'TEMPERATURE', min: 0, max: 2, step: 0.05, label: 'Temperature' },
  maxTokens:   { env: 'QT_MAX_TOKENS',  field: 'MAX_TOKENS',  min: 50, max: 1024, integer: true, label: 'Max tokens' },
  topK:        { env: 'QT_TOP_K',       field: 'TOP_K',       min: 1, max: 10, integer: true, label: 'Pages per answer' },
  minScore:    { env: 'QT_MIN_SCORE',   field: 'MIN_SCORE',   min: 0, max: 20, step: 0.1, label: 'Minimum score' },
};

/** Check the numbers in a request; returns { values, error }. */
function readNumbers(body) {
  const values = {};
  for (const [name, rule] of Object.entries(NUMBERS)) {
    if (body[name] === undefined || body[name] === '') continue;
    const n = Number(body[name]);
    if (!Number.isFinite(n) || n < rule.min || n > rule.max) return { error: `${rule.label} must be between ${rule.min} and ${rule.max}.` };
    if (rule.integer && !Number.isInteger(n)) return { error: `${rule.label} must be a whole number.` };
    values[name] = Number(n.toFixed(2));
  }
  return { values };
}

const mask = (key) => (key ? `${key.slice(0, 4)}…${key.slice(-4)}` : '');

function current() {
  return {
    hasKey: Boolean(config.GROQ_API_KEY),
    keyMasked: mask(config.GROQ_API_KEY),
    mode: config.LLM_MODE,
    model: config.GROQ_MODEL,
    fallbackModel: config.GROQ_FALLBACK_MODEL,
    judgeModel: config.JUDGE_MODEL,
    temperature: config.TEMPERATURE,
    maxTokens: config.MAX_TOKENS,
    topK: config.TOP_K,
    minScore: config.MIN_SCORE,
    envFile: fs.existsSync(ENV_FILE),
  };
}

/** Ask Groq which models this key can use. 401 = bad key. */
async function verifyKey(key) {
  if (!key) return { ok: false, message: 'Paste a key first. Get one free at console.groq.com/keys.' };
  try {
    const res = await fetch(`${config.GROQ_BASE_URL}/models`, {
      headers: { Authorization: `Bearer ${key}` },
      signal: AbortSignal.timeout(10000),
    });
    if (res.status === 401) return { ok: false, message: 'Groq rejected this key (401). Copy it again from console.groq.com/keys.' };
    if (!res.ok) return { ok: false, message: `Groq answered HTTP ${res.status}. Try again in a minute.` };
    const data = await res.json();
    const models = (data.data || [])
      .filter((m) => m.active !== false && !/whisper|tts|guard|playai/i.test(m.id))
      .map((m) => m.id)
      .sort();
    return { ok: true, message: `Key works. ${models.length} chat models available.`, models: models.length ? models : FALLBACK_MODELS };
  } catch (err) {
    return { ok: false, message: `Could not reach Groq (${err.name === 'TimeoutError' ? 'timeout' : err.message}). Check the internet connection.` };
  }
}

/** Update KEY=value lines in .env (create it from .env.example if missing). */
function writeEnv(values) {
  let text = fs.existsSync(ENV_FILE) ? fs.readFileSync(ENV_FILE, 'utf8')
    : fs.existsSync(EXAMPLE) ? fs.readFileSync(EXAMPLE, 'utf8') : '';
  const eol = text.includes('\r\n') ? '\r\n' : '\n';
  for (const [k, v] of Object.entries(values)) {
    const line = `${k}=${v}`;
    const re = new RegExp(`^${k}=.*$`, 'm');
    text = re.test(text) ? text.replace(re, line) : `${text.replace(/\s*$/, '')}${eol}${line}${eol}`;
  }
  fs.writeFileSync(ENV_FILE, text);
}

/** Apply new values to the running app (no restart). */
function applyLive({ key, model, mode, fallbackModel }) {
  if (key !== undefined) { config.GROQ_API_KEY = key; process.env.GROQ_API_KEY = key; }
  if (model) { config.GROQ_MODEL = model; process.env.GROQ_MODEL = model; }
  if (fallbackModel) { config.GROQ_FALLBACK_MODEL = fallbackModel; process.env.GROQ_FALLBACK_MODEL = fallbackModel; }
  const wanted = (mode || config.LLM_MODE || 'groq').toLowerCase();
  config.LLM_MODE = config.GROQ_API_KEY && wanted === 'groq' ? 'groq' : 'offline';
  process.env.QT_LLM_MODE = config.LLM_MODE;
}

/**
 * Save settings. A new key is verified first; nothing is saved if Groq rejects it.
 * body: { apiKey?, model?, mode?: 'groq'|'offline', fallbackModel? }
 */
async function save(body) {
  const key = typeof body.apiKey === 'string' ? body.apiKey.trim() : undefined;
  if (key && !/^[A-Za-z0-9_\-]{20,200}$/.test(key)) return { ok: false, message: 'That does not look like a Groq key (expected letters, digits and _ , usually starting with gsk_).' };
  let models;
  if (key) {
    const check = await verifyKey(key);
    if (!check.ok) return check;
    models = check.models;
  }
  const model = body.model && /^[\w.\-\/:]{2,80}$/.test(body.model) ? body.model : undefined;
  const fallbackModel = body.fallbackModel && /^[\w.\-\/:]{2,80}$/.test(body.fallbackModel) ? body.fallbackModel : undefined;
  const mode = ['groq', 'offline'].includes(body.mode) ? body.mode : undefined;
  const judgeModel = body.judgeModel && /^[\w.\-\/:]{2,80}$/.test(body.judgeModel) ? body.judgeModel : undefined;
  const nums = readNumbers(body);
  if (nums.error) return { ok: false, message: nums.error };

  const values = {};
  if (key !== undefined) values.GROQ_API_KEY = key;
  if (model) values.GROQ_MODEL = model;
  if (fallbackModel) values.GROQ_FALLBACK_MODEL = fallbackModel;
  if (judgeModel) { values.QT_JUDGE_MODEL = judgeModel; config.JUDGE_MODEL = judgeModel; process.env.QT_JUDGE_MODEL = judgeModel; }
  applyLive({ key, model, mode, fallbackModel });
  for (const [name, v] of Object.entries(nums.values)) {
    const rule = NUMBERS[name];
    config[rule.field] = v;
    process.env[rule.env] = String(v);
    values[rule.env] = String(v);
  }
  values.QT_LLM_MODE = mode || config.LLM_MODE;
  writeEnv(values);

  const now = current();
  const note = mode === 'groq' && !now.hasKey ? ' Groq mode needs a key, so the app stays in offline mode.' : '';
  const what = now.mode === 'groq' ? ` with ${now.model} at temperature ${now.temperature}` : '';
  return { ok: true, message: `Saved. The app now answers in ${now.mode} mode${what}.${note}`, settings: now, models };
}

/** Remove the key and switch to offline mode. */
function removeKey() {
  applyLive({ key: '', mode: 'offline' });
  writeEnv({ GROQ_API_KEY: '', QT_LLM_MODE: 'offline' });
  return { ok: true, message: 'Key removed. The app now answers in offline mode.', settings: current() };
}

async function models() {
  if (!config.GROQ_API_KEY) return { ok: true, models: FALLBACK_MODELS };
  const check = await verifyKey(config.GROQ_API_KEY);
  return { ok: check.ok, message: check.message, models: check.models || FALLBACK_MODELS };
}

module.exports = { current, verifyKey, save, removeKey, models, NUMBERS };
