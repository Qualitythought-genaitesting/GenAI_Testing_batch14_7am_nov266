/* =====================================================================
 *   ___  _____   QUALITY THOUGHT  |  Student Helpdesk RAG
 *  / _ \|_   _|  Transforming Dreams! Redefining Future!
 * | (_) | | |
 *  \__\_\ |_|    File: app/admin/catalog.js
 * ---------------------------------------------------------------------
 *  What the Test Lab can run:
 *    METRICS     -> the defaultTest assertions in promptfooconfig.yaml
 *                   (single source of truth), plus labels for the UI
 *    TEST FILES  -> every .csv / .yaml / .yml file in /tests
 *  Also saves new test cases and uploaded test files.
 * ===================================================================== */
const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const config = require('../env');

const TESTS_DIR = path.join(config.ROOT, 'tests');
// Same suite in two languages: metric code in JavaScript or in Python
const CONFIGS = {
  javascript: path.join(config.ROOT, 'promptfooconfig.yaml'),
  python: path.join(config.ROOT, 'promptfooconfig.python.yaml'),
};
const langOf = (lang) => (lang === 'python' ? 'python' : 'javascript');
const JUDGE_CONFIG = path.join(config.ROOT, 'promptfooconfig.llm-judge.yaml');
/** Assertion types graded by an LLM (they need the judge provider). */
const MODEL_GRADED = new Set(['llm-rubric', 'g-eval', 'factuality', 'model-graded-factuality', 'model-graded-closedqa', 'context-faithfulness',
  'context-relevance', 'context-recall', 'answer-relevance', 'select-best', 'search-rubric'].flatMap((t) => [t, `not-${t}`]));
function judgeDefaults() {
  if (!fs.existsSync(JUDGE_CONFIG)) return { options: {}, assert: [] };
  const d = yaml.load(fs.readFileSync(JUDGE_CONFIG, 'utf8')).defaultTest || {};
  return { options: d.options || {}, assert: d.assert || [] };
}
const BUILT_IN = ['qt_golden_dataset.csv', 'qt_assertion_showcase.yaml', 'qt_python_showcase.yaml', 'qt_judge_dataset.csv', 'qt_judge_showcase.yaml'];
const MY_TESTS = 'my_tests.csv';

/**
 * Labels for every named metric. `needs` = the test var a metric reads;
 * a test without that var simply skips the metric instead of failing it.
 */
const METRIC_INFO = {
  hit_rate_at_3:        { group: 'Retrieval',  label: 'Hit rate @3',          help: 'Right page somewhere in the top 3', needs: 'expected_docs' },
  top1_accuracy:        { group: 'Retrieval',  label: 'Top-1 accuracy',       help: 'Right page ranked first', needs: 'expected_docs' },
  mrr:                  { group: 'Retrieval',  label: 'MRR',                  help: '1 / rank of the first right page', needs: 'expected_docs' },
  context_recall:       { group: 'Retrieval',  label: 'Context recall',       help: 'Share of needed pages retrieved', needs: 'expected_docs' },
  context_precision:    { group: 'Retrieval',  label: 'Context precision',    help: 'Share of retrieved pages that are relevant', needs: 'expected_docs' },
  answer_correctness:   { group: 'Generation', label: 'Answer correctness',   help: 'Right fact in the right shape (regex)', needs: 'must_match' },
  no_wrong_facts:       { group: 'Generation', label: 'No wrong facts',       help: 'Known wrong value absent (not-regex)', needs: 'must_not_match' },
  citation_grounding:   { group: 'Generation', label: 'Citation grounding',   help: 'Every citation was really retrieved' },
  citation_accuracy:    { group: 'Generation', label: 'Citation accuracy',    help: 'The expected page is cited', needs: 'expected_docs' },
  numeric_faithfulness: { group: 'Generation', label: 'Numeric faithfulness', help: 'Every number exists in the retrieved pages' },
  conciseness:          { group: 'Safety and speed', label: 'Conciseness',    help: 'Answer within the word budget' },
  safety:               { group: 'Safety and speed', label: 'Safety',         help: 'No ID-number or system-prompt leaks' },
  response_contract:    { group: 'Safety and speed', label: 'Response contract', help: 'App JSON keeps its schema' },
  latency:              { group: 'Safety and speed', label: 'Latency',        help: 'Round trip under the time budget' },
  // LLM-as-a-judge metrics (promptfooconfig.llm-judge.yaml). inScope: skipped for off-topic tests (no pages to judge).
  judge_faithfulness:      { group: 'LLM judge', label: 'Faithfulness (judge)',      help: 'Every claim is supported by the retrieved pages', inScope: true },
  judge_context_relevance: { group: 'LLM judge', label: 'Context relevance (judge)', help: 'Share of retrieved text needed for the question', inScope: true },
  judge_context_recall:    { group: 'LLM judge', label: 'Context recall (judge)',    help: 'Pages contain everything the reference says', needs: 'reference_answer', inScope: true },
  judge_factuality:        { group: 'LLM judge', label: 'Factuality (judge)',        help: 'Answer agrees with the reference answer', needs: 'reference_answer' },
  judge_helpfulness:       { group: 'LLM judge', label: 'Helpfulness rubric (judge)', help: 'Plain-English rubric graded by the judge' },
  judge_tone:              { group: 'Test-specific', label: 'Tone rubric (judge)',   help: 'llm-rubric written in the test' },
  judge_closedqa:          { group: 'Test-specific', label: 'Closed QA (judge)',     help: 'Yes/no criterion graded by the judge' },
  judge_geval:             { group: 'Test-specific', label: 'G-Eval (judge)',        help: 'Multi-criteria score out of 10' },
  // Metrics that only appear in test files' own assertions
  format_shapes:        { group: 'Test-specific', label: 'Format shapes',     help: 'Email, mobile and clock-time shapes' },
  business_rules:       { group: 'Test-specific', label: 'Business rules',    help: 'Custom JavaScript rules' },
  citation_format:      { group: 'Test-specific', label: 'Citation format',   help: 'Citation closes the answer' },
  reference_overlap:    { group: 'Test-specific', label: 'Reference overlap', help: 'ROUGE-N overlap with a reference' },
};
const info = (name) => METRIC_INFO[name] || { group: 'Other', label: name, help: '' };

function mainConfig(lang) {
  return yaml.load(fs.readFileSync(CONFIGS[langOf(lang)], 'utf8'));
}

/** Is Python installed? promptfoo needs it for type: python assertions. */
let pythonCache = null;
function pythonInfo() {
  if (pythonCache) return pythonCache;
  const { spawnSync } = require('child_process');
  const candidates = process.env.PROMPTFOO_PYTHON ? [process.env.PROMPTFOO_PYTHON] : ['python', 'python3', 'py'];
  for (const cmd of candidates) {
    try {
      const r = spawnSync(cmd, ['--version'], { encoding: 'utf8', timeout: 5000, windowsHide: true });
      const out = `${r.stdout || ''}${r.stderr || ''}`.trim();
      if (r.status === 0 && /^Python 3\./.test(out)) return (pythonCache = { available: true, command: cmd, version: out });
    } catch (_) { /* try the next one */ }
  }
  return (pythonCache = { available: false, command: null, version: null });
}

/** Metrics the user can pick: one entry per metric name in defaultTest. */
function metrics(lang) {
  // deterministic metrics in the chosen language + LLM-judge metrics (same for both languages)
  const asserts = [...((mainConfig(lang).defaultTest || {}).assert || []), ...judgeDefaults().assert];
  const byName = new Map();
  for (const a of asserts) {
    const name = a.metric || a.type;
    if (!byName.has(name)) byName.set(name, { name, ...info(name), assertions: [] });
    byName.get(name).assertions.push(a);
  }
  return [...byName.values()].map((m) => ({ ...m, types: [...new Set(m.assertions.map((a) => a.type))], judge: m.assertions.some((a) => MODEL_GRADED.has(a.type)) }));
}

// ---------------- CSV (small RFC-4180 reader, handles quotes) ----------------
function parseCsv(text) {
  const rows = [];
  let row = [], field = '', q = false;
  text = text.replace(/^\uFEFF/, '');
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"' && text[i + 1] === '"') { field += '"'; i++; }
      else if (c === '"') q = false;
      else field += c;
    } else if (c === '"') q = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && text[i + 1] === '\n') i++;
      row.push(field); field = '';
      if (row.some((v) => v !== '')) rows.push(row);
      row = [];
    } else field += c;
  }
  row.push(field);
  if (row.some((v) => v !== '')) rows.push(row);
  const [header = [], ...data] = rows;
  return data.map((r) => Object.fromEntries(header.map((h, i) => [h.trim(), (r[i] ?? '').trim()])));
}

const csvCell = (v) => (/[",\r\n]/.test(v) ? `"${String(v).replace(/"/g, '""')}"` : String(v));

/** "__expected" cells: "type:value", e.g. "icontains:refund" or "regex:\b7 days\b". */
function assertionFromCell(cell) {
  const m = cell.match(/^(not-)?([a-z-]+)(?:\((\d+(?:\.\d+)?)\))?:([\s\S]*)$/);
  if (!m) return { type: 'equals', value: cell };
  const type = (m[1] || '') + m[2];
  const a = { type, value: m[4].trim() };
  if (/-(any|all)$/.test(type)) a.value = a.value.split(/(?<!\\),/).map((v) => v.trim());
  if (m[3]) a.threshold = Number(m[3]);
  return a;
}

function testsFromCsv(text) {
  return parseCsv(text).map((row) => {
    const t = { vars: {}, assert: [], metadata: {} };
    for (const [k, v] of Object.entries(row)) {
      if (k === '__description') t.description = v;
      else if (k.startsWith('__metadata:')) { if (v) t.metadata[k.slice(11)] = v; }
      else if (k.startsWith('__expected')) { if (v) t.assert.push(assertionFromCell(v)); }
      else if (!k.startsWith('__')) t.vars[k] = v;
    }
    return t;
  });
}

function testsFromYaml(text) {
  const doc = yaml.load(text);
  const list = Array.isArray(doc) ? doc : doc && Array.isArray(doc.tests) ? doc.tests : null;
  if (!list) throw new Error('A YAML test file must be a list of tests (or have a "tests:" list).');
  return list.map((t) => ({ description: t.description, vars: { ...(t.vars || {}) }, assert: t.assert || [], metadata: t.metadata || {}, options: t.options }));
}

function readTests(file) {
  const full = path.join(TESTS_DIR, file);
  const text = fs.readFileSync(full, 'utf8');
  const tests = file.endsWith('.csv') ? testsFromCsv(text) : testsFromYaml(text);
  return tests.map((t, i) => ({
    ...t,
    id: `${file}#${i}`,
    file,
    description: t.description || t.vars.question || `Test ${i + 1}`,
  }));
}

function safeName(name) {
  const base = path.basename(String(name || '')).replace(/[^\w.\-]/g, '_');
  if (!/\.(csv|ya?ml)$/i.test(base)) throw new Error('Only .csv, .yaml or .yml test files are allowed.');
  return base;
}

/** Every test file with its tests (for the Test Lab file picker). */
function testFiles() {
  if (!fs.existsSync(TESTS_DIR)) return [];
  return fs.readdirSync(TESTS_DIR).filter((f) => /\.(csv|ya?ml)$/i.test(f)).sort((a, b) => {
    const ia = BUILT_IN.indexOf(a), ib = BUILT_IN.indexOf(b);
    return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib) || a.localeCompare(b);
  }).map((file) => {
    try {
      const tests = readTests(file);
      return {
        file, builtIn: BUILT_IN.includes(file), count: tests.length, error: null,
        tests: tests.map((t) => ({ id: t.id, description: t.description, question: t.vars.question || '', expected_docs: t.vars.expected_docs || '', ownChecks: t.assert.length })),
      };
    } catch (err) {
      return { file, builtIn: BUILT_IN.includes(file), count: 0, error: err.message, tests: [] };
    }
  });
}

/** Validate one regex the same way promptfoo will run it (JavaScript RegExp). */
function checkRegex(label, value) {
  if (!value) return;
  if (/\(\?i\)/.test(value)) throw new Error(`${label}: JavaScript regex has no (?i) flag. Use letter sets like [Rr]efund.`);
  try { new RegExp(value); } catch (err) { throw new Error(`${label} is not a valid regex: ${err.message}`); }
}

/** Append one test case to tests/my_tests.csv (created on first use). */
function addTest(body) {
  const description = String(body.description || '').trim();
  const question = String(body.question || '').trim();
  const expected = String(body.expected_docs || 'NONE').trim() || 'NONE';
  const mustMatch = String(body.must_match || '').trim();
  const mustNot = String(body.must_not_match || '').trim();
  if (!question) throw new Error('Write the student question.');
  if (!/^(NONE|DOC-\d{3}([;,]\s*DOC-\d{3})*)$/.test(expected)) throw new Error('Expected pages must be NONE or IDs like DOC-102 or DOC-101;DOC-102.');
  checkRegex('Must match', mustMatch);
  checkRegex('Must not match', mustNot);
  const file = path.join(TESTS_DIR, MY_TESTS);
  const header = ['__description', '__metadata:category', 'question', 'expected_docs', 'must_match', 'must_not_match'];
  if (!fs.existsSync(file)) fs.writeFileSync(file, header.join(',') + '\r\n');
  const row = [description || question, 'custom', question, expected.replace(/,\s*/g, ';'), mustMatch, mustNot].map(csvCell).join(',');
  fs.appendFileSync(file, row + '\r\n');
  return { ok: true, message: `Added to tests/${MY_TESTS}.`, file: MY_TESTS };
}

/** Save an uploaded test file into /tests after checking it parses. */
function uploadFile(body) {
  const name = safeName(body.name);
  if (BUILT_IN.includes(name)) throw new Error(`${name} is a built-in file. Rename your file and upload again.`);
  const content = String(body.content || '');
  if (!content.trim()) throw new Error('The file is empty.');
  if (content.length > 500000) throw new Error('The file is larger than 500 KB.');
  const tests = name.endsWith('.csv') ? testsFromCsv(content) : testsFromYaml(content);
  if (!tests.length) throw new Error('No tests found in the file.');
  if (!tests.every((t) => t.vars && t.vars.question)) throw new Error('Every test needs a "question" var (a "question" column in CSV).');
  fs.writeFileSync(path.join(TESTS_DIR, name), content);
  return { ok: true, message: `Uploaded ${name} with ${tests.length} tests.`, file: name };
}

function deleteFile(name) {
  const file = safeName(name);
  if (BUILT_IN.includes(file)) throw new Error('Built-in test files cannot be deleted.');
  const full = path.join(TESTS_DIR, file);
  if (!fs.existsSync(full)) throw new Error('File not found.');
  fs.unlinkSync(full);
  return { ok: true, message: `Deleted ${file}.` };
}

module.exports = { METRIC_INFO, MODEL_GRADED, judgeDefaults, info, metrics, mainConfig, pythonInfo, langOf, testFiles, readTests, addTest, uploadFile, deleteFile, TESTS_DIR };
