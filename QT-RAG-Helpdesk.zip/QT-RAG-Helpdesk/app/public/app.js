/* =====================================================================
 *  QUALITY THOUGHT | Student Helpdesk RAG
 *  Transforming Dreams! Redefining Future!
 *  File: app/public/app.js   (Chat · Test lab · Settings)
 * ===================================================================== */
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pct = (v) => `${Math.round((v || 0) * 100)}%`;

async function api(path, opts = {}) {
  const res = await fetch(path, {
    method: opts.method || (opts.body ? 'POST' : 'GET'),
    headers: opts.body ? { 'Content-Type': 'application/json' } : undefined,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.error) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}
function note(el, text, kind = 'info') {
  const box = typeof el === 'string' ? $(el) : el;
  box.innerHTML = text ? `<p class="msg ${kind}" role="status">${esc(text)}</p>` : '';
}

/* ============================ TABS ============================ */
const TABS = ['chat', 'lab', 'settings'];
const loaded = {};
function showTab() {
  const tab = TABS.includes(location.hash.slice(1)) ? location.hash.slice(1) : 'chat';
  TABS.forEach((t) => $(`tab-${t}`).classList.toggle('hidden', t !== tab));
  document.querySelectorAll('nav a').forEach((a) => a.setAttribute('aria-current', a.dataset.tab === tab ? 'page' : 'false'));
  if (!loaded[tab]) { loaded[tab] = true; ({ lab: initLab, settings: initSettings })[tab]?.(); }
  if (tab === 'settings') loadSettings();
  if (tab === 'lab') refreshLlmLine();
}
window.addEventListener('hashchange', showTab);

async function refreshStatus() {
  try {
    const h = await api('/api/health');
    $('status').innerHTML = `<span class="dot ${h.mode === 'groq' ? '' : 'off'}"></span><b>${h.mode === 'groq' ? 'Groq' : 'Offline mode'}</b> · ${esc(h.mode === 'groq' ? h.model : 'add a key in Settings')}`;
    return h;
  } catch (_) { $('status').textContent = 'Server not reachable'; return null; }
}

/* ============================ CHAT ============================ */
const SAMPLES = ['What is the course fee?', 'Can I get a refund?', 'Weekday batch timings?', 'When will I get my certificate?', 'How do I contact support?', 'Who won the cricket world cup?'];
SAMPLES.forEach((s) => {
  const b = document.createElement('button');
  b.type = 'button'; b.className = 'sample'; b.textContent = s;
  b.onclick = () => { $('q').value = s; $('chat-form').requestSubmit(); };
  $('samples').appendChild(b);
});
function bubble(html, cls) {
  const d = document.createElement('div');
  d.className = 'bubble ' + cls; d.innerHTML = html;
  $('log').appendChild(d); $('log').scrollTop = $('log').scrollHeight;
  return d;
}
function showPages(list) {
  if (!list.length) { $('pages').innerHTML = '<div class="empty">No page scored high enough, so the helpdesk gave the safe fallback answer instead of guessing.</div>'; return; }
  const max = list[0].score;
  $('pages').innerHTML = list.map((p) => `
    <div class="pagecard"><div class="rank">${p.rank}</div>
      <div><span class="id">${esc(p.id)}</span><h3>${esc(p.title)}</h3>
        <div class="bar"><span style="width:${Math.max(8, (p.score / max) * 100)}%"></span></div>
        <small class="sub">BM25 score ${p.score}</small></div></div>`).join('');
}
$('chat-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const question = $('q').value.trim();
  if (!question) return;
  bubble(esc(question), 'me'); $('q').value = ''; $('send').disabled = true;
  const wait = bubble('Looking it up…', 'bot');
  try {
    const d = await api('/api/ask', { body: { question } });
    wait.className = 'bubble bot' + (d.fallback ? ' fallback' : '');
    wait.innerHTML = `${esc(d.answer)}<div class="meta">${d.citations.map((c) => `<span class="pill cite">${esc(c)}</span>`).join('')}<span class="pill">${d.latency_ms} ms</span><span class="pill">${esc(d.model)}</span></div>`;
    showPages(d.retrieved);
  } catch (err) {
    wait.className = 'bubble bot fallback';
    wait.textContent = 'Could not get an answer: ' + err.message;
  } finally { $('send').disabled = false; $('q').focus(); }
});

/* ============================ TEST LAB ============================ */
const lab = { groq: false, lang: 'javascript', python: null, files: [], metrics: [], kb: [], selFiles: new Set(), selTests: {}, selMetrics: new Set(), open: new Set(), runId: null, poll: null, failedOnly: false, expanded: new Set(), run: null };

async function initLab() {
  ['btn-add', 'btn-upload'].forEach((id) => $(id).addEventListener('click', () => openDialog(id === 'btn-add' ? 'dlg-add' : 'dlg-upload')));
  $('opt-own').addEventListener('change', updatePlan);
  document.querySelectorAll('input[name=lang]').forEach((r) => r.addEventListener('change', async () => {
    lab.lang = r.value; await loadCatalog();
  }));
  $('opt-filter').addEventListener('input', debounce(updatePlan, 300));
  $('btn-run').addEventListener('click', startRun);
  $('btn-stop').addEventListener('click', async () => { try { await api('/api/runs/stop', { method: 'POST', body: {} }); } catch (err) { note('run-msg', err.message, 'err'); } });
  $('history').addEventListener('change', () => { if ($('history').value) loadRun($('history').value); });
  await loadCatalog(true);
  await loadHistory();
  const runs = await api('/api/runs').catch(() => []);
  const running = runs.find((r) => r.status === 'running');
  if (running) watchRun(running.id);
  else if (runs[0]) loadRun(runs[0].id);
}

async function loadCatalog(first) {
  try {
    const c = await api(`/api/tests/catalog?lang=${lab.lang}`);
    lab.files = c.files; lab.metrics = c.metrics; lab.kb = c.kb; lab.python = c.python;
    showPython();
    if (first) {
      c.files.filter((f) => f.builtIn && !/python|judge/.test(f.file)).forEach((f) => lab.selFiles.add(f.file));
      c.metrics.filter((m) => !m.judge).forEach((m) => lab.selMetrics.add(m.name));
    }
    c.files.forEach((f) => { if (!lab.selTests[f.file]) lab.selTests[f.file] = new Set(f.tests.map((t) => t.id)); });
    renderFiles(); renderMetrics(); updatePlan();
  } catch (err) {
    $('files').innerHTML = `<p class="msg err">${esc(err.message)}</p>`;
    $('metrics').innerHTML = '';
  }
}

function renderFiles() {
  $('files').innerHTML = lab.files.map((f) => {
    const sel = lab.selTests[f.file];
    const open = lab.open.has(f.file);
    return `<div class="file">
      <div class="file-row">
        <input type="checkbox" id="f-${esc(f.file)}" data-file="${esc(f.file)}" ${lab.selFiles.has(f.file) ? 'checked' : ''} ${f.error ? 'disabled' : ''} aria-label="Run ${esc(f.file)}">
        <label class="name" for="f-${esc(f.file)}">${esc(f.file)}<small>${f.error ? `<span style="color:var(--bad)">${esc(f.error)}</span>` : `${sel.size} of ${f.count} tests${f.builtIn ? ' · built-in' : ''}`}</small></label>
        ${f.error ? '' : `<button type="button" class="link" data-toggle="${esc(f.file)}" aria-expanded="${open}">${open ? 'Close' : 'Choose'}</button>`}
        ${f.builtIn ? '' : `<button type="button" class="link" data-del="${esc(f.file)}" aria-label="Delete ${esc(f.file)}">Delete</button>`}
      </div>
      ${open ? `<div class="testlist">
        <div class="row" style="margin-bottom:.2rem"><button type="button" class="link" data-all="${esc(f.file)}">All</button><button type="button" class="link" data-none="${esc(f.file)}">None</button></div>
        ${f.tests.map((t) => `<label class="check"><input type="checkbox" data-test="${esc(t.id)}" data-tfile="${esc(f.file)}" ${sel.has(t.id) ? 'checked' : ''}><span>${esc(t.description)}${t.expected_docs ? ` <span class="pill">${esc(t.expected_docs)}</span>` : ''}</span></label>`).join('')}
      </div>` : ''}
    </div>`;
  }).join('') || '<p class="sub">No test files yet.</p>';

  $('files').querySelectorAll('[data-file]').forEach((el) => el.addEventListener('change', () => {
    el.checked ? lab.selFiles.add(el.dataset.file) : lab.selFiles.delete(el.dataset.file); updatePlan();
  }));
  $('files').querySelectorAll('[data-toggle]').forEach((el) => el.addEventListener('click', () => {
    const f = el.dataset.toggle; lab.open.has(f) ? lab.open.delete(f) : lab.open.add(f); renderFiles();
  }));
  $('files').querySelectorAll('[data-test]').forEach((el) => el.addEventListener('change', () => {
    const set = lab.selTests[el.dataset.tfile];
    el.checked ? set.add(el.dataset.test) : set.delete(el.dataset.test);
    renderFiles(); updatePlan();
  }));
  $('files').querySelectorAll('[data-all],[data-none]').forEach((el) => el.addEventListener('click', () => {
    const file = el.dataset.all || el.dataset.none;
    const f = lab.files.find((x) => x.file === file);
    lab.selTests[file] = new Set(el.dataset.all ? f.tests.map((t) => t.id) : []);
    renderFiles(); updatePlan();
  }));
  $('files').querySelectorAll('[data-del]').forEach((el) => el.addEventListener('click', async () => {
    if (!confirm(`Delete tests/${el.dataset.del}? This cannot be undone.`)) return;
    try { await api(`/api/tests/file?name=${encodeURIComponent(el.dataset.del)}`, { method: 'DELETE' }); lab.selFiles.delete(el.dataset.del); await loadCatalog(); }
    catch (err) { alert(err.message); }
  }));
}

const GROUPS = ['Retrieval', 'Generation', 'Safety and speed'];
function renderMetrics() {
  const presets = [['All deterministic', () => lab.metrics.filter((m) => !m.judge).map((m) => m.name)], ...GROUPS.map((g) => [g === 'Safety and speed' ? 'Safety and speed' : `${g} only`, () => lab.metrics.filter((m) => m.group === g).map((m) => m.name)]), ['LLM judge', () => (lab.groq ? lab.metrics.filter((m) => m.judge).map((m) => m.name) : [])], ['None', () => []]];
  $('presets').innerHTML = presets.map(([label], i) => `<button type="button" data-preset="${i}">${esc(label)}</button>`).join('');
  $('presets').querySelectorAll('[data-preset]').forEach((b) => b.addEventListener('click', () => {
    lab.selMetrics = new Set(presets[b.dataset.preset][1]()); renderMetrics(); updatePlan();
  }));
  const groups = [...new Set(lab.metrics.map((m) => m.group))];
  $('metrics').innerHTML = groups.map((g) => {
    const items = lab.metrics.filter((m) => m.group === g);
    const n = items.filter((m) => lab.selMetrics.has(m.name)).length;
    const judge = items.some((m) => m.judge), locked = judge && !lab.groq;
    return `<div class="group${judge ? ' judge' : ''}">
      <label class="check"><input type="checkbox" data-group="${esc(g)}" ${n === items.length ? 'checked' : ''} ${locked ? 'disabled' : ''}><span>${esc(g)} <span class="pill">${n}/${items.length}</span></span></label>
      ${judge ? `<p class="hint" style="margin:.1rem 0 .3rem 1.6rem">${locked ? 'Needs a Groq key: the judge is an LLM too. <a href="#settings">Add it in Settings</a>.' : 'A second LLM grades each answer: 1 or 2 extra Groq calls per check, slower, scores can vary a little.'}</p>` : ''}
      <div class="items">${items.map((m) => `
        <label class="check"><input type="checkbox" data-metric="${esc(m.name)}" ${lab.selMetrics.has(m.name) ? 'checked' : ''} ${m.judge && !lab.groq ? 'disabled' : ''}>
          <span>${esc(m.label)}<small>${esc(m.help)} · ${m.types.map(esc).join(', ')}${m.needs ? ` · needs <code>${esc(m.needs)}</code>` : ''}</small></span></label>`).join('')}
      </div></div>`;
  }).join('');
  $('metrics').querySelectorAll('[data-group]').forEach((el) => {
    const items = lab.metrics.filter((m) => m.group === el.dataset.group);
    const n = items.filter((m) => lab.selMetrics.has(m.name)).length;
    el.indeterminate = n > 0 && n < items.length;
    el.addEventListener('change', () => { items.forEach((m) => (el.checked ? lab.selMetrics.add(m.name) : lab.selMetrics.delete(m.name))); renderMetrics(); updatePlan(); });
  });
  $('metrics').querySelectorAll('[data-metric]').forEach((el) => el.addEventListener('change', () => {
    el.checked ? lab.selMetrics.add(el.dataset.metric) : lab.selMetrics.delete(el.dataset.metric); renderMetrics(); updatePlan();
  }));
}

function showPython() {
  const p = lab.python || {};
  $('py-line').innerHTML = p.available
    ? `${esc(p.version)} found. Python metrics and <code>qt_python_showcase.yaml</code> can run.`
    : 'Python 3 not found: Python metrics are off. Install it from <a href="https://www.python.org/downloads/" target="_blank" rel="noopener">python.org</a> and restart the app.';
  const py = document.querySelector('input[name=lang][value=python]');
  py.disabled = !p.available;
  if (!p.available && lab.lang === 'python') { lab.lang = 'javascript'; document.querySelector('input[name=lang][value=javascript]').checked = true; }
}

function request() {
  const files = [...lab.selFiles].filter((f) => lab.files.some((x) => x.file === f));
  const testIds = files.flatMap((f) => [...(lab.selTests[f] || [])]);
  return { files, metrics: [...lab.selMetrics], testIds, includeOwn: $('opt-own').checked, filter: $('opt-filter').value.trim(), lang: lab.lang };
}

let planSeq = 0;
async function updatePlan() {
  const req = request();
  const seq = ++planSeq;
  if (!req.files.length) { $('plan').innerHTML = 'Pick at least one test file.'; $('btn-run').disabled = true; return; }
  try {
    const p = await api('/api/runs/preview', { body: req });
    if (seq !== planSeq) return;
    $('plan').innerHTML = p.tests
      ? `<b>${p.tests}</b> tests · <b>${p.checks}</b> checks<br><small class="sub">${req.metrics.length} metrics in ${req.lang === 'python' ? 'Python' : 'JavaScript'}${req.includeOwn ? ' + each test’s own checks' : ''}${p.judgeChecks ? ` · <b>${p.judgeChecks}</b> graded by the LLM judge` : ''}</small>`
      : 'No checks to run. Pick metrics, or include each test’s own checks.';
    $('btn-run').disabled = !p.tests || Boolean(lab.poll);
  } catch (err) { $('plan').textContent = err.message; $('btn-run').disabled = true; }
}

async function refreshLlmLine() {
  const h = await refreshStatus();
  const groq = Boolean(h && h.mode === 'groq');
  if (groq !== lab.groq) { lab.groq = groq; if (!groq) lab.metrics.filter((m) => m.judge).forEach((m) => lab.selMetrics.delete(m.name)); if (lab.metrics.length) { renderMetrics(); updatePlan(); } }
  if (h) $('llm-line').innerHTML = h.mode === 'groq'
    ? `Answers from Groq <b>${esc(h.model)}</b> at temperature <b>${h.temperature}</b>. Free keys are rate limited, so tests run one at a time.${h.temperature > 0 ? ' <a href="#settings">Set temperature to 0</a> for repeatable results.' : ''}`
    : 'Offline demo mode: answers copy the best page. <a href="#settings">Add a Groq key</a> for real LLM answers.';
}

async function startRun() {
  note('run-msg', '');
  try {
    const run = await api('/api/runs', { body: request() });
    lab.expanded.clear();
    watchRun(run.id);
  } catch (err) { note('run-msg', err.message, 'err'); }
}

function watchRun(id) {
  lab.runId = id;
  $('results').classList.add('hidden');
  $('run-state').classList.remove('hidden');
  $('btn-stop').classList.remove('hidden');
  $('btn-run').disabled = true;
  clearInterval(lab.poll);
  const tick = async () => {
    try {
      const r = await api(`/api/runs/${id}`);
      $('progress').style.width = `${Math.round((r.done / Math.max(r.total, 1)) * 100)}%`;
      $('run-text').textContent = r.status === 'running' ? `Running: ${r.done} of ${r.total} tests answered…` : `Run ${r.status}.`;
      $('run-log').textContent = r.log.join('\n');
      if (r.status !== 'running') {
        clearInterval(lab.poll); lab.poll = null;
        $('btn-stop').classList.add('hidden');
        if (r.status !== 'finished') note('run-msg', r.status === 'stopped' ? 'Run stopped. No results saved.' : 'The run failed. Open “promptfoo output” to see why.', 'err');
        await loadHistory(); $('history').value = id;
        showResults(r);
        updatePlan();
        if (r.summary) $('results').scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    } catch (err) { clearInterval(lab.poll); lab.poll = null; note('run-msg', err.message, 'err'); }
  };
  lab.poll = setInterval(tick, 1000);
  tick();
}

function runSettings(r) {
  const st = r.settings;
  const llm = (r.mode === 'groq' ? `Groq ${esc(r.model)}` : 'Offline mode') + ` · metrics in ${r.request && r.request.lang === 'python' ? 'Python' : 'JavaScript'}`;
  if (!st) return llm;
  return `${llm} · temperature ${st.temperature} · max ${st.maxTokens} tokens · ${st.topK} pages · min score ${st.minScore}`;
}

async function loadHistory() {
  const runs = await api('/api/runs').catch(() => []);
  $('history').innerHTML = '<option value="">Previous runs…</option>' + runs.map((r) =>
    `<option value="${esc(r.id)}">${esc(new Date(r.startedAt).toLocaleString())} · ${r.total} tests · ${r.metrics} ${r.lang === 'python' ? 'Python' : 'JS'} metrics${r.settings && r.mode === 'groq' ? ` · temp ${r.settings.temperature}` : ''} · ${esc(r.status)}</option>`).join('');
}

async function loadRun(id) {
  try {
    const r = await api(`/api/runs/${id}`);
    $('history').value = id;
    $('run-state').classList.remove('hidden');
    $('progress').style.width = r.status === 'finished' ? '100%' : '0';
    $('run-text').textContent = `Run ${r.status} · ${new Date(r.startedAt).toLocaleString()}`;
    $('run-log').textContent = (r.log || []).join('\n');
    lab.expanded.clear();
    showResults(r);
  } catch (err) { note('run-msg', err.message, 'err'); }
}

function tone(v) { return v >= 0.999 ? 'good' : v >= 0.8 ? 'warn' : 'bad'; }

function showResults(r) {
  lab.run = r;
  const s = r.summary;
  if (!s) { $('results').classList.add('hidden'); return; }
  const order = lab.metrics.map((m) => m.name);
  const metrics = [...s.metrics].sort((a, b) => (order.indexOf(a.name) + 1 || 99) - (order.indexOf(b.name) + 1 || 99));
  const groups = [...new Set(metrics.map((m) => m.group))];
  const tests = s.tests.filter((t) => !lab.failedOnly || !t.success);
  const files = r.request.files.map(esc).join(', ');

  $('results').innerHTML = `
    <div class="page-head" style="margin-bottom:0">
      <div><h2 style="font-size:1.35rem">Results</h2>
        <p class="sub">${files} · ${(s.durationMs / 1000).toFixed(1)} s</p>
        <p class="sub">${runSettings(r)}</p></div>
      <div class="row">
        <a class="btn ghost small" href="${r.links.html}" target="_blank" rel="noopener">promptfoo report</a>
        <a class="btn ghost small" href="${r.links.json}" download="qt-results-${esc(r.id)}.json">Download JSON</a>
        <a class="btn ghost small" href="${r.links.config}" target="_blank" rel="noopener">Run config</a>
      </div>
    </div>
    <div class="stats">
      <div class="stat"><b>${s.tests.length}</b>tests</div>
      <div class="stat pass"><b>${s.passed}</b>passed</div>
      <div class="stat fail"><b>${s.failed}</b>failed</div>
      <div class="stat"><b>${s.errors}</b>errors</div>
      <div class="stat"><b>${s.ownChecks ? `${s.ownPassed}/${s.ownChecks}` : '–'}</b>tests’ own checks</div>
    </div>
    ${metrics.length ? groups.map((g) => `<div class="mgroup">${esc(g)}</div><div class="metric-grid">${metrics.filter((m) => m.group === g).map((m) => `
      <div class="mcard ${tone(m.passed / m.count)}" title="${esc(m.help)} (value = average score)">
        <div class="top"><b>${esc(m.label)}</b><span class="val">${pct(m.average)}</span></div>
        <div class="bar"><span style="width:${pct(m.average)}"></span></div>
        <small>${m.passed} of ${m.count} tests passed · <code>${esc(m.name)}</code></small>
      </div>`).join('')}</div>`).join('') : '<p class="msg info">No metrics were selected for this run: only the tests’ own checks ran.</p>'}
    <div class="toolbar">
      <h3>Every test</h3>
      <label class="check" style="padding:0"><input type="checkbox" id="failed-only" ${lab.failedOnly ? 'checked' : ''}><span>Failed only</span></label>
    </div>
    <div class="table-wrap"><table class="matrix">
      <thead><tr><th scope="col">Test</th><th scope="col">Result</th>
        ${metrics.map((m) => `<th scope="col" title="${esc(m.help)}">${esc(m.label)}</th>`).join('')}
        ${s.ownChecks ? '<th scope="col">Own checks</th>' : ''}</tr></thead>
      <tbody>${tests.map((t) => {
        const i = s.tests.indexOf(t);
        const own = t.own.length ? `${t.own.filter((o) => o.pass).length}/${t.own.length}` : '';
        return `<tr data-row="${i}" tabindex="0" aria-expanded="${lab.expanded.has(i)}">
          <td><b>${esc(t.description)}</b><br><small class="sub">${esc(t.source.split('#')[0])}</small></td>
          <td><span class="res ${t.success ? '' : 'ko'}">${t.success ? 'PASS' : 'FAIL'}</span></td>
          ${metrics.map((m) => { const c = t.metrics[m.name]; return `<td>${c ? `<span class="cell ${c.pass ? 'ok' : 'ko'}" title="score ${c.score}">${c.pass ? '✓' : '✗'}</span>` : '<span class="cell na" title="not run for this test">–</span>'}</td>`; }).join('')}
          ${s.ownChecks ? `<td>${own ? `<span class="cell ${t.own.every((o) => o.pass) ? 'ok' : 'ko'}" style="width:auto;padding:0 .4rem">${own}</span>` : '<span class="cell na">–</span>'}</td>` : ''}
        </tr>${lab.expanded.has(i) ? detailRow(t, metrics.length + 2 + (s.ownChecks ? 1 : 0)) : ''}`;
      }).join('') || `<tr><td colspan="${metrics.length + 3}">No failed tests.</td></tr>`}</tbody>
    </table></div>`;
  $('results').classList.remove('hidden');

  $('failed-only').addEventListener('change', (e) => { lab.failedOnly = e.target.checked; showResults(lab.run); });
  $('results').querySelectorAll('tr[data-row]').forEach((tr) => {
    const toggle = () => { const i = Number(tr.dataset.row); lab.expanded.has(i) ? lab.expanded.delete(i) : lab.expanded.add(i); showResults(lab.run); };
    tr.addEventListener('click', toggle);
    tr.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); } });
  });
}

function detailRow(t, span) {
  const expected = String(t.expected_docs || '').split(/[;,]/).map((x) => x.trim()).filter((x) => x && x !== 'NONE');
  const fails = [
    ...Object.entries(t.metrics).filter(([, c]) => !c.pass).flatMap(([name, c]) => c.reasons.map((r) => `<li><b>${esc(name)}</b> ${esc(r)}</li>`)),
    ...t.own.filter((o) => !o.pass).map((o) => `<li><b>${esc(o.type)}</b> ${esc(o.reason)}</li>`),
  ];
  return `<tr class="detail"><td colspan="${span}"><div class="detail-box">
    <div><p><b>Question</b><br>${esc(t.question)}</p><p><b>Answer</b><br>${esc(t.answer || t.error || '(no answer)')}</p></div>
    <div><p><b>Pages retrieved</b><br>${t.retrieved.map((p) => `<span class="pill ${expected.includes(p.id) ? 'good' : ''}">#${p.rank} ${esc(p.id)} · ${p.score}</span>`).join(' ') || '<span class="pill">none (fallback)</span>'}</p>
      <p><b>Expected</b><br><span class="pill">${esc(t.expected_docs || 'not set')}</span> ${t.latencyMs ? `<span class="pill">${t.latencyMs} ms</span>` : ''}</p>
      ${fails.length ? `<p><b>Why it failed</b></p><ul class="reasons">${fails.join('')}</ul>` : '<p class="pill good">Every check passed</p>'}</div>
  </div></td></tr>`;
}

/* ---------- dialogs: add a test, upload a file ---------- */
function openDialog(id) {
  const d = $(id);
  if (id === 'dlg-add') {
    $('add-docs').innerHTML = lab.kb.map((k) => `<label class="check"><input type="checkbox" value="${esc(k.id)}"><span><b>${esc(k.id)}</b> ${esc(k.title)}</span></label>`).join('');
    note('add-msg', '');
  } else note('up-msg', '');
  d.showModal();
}
document.querySelectorAll('dialog [data-close]').forEach((b) => b.addEventListener('click', () => b.closest('dialog').close()));

$('add-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const docs = [...$('add-docs').querySelectorAll('input:checked')].map((i) => i.value);
  try {
    const r = await api('/api/tests/add', { body: {
      question: $('add-question').value, description: $('add-desc').value,
      expected_docs: docs.length ? docs.join(';') : 'NONE',
      must_match: $('add-match').value, must_not_match: $('add-notmatch').value,
    } });
    $('dlg-add').close();
    ['add-question', 'add-desc', 'add-match', 'add-notmatch'].forEach((id) => { $(id).value = ''; });
    lab.selFiles.add(r.file); delete lab.selTests[r.file];
    await loadCatalog();
    note('run-msg', r.message, 'ok');
  } catch (err) { note('add-msg', err.message, 'err'); }
});

$('up-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const file = $('up-file').files[0];
  if (!file) return note('up-msg', 'Choose a file first.', 'err');
  try {
    const r = await api('/api/tests/upload', { body: { name: file.name, content: await file.text() } });
    $('dlg-upload').close(); $('up-file').value = '';
    lab.selFiles.add(r.file); delete lab.selTests[r.file];
    await loadCatalog();
    note('run-msg', r.message, 'ok');
  } catch (err) { note('up-msg', err.message, 'err'); }
});

/* ============================ SETTINGS ============================ */
function initSettings() {
  $('btn-show').addEventListener('click', () => {
    const show = $('key').type === 'password';
    $('key').type = show ? 'text' : 'password';
    $('btn-show').textContent = show ? 'Hide' : 'Show';
    $('btn-show').setAttribute('aria-pressed', String(show));
  });
  $('btn-verify').addEventListener('click', () => withBusy('btn-verify', async () => {
    const r = await api('/api/settings/verify', { body: { apiKey: $('key').value } });
    note('key-msg', r.message, r.ok ? 'ok' : 'err');
    if (r.ok) fillModels(r.models);
  }));
  $('btn-savekey').addEventListener('click', () => withBusy('btn-savekey', async () => {
    const r = await api('/api/settings', { body: { apiKey: $('key').value, mode: 'groq' } });
    note('key-msg', r.message, r.ok ? 'ok' : 'err');
    if (r.ok) { $('key').value = ''; if (r.models) fillModels(r.models); await loadSettings(); }
  }));
  $('btn-removekey').addEventListener('click', () => withBusy('btn-removekey', async () => {
    if (!confirm('Remove the Groq key from this computer? The app will switch to offline mode.')) return;
    const r = await api('/api/settings/key', { method: 'DELETE' });
    note('key-msg', r.message, 'ok'); await loadSettings();
  }));
  $('btn-savemodel').addEventListener('click', () => withBusy('btn-savemodel', async () => {
    const mode = document.querySelector('input[name=mode]:checked')?.value;
    const r = await api('/api/settings', { body: {
      mode, model: $('model').value, fallbackModel: $('fallback').value, judgeModel: $('judge-model').value,
      temperature: $('temperature').value, maxTokens: $('max-tokens').value,
    } });
    note('model-msg', r.message, r.ok ? 'ok' : 'err'); if (r.ok) await loadSettings();
  }));
  $('btn-saveretriever').addEventListener('click', () => withBusy('btn-saveretriever', async () => {
    const r = await api('/api/settings', { body: { topK: $('top-k').value, minScore: $('min-score').value } });
    note('retriever-msg', r.message.replace(/^Saved\..*$/, 'Saved. The next question uses the new retriever settings.'), r.ok ? 'ok' : 'err');
    if (r.ok) await loadSettings();
  }));
  $('temperature').addEventListener('input', showTemperature);
  $('try-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const question = $('try-q').value.trim();
    if (!question) return;
    $('try-send').disabled = true;
    $('try-out').innerHTML = '<p class="hint">Asking…</p>';
    try {
      const d = await api('/api/ask', { body: { question } });
      const st = d.settings || {};
      $('try-out').innerHTML = `<div class="try-answer ${d.fallback ? 'fallback' : ''}">${esc(d.answer)}
        <div class="meta">${d.citations.map((c) => `<span class="pill cite">${esc(c)}</span>`).join('')}
          <span class="pill">${esc(d.model)}</span><span class="pill">temperature ${st.temperature}</span>
          <span class="pill">${d.retrieved.length} of ${st.top_k} pages</span><span class="pill">${d.usage.completion} tokens</span><span class="pill">${d.latency_ms} ms</span></div></div>`;
    } catch (err) { note('try-out', err.message, 'err'); }
    finally { $('try-send').disabled = false; }
  });
}

async function withBusy(id, fn) {
  const b = $(id); const label = b.textContent;
  b.disabled = true; b.textContent = 'Working…';
  try { await fn(); } catch (err) { note({ 'btn-savemodel': 'model-msg', 'btn-saveretriever': 'retriever-msg' }[id] || 'key-msg', err.message, 'err'); }
  finally { b.disabled = false; b.textContent = label; }
}

let currentSettings = null;
function showTemperature() {
  const v = Number($('temperature').value);
  $('temperature-out').textContent = v.toFixed(2).replace(/\.?0+$/, '') || '0';
  $('temp-warn').classList.toggle('hidden', v === 0);
}
function fillModels(models) {
  const s = currentSettings || {};
  const opts = (sel) => [...new Set([sel, ...models].filter(Boolean))].map((m) => `<option ${m === sel ? 'selected' : ''}>${esc(m)}</option>`).join('');
  $('model').innerHTML = opts(s.model);
  $('fallback').innerHTML = opts(s.fallbackModel);
  $('judge-model').innerHTML = opts(s.judgeModel);
}

async function loadSettings() {
  try {
    const s = await api('/api/settings');
    currentSettings = s;
    $('keystate').innerHTML = s.hasKey
      ? `<span class="dot"></span><div><span class="big">Key saved</span> <code>${esc(s.keyMasked)}</code><br><small class="sub">Mode: ${esc(s.mode)}${s.mode === 'groq' ? ` · ${esc(s.model)} · temperature ${s.temperature}` : ''}</small></div>`
      : '<span class="dot off"></span><div><span class="big">No key yet</span><br><small class="sub">The app answers in offline demo mode.</small></div>';
    document.querySelectorAll('input[name=mode]').forEach((r) => { r.checked = r.value === s.mode; });
    $('temperature').value = s.temperature; showTemperature();
    $('max-tokens').value = s.maxTokens;
    $('top-k').value = s.topK;
    $('min-score').value = s.minScore;
    fillModels(['llama-3.3-70b-versatile', 'llama-3.1-8b-instant']);
    if (s.hasKey) api('/api/settings/models').then((m) => fillModels(m.models)).catch(() => {});
    refreshStatus();
  } catch (err) { note('key-msg', err.message, 'err'); }
}

function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

refreshStatus();
showTab();
