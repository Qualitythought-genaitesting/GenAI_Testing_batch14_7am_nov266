/* =====================================================================
 *   ___  _____   QUALITY THOUGHT  |  Student Helpdesk RAG
 *  / _ \|_   _|  Transforming Dreams! Redefining Future!
 * | (_) | | |
 *  \__\_\ |_|    File: app/server.js
 * ---------------------------------------------------------------------
 *  Local web server (Node.js built-in http, no frameworks).
 *
 *  Pages (one app, three tabs)
 *    http://localhost:3000/#chat       student chat
 *    http://localhost:3000/#lab        Test Lab: pick tests + metrics, run, see results
 *    http://localhost:3000/#settings   Groq key, model, temperature, retriever
 *    http://localhost:3000/report      branded report from run.bat
 *    http://localhost:3000/report/judge  LLM-as-a-judge report (npm run report:judge)
 *
 *  RAG API (used by the chat page AND by promptfoo)
 *    POST /api/ask {"question": ".."}  answer contract (JSON)
 *    GET  /api/health                  status (used by run.bat)
 *    GET  /api/kb                      knowledge-base pages
 *
 *  Admin API (only from this computer: localhost)
 *    GET/POST /api/settings  (key, model, temperature, max tokens, retriever)
 *    POST /api/settings/verify, DELETE /api/settings/key
 *    GET  /api/tests/catalog           test files + metrics
 *    POST /api/tests/add | /api/tests/upload, DELETE /api/tests/file?name=
 *    POST /api/runs/preview | /api/runs, POST /api/runs/stop
 *    GET  /api/runs, GET /api/runs/<id>, GET /runs/<id>/<file>
 * ===================================================================== */
const http = require('http');
const fs = require('fs');
const path = require('path');
const config = require('./env');
const { ask } = require('./rag/pipeline');
const { loadKnowledgeBase } = require('./rag/retriever');

// Test Lab modules need js-yaml (installed by run.bat / npm install).
let settings, catalog, runner, adminError = null;
try {
  settings = require('./admin/settings');
  catalog = require('./admin/catalog');
  runner = require('./admin/runner');
} catch (err) {
  adminError = `Test Lab unavailable: ${err.message}. Run "npm install" in the project folder.`;
}

const PUBLIC = path.join(__dirname, 'public');
const TYPES = { '.html': 'text/html; charset=utf-8', '.png': 'image/png', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.yaml': 'text/plain; charset=utf-8' };

function send(res, status, body, type = 'application/json; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body, null, 2));
}

function sendFile(res, file) {
  if (!file || !fs.existsSync(file)) return send(res, 404, { error: 'Not found' });
  send(res, 200, fs.readFileSync(file), TYPES[path.extname(file)] || 'application/octet-stream');
}

function readBody(req, limit = 600000) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (c) => { data += c; if (data.length > limit) { reject(new Error('Request too large')); req.destroy(); } });
    req.on('end', () => {
      try { resolve(data ? JSON.parse(data) : {}); } catch (_) { reject(new Error('Body must be JSON')); }
    });
    req.on('error', reject);
  });
}

/** Admin endpoints change settings and start processes: this computer only. */
const isLocal = (req) => ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress);

async function admin(req, res, url) {
  if (!isLocal(req)) return send(res, 403, { error: 'The Test Lab and Settings only work from this computer (localhost).' });
  if (adminError) return send(res, 503, { error: adminError });
  const p = url.pathname;
  const m = req.method;

  // ---- settings ----
  if (p === '/api/settings' && m === 'GET') return send(res, 200, settings.current());
  if (p === '/api/settings' && m === 'POST') return send(res, 200, await settings.save(await readBody(req)));
  if (p === '/api/settings/verify' && m === 'POST') return send(res, 200, await settings.verifyKey(String((await readBody(req)).apiKey || '').trim()));
  if (p === '/api/settings/models' && m === 'GET') return send(res, 200, await settings.models());
  if (p === '/api/settings/key' && m === 'DELETE') return send(res, 200, settings.removeKey());

  // ---- tests and metrics ----
  if (p === '/api/tests/catalog' && m === 'GET') {
    const lang = catalog.langOf(url.searchParams.get('lang'));
    const metrics = catalog.metrics(lang).map(({ assertions, ...rest }) => rest);
    return send(res, 200, { lang, python: catalog.pythonInfo(), files: catalog.testFiles(), metrics, kb: loadKnowledgeBase().map(({ id, title }) => ({ id, title })) });
  }
  if (p === '/api/tests/add' && m === 'POST') return send(res, 200, catalog.addTest(await readBody(req)));
  if (p === '/api/tests/upload' && m === 'POST') return send(res, 200, catalog.uploadFile(await readBody(req)));
  if (p === '/api/tests/file' && m === 'DELETE') return send(res, 200, catalog.deleteFile(url.searchParams.get('name')));

  // ---- runs ----
  if (p === '/api/runs/preview' && m === 'POST') return send(res, 200, runner.preview(await readBody(req)));
  if (p === '/api/runs/stop' && m === 'POST') return send(res, 200, runner.stop());
  if (p === '/api/runs' && m === 'POST') return send(res, 200, runner.start(await readBody(req)));
  if (p === '/api/runs' && m === 'GET') return send(res, 200, runner.list());
  const run = p.match(/^\/api\/runs\/([\w-]+)$/);
  if (run && m === 'GET') return send(res, 200, runner.get(run[1]));
  const file = p.match(/^\/runs\/([\w-]+)\/([\w.-]+)$/);
  if (file && m === 'GET') return sendFile(res, runner.runFile(file[1], file[2]));
  return send(res, 404, { error: 'Not found' });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (req.method === 'POST' && url.pathname === '/api/ask') {
      const body = await readBody(req, 100000);
      if (!body.question || !String(body.question).trim()) return send(res, 400, { error: 'Send JSON like {"question": "Can I get a refund?"}' });
      const result = await ask(body.question);
      if (runner) runner.onAsk();
      console.log(`[ask] ${result.latency_ms}ms ${result.fallback ? 'FALLBACK' : result.citations.join(',')} | ${result.question}`);
      return send(res, 200, result);
    }
    if (url.pathname === '/api/health') {
      return send(res, 200, { status: 'ok', app: 'Quality Thought Student Helpdesk', mode: config.LLM_MODE, model: config.LLM_MODE === 'groq' ? config.GROQ_MODEL : 'offline-extractive', temperature: config.TEMPERATURE, maxTokens: config.MAX_TOKENS, topK: config.TOP_K, minScore: config.MIN_SCORE, testLab: !adminError });
    }
    if (url.pathname === '/api/kb') {
      return send(res, 200, loadKnowledgeBase().map(({ id, title, text }) => ({ id, title, text })));
    }
    if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/runs/')) return await admin(req, res, url);
    if (url.pathname === '/report' || url.pathname === '/report/judge') {
      const report = path.join(config.ROOT, 'results', url.pathname === '/report' ? 'qt-test-report.html' : 'qt-judge-report.html');
      if (fs.existsSync(report)) return sendFile(res, report);
      return send(res, 200, '<p style="font-family:sans-serif;padding:2rem">No run.bat report yet. Use the <a href="/#lab">Test Lab</a> or run <b>run.bat</b>.</p>', TYPES['.html']);
    }
    if (url.pathname === '/assets/qt-logo.png') return sendFile(res, path.join(config.ROOT, 'assets', 'qt-logo.png'));
    if (url.pathname === '/' || url.pathname === '/index.html') return sendFile(res, path.join(PUBLIC, 'index.html'));
    if (/^\/(app\.js|style\.css)$/.test(url.pathname)) return sendFile(res, path.join(PUBLIC, url.pathname.slice(1)));
    return send(res, 404, { error: 'Not found' });
  } catch (err) {
    console.error('[error]', err.message);
    return send(res, 400, { error: err.message });
  }
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`Port ${config.PORT} is already in use. The helpdesk may already be running: open http://localhost:${config.PORT}`);
    process.exit(1);
  }
  throw err;
});

server.listen(config.PORT, () => {
  console.log('==============================================================');
  console.log('  QUALITY THOUGHT  |  Student Helpdesk RAG');
  console.log('  Transforming Dreams! Redefining Future!');
  console.log('==============================================================');
  console.log(`  Chat      : http://localhost:${config.PORT}/#chat`);
  console.log(`  Test Lab  : http://localhost:${config.PORT}/#lab`);
  console.log(`  Settings  : http://localhost:${config.PORT}/#settings`);
  console.log(`  LLM mode  : ${config.LLM_MODE}${config.LLM_MODE === 'groq' ? ` (${config.GROQ_MODEL})` : ' (add a Groq key in Settings for real answers)'}`);
  if (adminError) console.log(`  ${adminError}`);
  console.log('  Keep this window open. Ctrl+C to stop.');
  console.log('==============================================================');
});
