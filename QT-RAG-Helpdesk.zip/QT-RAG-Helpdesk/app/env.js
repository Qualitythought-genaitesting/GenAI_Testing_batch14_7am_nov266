/* =====================================================================
 *   ___  _____   QUALITY THOUGHT  |  Student Helpdesk RAG
 *  / _ \|_   _|  Transforming Dreams! Redefining Future!
 * | (_) | | |
 *  \__\_\ |_|    File: app/env.js
 * ---------------------------------------------------------------------
 *  Reads the .env file (KEY=value lines) into process.env.
 *  Zero dependencies on purpose: students can read every line.
 * ===================================================================== */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

function loadEnv() {
  const file = path.join(ROOT, '.env');
  if (!fs.existsSync(file)) return;
  for (const raw of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#') || !line.includes('=')) continue;
    const key = line.slice(0, line.indexOf('=')).trim();
    const value = line.slice(line.indexOf('=') + 1).trim().replace(/^["']|["']$/g, '');
    // A value already set in the terminal wins over the .env file.
    if (process.env[key] === undefined) process.env[key] = value;
  }
}

loadEnv();

const config = {
  ROOT,
  PORT: Number(process.env.PORT || 3000),
  GROQ_API_KEY: process.env.GROQ_API_KEY || '',
  GROQ_MODEL: process.env.GROQ_MODEL || 'llama-3.3-70b-versatile',
  GROQ_FALLBACK_MODEL: process.env.GROQ_FALLBACK_MODEL || 'llama-3.1-8b-instant',
  // The LLM judge (grader) used by model-graded promptfoo assertions
  JUDGE_MODEL: process.env.QT_JUDGE_MODEL || 'llama-3.3-70b-versatile',
  GROQ_BASE_URL: (process.env.GROQ_BASE_URL || 'https://api.groq.com/openai/v1').replace(/\/$/, ''),
  // "groq" = real LLM. "offline" = no internet demo mode (extractive answers).
  // No key means offline, whatever QT_LLM_MODE says.
  LLM_MODE: process.env.GROQ_API_KEY ? (process.env.QT_LLM_MODE || 'groq').toLowerCase() : 'offline',
  // Generation settings (editable on the Settings page)
  TEMPERATURE: Number(process.env.QT_TEMPERATURE === undefined || process.env.QT_TEMPERATURE === '' ? 0 : process.env.QT_TEMPERATURE),     // 0 = most repeatable answers
  MAX_TOKENS: Number(process.env.QT_MAX_TOKENS || 200),     // longest answer the LLM may write
  // Retrieval settings (editable on the Settings page)
  TOP_K: Number(process.env.QT_TOP_K || 3),
  MIN_SCORE: Number(process.env.QT_MIN_SCORE || 2.5),
  // Estimated list prices (USD per 1M tokens) so the promptfoo "cost" check has a number.
  PRICE_IN_PER_M: Number(process.env.QT_PRICE_IN_PER_M || 0.59),
  PRICE_OUT_PER_M: Number(process.env.QT_PRICE_OUT_PER_M || 0.79),
};

module.exports = config;
