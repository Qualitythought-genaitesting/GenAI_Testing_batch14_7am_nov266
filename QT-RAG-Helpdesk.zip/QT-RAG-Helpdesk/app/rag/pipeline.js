/* =====================================================================
 *   ___  _____   QUALITY THOUGHT  |  Student Helpdesk RAG
 *  / _ \|_   _|  Transforming Dreams! Redefining Future!
 * | (_) | | |
 *  \__\_\ |_|    File: app/rag/pipeline.js   (RETRIEVE -> AUGMENT -> GENERATE)
 * ---------------------------------------------------------------------
 *  One function, ask(question), runs the whole RAG flow and returns
 *  the ANSWER CONTRACT (a JSON object). Promptfoo tests read it:
 *
 *  {
 *    question, answer,              <- generation checks (regex, contains ...)
 *    citations: ["DOC-102"],        <- citation checks
 *    retrieved: [{rank,id,title,score}],  <- retrieval metrics (Hit@K, MRR ...)
 *    context,                       <- numeric faithfulness check
 *    fallback: false,               <- out-of-scope check
 *    mode, model, settings, latency_ms, usage, cost
 *  }
 * ===================================================================== */
const fs = require('fs');
const path = require('path');
const config = require('../env');
const { search } = require('./retriever');
const { generate } = require('./generator');

const PROMPTS = path.join(config.ROOT, 'prompts');
const read = (f) => fs.readFileSync(path.join(PROMPTS, f), 'utf8').replace(/\r\n/g, '\n').trim();

/** Fill {{placeholders}} in a Notepad template. */
const fill = (template, values) => template.replace(/\{\{\s*(\w+)\s*\}\}/g, (_, k) => (values[k] ?? ''));

async function ask(rawQuestion) {
  const question = String(rawQuestion || '').trim().slice(0, 500);
  const started = Date.now();
  const FALLBACK = read('fallback_message.txt');

  // ---- STEP 1: RETRIEVE ------------------------------------------------
  const pages = search(question);

  // ---- STEP 2: AUGMENT -------------------------------------------------
  const context = pages.map((p) => `[${p.id}] ${p.title}\n${p.text}`).join('\n\n');
  const system = fill(read('system_prompt.txt'), { context, fallback: FALLBACK });
  const user = `Student question: ${question}`;

  // ---- STEP 3: GENERATE ------------------------------------------------
  let answer;
  let usage = {};
  let model = 'none';
  if (!question || pages.length === 0) {
    // Nothing relevant was found: never call the LLM, never guess.
    answer = FALLBACK;
  } else {
    const out = await generate({ system, user, question, pages, fallback: FALLBACK });
    answer = out.text;
    usage = out.usage;
    model = out.model;
  }

  const fallback = answer.trim() === FALLBACK || answer.startsWith(FALLBACK.slice(0, 30));
  const citations = [...new Set([...answer.matchAll(/\[(DOC-\d{3})\]/g)].map((m) => m[1]))];
  const promptTokens = usage.prompt_tokens || 0;
  const completionTokens = usage.completion_tokens || 0;
  const cost = (promptTokens * config.PRICE_IN_PER_M + completionTokens * config.PRICE_OUT_PER_M) / 1e6;

  return {
    question,
    answer,
    citations,
    retrieved: pages.map(({ rank, id, title, score }) => ({ rank, id, title, score })),
    context,
    fallback,
    mode: config.LLM_MODE,
    model,
    settings: { temperature: config.TEMPERATURE, max_tokens: config.MAX_TOKENS, top_k: config.TOP_K, min_score: config.MIN_SCORE },
    latency_ms: Date.now() - started,
    usage: { prompt: promptTokens, completion: completionTokens, total: promptTokens + completionTokens },
    cost: Number(cost.toFixed(8)),
  };
}

module.exports = { ask };
