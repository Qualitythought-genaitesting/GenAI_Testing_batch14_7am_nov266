/* =====================================================================
 *   ___  _____   QUALITY THOUGHT  |  Student Helpdesk RAG
 *  / _ \|_   _|  Transforming Dreams! Redefining Future!
 * | (_) | | |
 *  \__\_\ |_|    File: app/rag/retriever.js   (STEP 1 = RETRIEVE)
 * ---------------------------------------------------------------------
 *  The "librarian". Reads every page in /knowledge_base and finds the
 *  pages that best match the student's question using BM25 keyword
 *  scoring. No embeddings, no database, no API key: same question,
 *  same ranking, every time. That makes retrieval 100% testable with
 *  deterministic promptfoo assertions (Hit@K, MRR, precision, recall).
 * ===================================================================== */
const fs = require('fs');
const path = require('path');
const config = require('../env');

const KB_DIR = path.join(config.ROOT, 'knowledge_base');

// Words that carry no meaning for search ("what", "is", "the" ...)
const STOPWORDS = new Set(('a an and are as at be by can could do does for from get give go has have how i ' +
  'if in is it its me my of on or our please should so tell than that the their them then there these they ' +
  'this to was we were what when where which who whom why will with would you your yours about any also am ' +
  'did doing done just more most much need not now only own same some such too very want know may let').split(' '));

/** Lower-case, split into words, drop stopwords, apply a tiny stemmer. */
function tokenize(text) {
  return (text.toLowerCase().match(/[a-z0-9]+/g) || [])
    .filter((w) => !STOPWORDS.has(w))
    .map(stem);
}

/** Very small stemmer: refunded -> refund, batches -> batch, timings -> timing */
function stem(w) {
  if (w.length > 6 && w.endsWith('able')) return w.slice(0, -4);
  if (w.length > 5 && w.endsWith('ing')) return w.slice(0, -3);
  if (w.length > 4 && w.endsWith('ed')) return w.slice(0, -2);
  if (w.length > 4 && w.endsWith('es') && /(ch|sh|x|ss)es$/.test(w)) return w.slice(0, -2);
  if (w.length > 3 && w.endsWith('s') && !w.endsWith('ss')) return w.slice(0, -1);
  return w;
}

/** Parse one knowledge-base page (ID / TITLE / KEYWORDS header, then body). */
function parsePage(fileName, raw) {
  const [head, ...rest] = raw.split(/\r?\n---\r?\n/);
  const field = (name) => ((head.match(new RegExp(`^${name}:\\s*(.+)$`, 'mi')) || [])[1] || '').trim();
  return {
    id: field('ID'),
    title: field('TITLE'),
    keywords: field('KEYWORDS'),
    text: rest.join('\n').trim(),
    file: fileName,
  };
}

function loadKnowledgeBase() {
  return fs.readdirSync(KB_DIR)
    .filter((f) => f.endsWith('.txt'))
    .sort()
    .map((f) => parsePage(f, fs.readFileSync(path.join(KB_DIR, f), 'utf8')))
    .filter((p) => p.id && p.text);
}

// ---------------- BM25 index ----------------
const K1 = 1.2;
const B = 0.75;
let INDEX = null;

function buildIndex() {
  const pages = loadKnowledgeBase();
  const docs = pages.map((p) => {
    // Title counts twice: a match in the title is a strong signal.
    const tokens = tokenize(`${p.title} ${p.title} ${p.keywords} ${p.text}`);
    const tf = {};
    tokens.forEach((t) => { tf[t] = (tf[t] || 0) + 1; });
    return { page: p, tf, length: tokens.length };
  });
  const df = {};
  docs.forEach((d) => Object.keys(d.tf).forEach((t) => { df[t] = (df[t] || 0) + 1; }));
  const avgLength = docs.reduce((s, d) => s + d.length, 0) / Math.max(docs.length, 1);
  INDEX = { docs, df, avgLength, N: docs.length };
  return INDEX;
}

/**
 * Search the knowledge base.
 * @returns ranked pages: [{ rank, id, title, score, text }]
 * Pages scoring below MIN_SCORE are dropped, so an off-topic question
 * returns [] and the app answers with the safe fallback message.
 */
function search(question, topK = config.TOP_K) {
  const idx = INDEX || buildIndex();
  const qTokens = [...new Set(tokenize(question))];
  const scored = idx.docs.map((d) => {
    let score = 0;
    for (const t of qTokens) {
      const f = d.tf[t];
      if (!f) continue;
      const idf = Math.log(1 + (idx.N - idx.df[t] + 0.5) / (idx.df[t] + 0.5));
      score += idf * ((f * (K1 + 1)) / (f + K1 * (1 - B + (B * d.length) / idx.avgLength)));
    }
    return { page: d.page, score };
  });
  return scored
    .filter((s) => s.score >= config.MIN_SCORE)
    .sort((a, b) => b.score - a.score || a.page.id.localeCompare(b.page.id))
    .slice(0, topK)
    .map((s, i) => ({
      rank: i + 1,
      id: s.page.id,
      title: s.page.title,
      score: Number(s.score.toFixed(3)),
      text: s.page.text,
    }));
}

module.exports = { search, tokenize, loadKnowledgeBase, buildIndex };
