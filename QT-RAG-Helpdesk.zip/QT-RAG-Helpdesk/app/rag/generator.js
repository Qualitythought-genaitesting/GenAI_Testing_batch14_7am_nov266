/* =====================================================================
 *   ___  _____   QUALITY THOUGHT  |  Student Helpdesk RAG
 *  / _ \|_   _|  Transforming Dreams! Redefining Future!
 * | (_) | | |
 *  \__\_\ |_|    File: app/rag/generator.js   (STEP 3 = GENERATE)
 * ---------------------------------------------------------------------
 *  The "writer". Sends the augmented prompt to the Groq LLM
 *  (OpenAI-compatible API, free key from https://console.groq.com).
 *
 *  Two modes (set QT_LLM_MODE in .env):
 *    groq    -> real LLM answer (default when GROQ_API_KEY is set)
 *    offline -> no internet needed; answers with the text of the best
 *               retrieved page (handy in a classroom demo)
 * ===================================================================== */
const config = require('../env');
const { tokenize } = require('./retriever');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * Call Groq chat completions. Retries on 429 (rate limit) and 5xx.
 * Free-tier keys have per-minute token limits, so a short wait and
 * retry is normal. If the daily limit of the main model is hit, it
 * switches once to GROQ_FALLBACK_MODEL.
 */
async function callGroq(messages, opts = {}) {
  if (!config.GROQ_API_KEY) {
    throw new Error('GROQ_API_KEY is missing. Add it to the .env file (free key: https://console.groq.com/keys).');
  }
  let model = opts.model || config.GROQ_MODEL;
  let switched = false;
  for (let attempt = 1; attempt <= 6; attempt++) {
    const res = await fetch(`${config.GROQ_BASE_URL}/chat/completions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${config.GROQ_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model, messages, temperature: opts.temperature ?? config.TEMPERATURE, max_tokens: opts.maxTokens ?? config.MAX_TOKENS }),
    });

    if (res.ok) {
      const data = await res.json();
      return {
        text: (data.choices?.[0]?.message?.content || '').trim(),
        usage: data.usage || {},
        model: data.model || model,
      };
    }

    const body = await res.text();
    if (res.status === 401) throw new Error('Groq rejected the API key (401). Check GROQ_API_KEY in the .env file.');
    if (res.status === 429 || res.status >= 500) {
      const retryAfter = Number(res.headers.get('retry-after')) || 0;
      // Retry-After longer than a minute usually means a daily limit: try the smaller model once.
      if (retryAfter > 60 && !switched && config.GROQ_FALLBACK_MODEL && config.GROQ_FALLBACK_MODEL !== model) {
        console.warn(`[groq] ${model} is rate limited for ${retryAfter}s, switching to ${config.GROQ_FALLBACK_MODEL}`);
        model = config.GROQ_FALLBACK_MODEL;
        switched = true;
        continue;
      }
      const waitMs = Math.min(retryAfter ? retryAfter * 1000 : 1500 * attempt, 20000);
      console.warn(`[groq] HTTP ${res.status}, retry ${attempt}/6 in ${waitMs} ms`);
      await sleep(waitMs);
      continue;
    }
    throw new Error(`Groq API error ${res.status}: ${body.slice(0, 300)}`);
  }
  throw new Error('Groq API is still rate limiting after 6 retries. Wait a minute and run again.');
}

/**
 * Offline mode: the full text of the best page, plus the single best
 * sentence of a second page when it scores almost as high (questions
 * that need two pages, like "fee AND refund"). Every part is cited.
 */
function offlineAnswer(question, pages, fallback) {
  if (!pages.length) return { text: fallback, usage: {}, model: 'offline-extractive' };
  const qTokens = new Set(tokenize(question));
  const [best, second] = pages;
  const parts = [`${best.text} [${best.id}]`];
  if (second && second.score >= best.score * 0.7) {
    const sentence = second.text.split(/(?<=\.)\s+/)
      .map((s, i) => ({ s, i, hits: tokenize(s).filter((t) => qTokens.has(t)).length }))
      .sort((a, b) => b.hits - a.hits || a.i - b.i)[0].s;
    parts.push(`${sentence} [${second.id}]`);
  }
  return { text: parts.join(' '), usage: {}, model: 'offline-extractive' };
}

async function generate({ system, user, question, pages, fallback }) {
  if (config.LLM_MODE === 'offline') return offlineAnswer(question, pages, fallback);
  return callGroq([
    { role: 'system', content: system },
    { role: 'user', content: user },
  ]);
}

module.exports = { generate, callGroq };
