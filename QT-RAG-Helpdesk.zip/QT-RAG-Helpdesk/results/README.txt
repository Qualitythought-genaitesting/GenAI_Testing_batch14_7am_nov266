Test results are written here by run.bat (latest-results.json, qt-test-report.html).
